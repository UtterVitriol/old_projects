# hangman

hangman is a c program that lets you play the game hangman!

## Installation

clone or download

```bash
git clone "link"
```

## Usage

```bash
./hangman
./hangman [wordsfile]
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MEMES](https://reddit.com/r/programminghumor)
