#include "response.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

bool bad_request(int sock)
{
	/*
	 * Response for bad request
	 */

	char response[] =
	    "HTTP/1.1 400 Bad Request\nContent-type: text/html\n\n"
	    "bad request\n";

	write(sock, response, strlen(response));

	return true;
}

bool forbidden(int sock)
{
	/*
	 * Response for forbidden
	 */

	char response[] = "HTTP/1.1 403 Forbidden\nContent-type: text/html\n\n"
			  "Unauthorized Request\n";

	write(sock, response, strlen(response));

	return true;
}

bool not_found(int sock)
{
	/*
	 * Response for not found
	 */

	char response[] = "HTTP/1.1 404 Not Found\nContent-type: text/html\n\n"
			  "Page Requested Not Found\n";

	write(sock, response, strlen(response));

	return true;
}

bool method_not_allowed(int sock)
{
	/*
	 * Response for method not allowed
	 */

	char response[] =
	    "HTTP/1.1 405 Method Not Allowed\nContent-type: text/html\n\n"
	    "Method Not Allowed\n";

	write(sock, response, strlen(response));

	return true;
}

bool internal_error(int sock)
{
	/*
	 * Response for internal error
	 */

	char response[] =
	    "HTTP/1.1 500 Internal Server Error\nContent-type: text/html\n\n"
	    "Internal Server Error\n";

	write(sock, response, strlen(response));

	return true;
}

bool serve_request(int sock, char *file)
{
	/*
	 * Serves valid http get request
	 */

	// check for cgi-bin/ request
	if (strncmp(file, "cgi-bin/", 7) == 0) {
		return serve_script(sock, file);
	}

	FILE *fp = NULL;

	char file_path[256] = {'\0'};

	// prepend www/ to request
	strncat(file_path, "www/", 5);
	strncat(file_path, file, strlen(file));

	fp = fopen(file_path, "r");

	if (!fp) {
		internal_error(sock);
		return false;
	}

	// generate headers
	char response[] = "HTTP/1.1 200 OK\nContent-type: text/html\n";

	write(sock, response, strlen(response));

	time_t t = time(NULL);
	struct tm *info = localtime(&t);
	char date[37] = {'\0'};

	strftime(date, 37, "Date: %a, %d %b %Y %H:%M:%S %Z\n", info);

	write(sock, date, strlen(date));

	// get file size
	fseek(fp, SEEK_CUR, SEEK_END);
	size_t size = ftell(fp);

	rewind(fp);

	char content_length[50] = {'\0'};

	snprintf(content_length, 49, "Content-Length: %ld\n\n", size - 1);

	char *line = NULL;
	size_t s;
	int bytes_read;

	// send file
	while ((bytes_read = getline(&line, &s, fp)) != -1) {
		write(sock, line, bytes_read);
	}

	if (line) {
		free(line);
	}
	fclose(fp);
	return true;
}

bool serve_script(int sock, char *file)
{
	/*
	 * Execute cgi-script
	 * Write output to socket
	 */

	if (fork() == 0) {
		dup2(sock, 1);
		execlp("python3", "python3", file, NULL);
		exit(0);
	}
	return true;
}
