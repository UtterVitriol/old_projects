#ifndef RESPONSE_H_
#define RESPONSE_H_
#include <stdbool.h>

bool bad_request(int sock);
bool forbidden(int sock);
bool not_found(int sock);
bool method_not_allowed(int sock);
bool internal_error(int sock);
bool serve_request(int sock, char *file);
bool serve_script(int sock, char *file);

#endif