#!/usr/bin/env python3
page = '''<!doctype html>
<html>
    <head>
        <title>CGI</title>
    </head>
    <body>
        <h2>Sample "CGI" Script for ASHTI</h2>
        This is some text
        <br></br>
    </body>
</html>'''
print("HTTP/1.1 200 OK\n", end='')
print("Content-Type: text/html\r\n", end='')
print("Content-Length: {}\r\n\r\n".format(len(page)), end='')
print(page, end='')
