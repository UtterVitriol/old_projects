#!/usr/bin/env python3

def main():
    print("Are you ready for this?\n")
    print("BOOM! Two lines\n")

if __name__ == "__main__":
    main()
