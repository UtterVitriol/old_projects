#!/usr/bin/env python3

def main():
    print("I should not be executed!\n")

if __name__ == "__main__":
    main()
