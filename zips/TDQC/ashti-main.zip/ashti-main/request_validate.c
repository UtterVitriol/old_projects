#include "request_validate.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

int request_validate(char *request)
{
	int code = OK;

	// arbitrary copy
	char request_copy[1028] = {'\0'};
	strncpy(request_copy, request, strlen(request));

	char *token = strtok(request_copy, " ");

	if (!token) {
		code = INTERNALERROR;
		goto breakout;
	}
	char *method = NULL;
	char *path = NULL;
	char *version = NULL;
	int i = 0;

	while (token) {
		if (i == 0) {
			method = strdup(token);
			if (method == NULL) {
				puts("method bad");
				exit(1);
			}
		} else if (i == 1) {
			path = strdup(token);

			if (path == NULL) {
				puts("path bad");
				exit(1);
			}
		} else if (i == 2) {
			version = strdup(token);

			if (version == NULL) {
				puts("version bad");
				exit(1);
			}
		}
		token = strtok(NULL, " ");
		i++;
	}

	/* Check for 405 Method Not Allowed */
	if (strcmp(method, "GET") != 0) {
		if (strcmp(method, "HEAD") == 0 ||
		    strcmp(method, "POST") == 0 || strcmp(method, "PUT") == 0 ||
		    strcmp(method, "DELETE") == 0 ||
		    strcmp(method, "CONNECT") == 0 ||
		    strcmp(method, "OPTIONS") == 0 ||
		    strcmp(method, "TRACE") == 0 ||
		    strcmp(method, "PATCH") == 0) {
			code = METHODNOTALLOWED;
			goto breakout;
		}
		code = BADREQUEST;
		goto breakout;
	}

	/* Check for 400 Bad Request */
	if (strstr(path, "..") != NULL ||
	    (strncmp(version, "HTTP/1.1", 8) != 0)) {
		code = BADREQUEST;
		goto breakout;
	}

	/* Validate File */
	int status = file_validate(path);

	if (status) {
		if (status < 0) {
			code = FORBIDDEN;
		} else {
			code = NOTFOUND;
		}
	}

breakout:

	if (code == OK) {
		if (strcmp(path, "/") == 0) {
			char index[] = "/index.html";

			memset(request, '\0', strlen(request) + 1);
			strncpy(request, index, strlen(index));
		} else {
			memset(request, '\0', strlen(request) + 1);
			strncpy(request, path, strlen(path));
		}
	}

	free(method);
	free(path);
	free(version);

	return code;
}

int file_validate(char *fname)
{
	/* Checks the corresponding permissions for file requested.
	 * If the file does not exist, a 1 is returned.
	 * If the permissions are not valid -1 is returned.
	 * If everything is valid a 0 is returned.
	 */
	int result;
	int cgi = 0;

	// arbitrary filepath length
	char fpath[1024];

	if (strncmp(fname, "/cgi-bin/", 8) != 0) {
		snprintf(fpath, strlen(fname) + 5, "/www%s", fname);
	} else {
		cgi = 1;
		snprintf(fpath, strlen(fname) + 1, "%s", fname);
	}
	char *file_path = strchr(fpath, '/') + 1;

	// Check if file exists
	if (access(file_path, F_OK) == -1) {
		// file does not exist
		return NOTFOUND;
	}

	result = access(file_path, R_OK);

	// Check execution for cgi-bin
	if (cgi == 1 && result != -1) {
		result = access(file_path, X_OK);
	}

	return result;
}
