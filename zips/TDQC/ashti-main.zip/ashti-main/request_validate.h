#ifndef REQUEST_VALIDATE_H_
#define REQUEST_VALIDATE_H_
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

/*
 * Enum codes:
 * 200 OK
 * 400 Bad Request (syntax)
 * 403 Forbidden (permissions)
 * 404 Not found
 * 405 Method not allowed
 * 500 Internal Error
 */
enum codes
{
	OK = 200,
	BADREQUEST = 400,
	FORBIDDEN = 403,
	NOTFOUND = 404,
	METHODNOTALLOWED = 405,
	INTERNALERROR = 500
};

/**
 * Validate HTTP server request string.
 * @param request: Char pointer to the request string.
 * @return: HTTP enum code (see enum codes).
 */
int request_validate(char *request);

/**
 * Validate the presence and permissions of a requested file.
 * @param fname: Char pointer to the file path.
 * @return HTTP enum code (see enum codes).
 */
int file_validate(char *fname);

#endif // REQUEST_VALIDATE_H_
