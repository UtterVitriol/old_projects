#!/bin/bash
# Test server - client interaction for ashti

./ashti . & > /dev/null

# Test ashti index.html - valid
(echo 'GET /index.html HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_index.out
disown
diff -B -I '^.*Date.*' test/server_output/test_index.out test/expected_results/test_index.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test index.html                                               PASSED"
else
    echo "Test index.html                                               FAILED"
fi

# Test ashti easy.py - valid
(echo 'GET /cgi-bin/easy.py HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_easy.out
diff -B -I '^.*Date.*' test/server_output/test_easy.out test/expected_results/test_easy.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test easy.py                                                  PASSED"
else
    echo "Test easy.py                                                  FAILED"
fi

# Test ashti medium.py - valid
(echo 'GET /cgi-bin/medium.py HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_medium.out
diff -B -I '^.*Date.*' test/server_output/test_medium.out test/expected_results/test_medium.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test medium.py                                                PASSED"
else
    echo "Test medium.py                                                FAILED"
fi

# Test ashti non-x.py - 403 FORBIDDEN
(echo 'GET /cgi-bin/non-x.py HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_nonx.out
diff -B -I '^.*Date.*' test/server_output/test_nonx.out test/expected_results/test_nonx.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test non-x.py                                                 PASSED"
else
    echo "Test non-x.py                                                 FAILED"
fi

# Test ashti test1.py - valid
(echo 'GET /cgi-bin/test1.py HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_test1.out
diff -B -I '^.*Date.*' test/server_output/test_test1.out test/expected_results/test_test1.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test test1.py                                                 PASSED"
else
    echo "Test test1.py                                                 FAILED"
fi

# Test ashti 400 Bad Request
(echo 'GAT / HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_400.out
diff -B test/server_output/test_400.out test/expected_results/test_400.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test 400 Bad Request                                          PASSED"
else
    echo "Test 400 Bad Request                                          FAILED"
fi

# Test ashti 403 Forbidden
touch www/forbidden.txt && chmod -r www/forbidden.txt > /dev/null
(echo 'GET /forbidden.txt HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_403.out
diff -B test/server_output/test_403.out test/expected_results/test_403.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test 403 Forbidden                                            PASSED"
else
    echo "Test 403 Forbidden                                            FAILED"
fi
rm www/forbidden.txt

# Test ashti 404 Not Found
(echo 'GET /robots.txt HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_404.out
diff -B test/server_output/test_404.out test/expected_results/test_404.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test 404 Not Found                                            PASSED"
else
    echo "Test 404 Not Found                                            FAILED"
fi

# Test ashti 405 Method Not Allowed
(echo 'POST / HTTP/1.1\nHost: localhost\n\n' | nc -q1 localhost $(id -u)) > test/server_output/test_405.out
diff -B test/server_output/test_405.out test/expected_results/test_405.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test 405 Method Not Allowed                                   PASSED"
else
    echo "Test 405 Method Not Allowed                                   FAILED"
fi

# Test ashti Garbage TODO change port to $(id -u)
(echo 'Knock, knock.. Who is there? Robin. Robin Who? Robbing you! now gimme the cash!' | nc -q1 localhost $(id -u)) > test/server_output/test_garbage.out
diff -B test/server_output/test_garbage.out test/expected_results/test_garbage.expected
ret=$?
if [[ $ret -eq 0 ]]; then
    echo "Test Garbage                                                  PASSED"
else
    echo "Test Garbage                                                  FAILED"
fi

pkill ashti
pkill -f "nc -q1"
