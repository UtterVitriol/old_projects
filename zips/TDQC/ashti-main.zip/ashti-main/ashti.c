#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>

#include <dirent.h>
#include <errno.h>

#include <sys/stat.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <syslog.h>
#include <time.h>

#include "request_validate.h"
#include "response.h"

bool check_arg(int argc, char **argv);
bool validate_dir(char *dir_name);
bool dir_exists(char *dir_name);
void print_help(void);
bool setup_server(int *sock);
bool serve_forever(int *sock);
bool new_connection(int sock);
void log_data(char *data, struct sockaddr_in *client, bool recv);

int main(int argc, char **argv)
{
	if (!check_arg(argc, argv)) {
		return 1;
	}

	int sock;

	if (!setup_server(&sock)) {
		return 1;
	}

	serve_forever(&sock);
}

bool check_arg(int argc, char **argv)
{
	/*
	 * Validate correct number of args
	 * Call validate_dir
	 */

	if (argc != 2) {
		print_help();
		return false;
	}

	if (!validate_dir(argv[1])) {
		return false;
	}

	chdir(argv[1]);

	return true;
}

bool validate_dir(char *dir_name)
{
	/*
	 * Validate dir has www/ and cgi-bin/ as sub-directories
	 */

	if (!dir_exists(dir_name)) {
		return false;
	}

	size_t dir_len = strlen(dir_name);

	char www[250] = {'\0'};

	strncat(www, dir_name, 249);
	strncat(www, "/www", 249 - dir_len);

	if (!dir_exists(www)) {
		return false;
	}

	char cgi_bin[250] = {'\0'};

	strncat(cgi_bin, dir_name, 249);
	strncat(cgi_bin, "/cgi-bin", 249 - dir_len);

	if (!dir_exists(cgi_bin)) {
		return false;
	}

	return true;
}

bool dir_exists(char *dir_name)
{
	/*
	 * Check if dir exists
	 */
	struct stat sb;

	if (stat(dir_name, &sb) == 0 && S_ISDIR(sb.st_mode)) {
		return true;
	} else {
		print_help();
		return false;
	}

	return false;
}

bool setup_server(int *sock)
{
	/* Socket code courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up server to listen for connections
	 */

	int opt = 1;
	int len = sizeof(len);

	// create socket
	*sock = socket(AF_INET, SOCK_STREAM, 0);
	if (*sock == 0) {
		perror("Socket creation failed");
		return false;
	}

	// set socket options
	if (setsockopt(*sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
		perror("Setsockopt");
		return false;
	}

	// get user id to use as port
	int port = getuid();

	// check if port is too low
	// set port to arbitrary 5000
	// so root permissions aren't required
	if (port <= 1024) {
		port = 5000;
	}

	printf("PORT: %d\n", port);

	struct sockaddr_in addr;

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons(port);

	// bind socket to port
	if (bind(*sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("Bind failed");
		return false;
	}

	// listen for connections
	if (listen(*sock, 5) < 0) {
		perror("Listen failed");
		return false;
	}

	return true;
}

bool serve_forever(int *sock)
{
	/*
	 * Accept new connections
	 * Fork on new connection
	 */
	for (;;) {
		struct sockaddr_in addr;
		size_t addrlen = sizeof(addr);
		int new_socket;

		new_socket = accept(*sock, (struct sockaddr *)&addr,
					 (socklen_t *)&addrlen);
		if (new_socket < 0) {
			perror("accept");
			return false;
		}

		if (fork() == 0) {
			new_connection(new_socket);
			exit(0);
		} else {
			close(new_socket);
		}
	}

	return true;
}

bool new_connection(int sock)
{
	/*
	 * Handle new connection
	 */

	char buff[1028] = {'\0'};

	size_t bytes_read;

	struct sockaddr_in client = {0};
	socklen_t len = sizeof(client);

	// get client data
	getpeername(sock, &client, &len);

	// read request
	bytes_read = read(sock, buff, sizeof(buff));

	// log request
	log_data(buff, &client, true);

	if (bytes_read == 0) {
		return false;
	}

	// check if valid request
	int result = request_validate(buff);

	char *file_path = buff;

	// handle request
	switch (result) {
	case OK:
		file_path++;
		serve_request(sock, file_path);
		break;
	case BADREQUEST:
		bad_request(sock);
		break;
	case FORBIDDEN:
		forbidden(sock);
		break;
	case NOTFOUND:
		not_found(sock);
		break;
	case METHODNOTALLOWED:
		method_not_allowed(sock);
		break;
	case INTERNALERROR:
		internal_error(sock);
		break;
	}

	return true;
}

void log_data(char *data, struct sockaddr_in *client, bool recv)
{
	/*
	 * Log transmission payload data
	 */

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	// array for ip from inet_ntop
	char ip[16] = {'\0'};

	char to[] = "To";
	char from[] = "From";

	char *to_from = to;

	if (recv) {
		to_from = from;
	}

	// open log
	openlog("ashti", LOG_PID | LOG_PERROR, LOG_USER);

	// log data
	syslog(LOG_INFO,
	       "%s - "
	       "%d-%02d-%02d %02d:%02d:%02d - "
	       "%s:%hu - "
	       "\"%s\"\n",
	       to_from, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
	       tm.tm_hour, tm.tm_min, tm.tm_sec,
	       inet_ntop(AF_INET, &client->sin_addr.s_addr, ip, sizeof(ip)),
	       htons(client->sin_port), data);

	// close log (catiscat)
	closelog();
}

void print_help(void)
{
	/*
	 * Print usage statement
	 */

	fprintf(stderr, "./ashti [dir_name]\n"
			"dir_name - directory containing"
			" www/ and cgi-bin/ sub-directories\n");
}
