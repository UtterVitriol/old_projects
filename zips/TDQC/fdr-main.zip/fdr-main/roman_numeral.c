#include "roman_numeral.h"
#include "dnum.h"

char *roman_to_dec(char *input, bool use_medieval, bool uppercase)
{
	/**
	 * Function takes in a char array of roman numerals and whether or
	 * not to use the medieval notation.
	 * The function returns the corresponding decimal value between
	 * 1 and 4000.
	 * If, for any reason, the passed char array is malformed, the
	 * function will return a -1 to indicate the issue.
	 */

	// define which char are valid
	char medieval[] = "IVXLCDMASZOFSRNYKTHEBPGQZ/";
	char not_medieval[] = "IVXLCDM/";
	char *valid_chars;
	if (use_medieval) {
		valid_chars = medieval;
	} else {
		valid_chars = not_medieval;
	}
	uint8_t length = strlen(input);

	// Convert all chars in the input to upper case
	char *romanNumeral = malloc(sizeof(input) * length);
	for (int i = 0; i < length; i++) {
		romanNumeral[i] = toupper(input[i]);
	}

	// test to ensure that all the passed chars are valid R.N.
	for (uint8_t i = 0; i < length; i++) {
		if (!isin(romanNumeral[i], valid_chars, '/')) {
			free(romanNumeral);
			return NULL;
		}
	}

	int total = 0;
	int8_t pos_neg; // used to add or subtract

	// convert from R.N. and place into total
	for (uint8_t i = 0; i < length; i++) {
		pos_neg = 1; // assume this digit will increase the total

		// if this is not the last digit and the current digit is less
		// than the next digit, the digit will decrease the total
		if (i + 1 != length && get_digit(romanNumeral[i]) <
					   get_digit(romanNumeral[i + 1])) {
			pos_neg = -1;
		}

		// get the dec. equivalent of the R.N. digit
		total += get_digit(romanNumeral[i]) * pos_neg;

		// break, if ever the total goes 10000 above the
		// max return value - not conclusive, but used for
		// an early exit
		if (total > MAX || total < -MAX) {
			free(romanNumeral);
			return NULL;
		}
	}

	// the total must be between 1 and 4000 (inclusive)
	if (total < 1 || total > 4000) {
		free(romanNumeral);
		return NULL;
	}

	free(romanNumeral);

	char *string = uint64_to_hex(total, uppercase);
	return string;
}

int16_t get_digit(char digit)
{
	/**
	 * Function returns the corresponding dec. value for a single passed
	 * Roman Numeral.
	 * If the char is not one of the accepted chars, it will return
	 * 10000, as this is far outside the range of what will be accepted
	 * by the calling funtion.
	 */

	switch (digit) {
	case 'I':
		return 1;
	case 'A': // fall through
	case 'V':
		return 5;
	// S and Z have multiple possible values - depending on which
	// medieval system is being used.
	// We use the lower values that relate to the latim 'septem'
	case 'S': // fall through
	case 'Z':
		return 7;
	case 'X':
		return 10;
	case 'O':
		return 11;
	case 'F':
		return 40;
	case 'L':
		return 50;
	case 'R':
		return 80;
	case 'N':
		return 90;
	case 'C':
		return 100;
	case 'Y':
		return 150;
	case 'K':
		return 151;
	case 'T':
		return 160;
	case 'H':
		return 200;
	case 'E':
		return 250;
	case 'B':
		return 300;
	case 'P': // fall through
	case 'G':
		return 400;
	case 'Q': // fall through
	case 'D':
		return 500;
	case 'M':
		return 1000;
	default:
		return MAX; // causes calling function to return error
	}
	return 10000; // same as above
}

bool isin(char tested, char *tester, char ending)
{
	/**
	 * Function takes in a char to test, a char array to test against,
	 * and the char which should be present at the end of the array
	 * which signals its termination.
	 * The function will return true if the first char is in the passed
	 * char array, and false otherwise.
	 */

	int cur = 0;
	// while we have reached the terminating char
	while (tester[cur] != ending) {
		// if found, return true
		if (tested == tester[cur]) {
			return true;
		}
		++cur;
	}

	// all the testing is done, and the char is not found,
	// so must be false
	return false;
}
