#include "dnum.h"
#include "roman_numeral.h"

char *uint64_to_hex(uint64_t num, bool flag)
{
	// Converts decimal number between 0 - 10^19 inclusive to hexadecimal
	// Returns as string on success, empty string otherwise

	char num_str[LIMIT] = {'\0'};
	int err = snprintf(num_str, LIMIT, "%" PRIu64, num);

	if (err < 0 || err > LIMIT) {
		fprintf(stderr, "Could not store number as string.\n");
		return NULL;
	}

	// Length of number including null terminator and '0x'
	size_t len = strlen(num_str) + 3;
	// Hex string should be no larger than size of num + '0x'
	char *buff = calloc(1, sizeof(char) * len);

	if (!buff) {
		fprintf(stderr, "Error allocating memory for buffer.\n");
		return NULL;
	}

	// Hex all caps if flag is on
	if (flag) {
		err = snprintf(buff, len, "0X%" PRIX64, num);
	} else {
		err = snprintf(buff, len, "0x%" PRIx64, num);
	}

	if (err < 0 || err > (int)len) {
		fprintf(stderr, "Could not store hex as string.\n");
		free(buff);
		return NULL;
	}
	return buff;
}

char *check_data(char *data, bool *flags)
{
	/* Validates udp payloads
	 * calls oppropriate processing functions
	 */

	// payload must be at least chars long
	// i.e; "f3", "rv", "d7"
	if ((int)strlen(data) < 2) {
		return NULL;
	}

	bool uppercase = true;

	// case matching check
	if (data[0] > 90 && flags[0]) {
		uppercase = false;
	}

	// get first, option, char
	char first = tolower(data[0]);

	// move pointer past option char
	data++;

	switch (first) {
	case 'd':
		return get_decimal(data, uppercase);
		break;
	case 'f':
		return get_fib(data, uppercase);
		break;
	case 'r':
		return roman_to_dec(data, flags[1], uppercase);
		break;
	default:
		return NULL;
	}

	return NULL;
}

char *get_decimal(char *input, bool uppercase)
{
	/*
	 * Converts decimal string to uint64_t
	 */

	// validate string is all digits
	for (int i = 0; i < (int)strlen(input); i++) {
		if (isdigit(input[i])) {
			continue;
		} else {
			return NULL;
		}
	}

	char *string = NULL;
	uint64_t number;

	// get number from string
	number = strtoull(input, &string, 10);

	// make sure string is within limits
	if (number > 10000000000000000000U) {
		return NULL;
	}

	string = uint64_to_hex(number, uppercase);

	return string;
}

char *get_fib(char *input, bool uppercase)
{
	/*
	 * Call assembly code function to get fib(n)
	 */

	// validate string is all digits
	for (int i = 0; i < (int)strlen(input); i++) {
		if (isdigit(input[i])) {
			continue;
		} else {
			return NULL;
		}
	}

	char *string = NULL;
	uint32_t number;

	// get number from string
	number = strtoul(input, &string, 10);

	// validate number is withing limits
	if (number > 300) {
		return NULL;
	}

	uint64_t big_fib[4];

	fast_fibonacci(number, big_fib);

	return fib_to_string(big_fib, uppercase);
}

char *fib_to_string(uint64_t *fib, bool uppercase)
{
	/*
	 * Convert uint64_t array to hex string
	 */

	char upper[] = "%lX";
	char lower[] = "%lx";

	char *format = lower;

	// check for case
	if (uppercase) {
		format = upper;
	}

	char *fib_str = NULL;

	// alloc char array
	fib_str = calloc(67, sizeof(*fib_str));

	if (!fib_str) {
		return NULL;
	}

	// add '0x' prefix
	fib_str[0] = '0';
	fib_str[1] = 'x';

	char *temp = fib_str;

	// walk past prefix
	temp += 2;

	int bytes_written;

	// create rest of string
	for (int i = 0; i < 4; i++) {
		if (fib[i] > 0) {
			bytes_written = snprintf(temp, 17, format, fib[i]);
			temp += bytes_written;
		}
	}

	// check for 0
	if (strcmp(fib_str, "0x") == 0) {
		fib_str[2] = '0';
	}

	return fib_str;
}