#ifndef DNUM_H
#define DNUM_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <inttypes.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#define LIMIT 20

char *uint64_to_hex(uint64_t num, bool flag);
char *check_data(char *data, bool *flags);
char *get_decimal(char *input, bool uppercase);
char *get_fib(char *input, bool uppercase);
extern int fast_fibonacci(int num, uint64_t *arr);
char *fib_to_string(uint64_t *fib, bool uppercase);

#endif