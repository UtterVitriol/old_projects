#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <syslog.h>

#include <time.h>

#include "roman_numeral.h"
#include "dnum.h"

bool setup_server(int *sockets);
bool setup_socket(int *sock, int port);
bool recv_data(int *sockets, bool *flags);
void close_server(int *sockets);
bool handle_args(int argc, char **argv, bool *flags);
void print_help(void);
void log_data(char *data, struct sockaddr_in *client, bool recv);

enum flags
{
	UPPERCASE = true,
	MEDIEVAL = true,
	ERROR = true
};

int main(int argc, char **argv)
{
	(void)argc;
	(void)argv;

	/*
	 * flags:
	 * [0] - UPPERCASE
	 * [1] - MEDIEVAL
	 * [2] - ERROR
	 */
	bool flags[3] = {false};

	if (!handle_args(argc, argv, flags)) {
		return 1;
	}

	int sockets[3] = {0};

	setup_server(sockets);
	recv_data(sockets, flags);
	close_server(sockets);
}

bool handle_args(int argc, char **argv, bool *flags)
{
	/* checks for args
	 * calls print_help if error
	 */

	int c;

	while ((c = getopt(argc, argv, "ier")) >= 0) {
		switch (c) {
		case 'i':
			flags[0] = UPPERCASE;
			break;
		case 'r':
			flags[1] = MEDIEVAL;
			break;
		case 'e':
			flags[2] = ERROR;
			break;
		default:
			print_help();
			return false;
		}
	}

	if (optind != argc) {
		print_help();
		return false;
	}

	return true;
}

bool setup_server(int *sockets)
{
	/* Loop through sockets array
	 * calls setup_socket
	 */

	// get user id
	int uid = getuid();

	// check if uid is too low
	// set uid to arbitrary 5000
	// so root permissions aren't required
	if (uid < 1024) {
		uid = 5000;
	}

	for (int i = 0; i < 3; i++) {
		// print port number
		// so user can easily tell
		printf("PORT: %d\n", uid);

		if (!setup_socket(&sockets[i], uid)) {
			return false;
		}

		// inc uid for requirement
		uid += 1000;
	}

	return true;
}

bool setup_socket(int *sock, int port)
{
	/* Courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up socket to listen for connections
	 */

	int opt = 1;
	int len = sizeof(len);
	struct sockaddr_in addr;

	// create socket
	if ((*sock = socket(AF_INET, SOCK_DGRAM, 0)) == 0) {
		perror("Socket creation failed");
		return false;
	}

	// set socket options
	if (setsockopt(*sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
		perror("Setsockopt");
		return false;
	}

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons(port);

	// bind socket to port
	if (bind(*sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("Bind failed");
		return false;
	}

	return true;
}

bool recv_data(int *sockets, bool *flags)
{
	/* Courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-in-cc-handling-multiple-clients-on-server-without-multi-threading/
	 * listen for incoming data
	 */

	int max_sd = 0;
	int activity = 0;
	char buff[1024] = {'\0'};
	fd_set readfds;

	struct sockaddr_in client = {0};
	socklen_t len = sizeof(client);

	char *reply = NULL;
	char err[] = "Error invalid request";

	for (;;) {

		// clear socket set
		FD_ZERO(&readfds);

		// add sockets to set
		for (int i = 0; i < 3; i++) {
			FD_SET(sockets[i], &readfds);

			if (sockets[i] > max_sd) {
				max_sd = sockets[i];
			}
		}

		// wait for activity
		activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);

		// check for select error
		if ((activity < 0) && (errno != EINTR)) {
			fprintf(stderr, "select error\n");
		}

		// loop through sockets
		for (int i = 0; i < 3; i++) {
			int sd = sockets[i];

			if (FD_ISSET(sd, &readfds)) {

				// read data
				recvfrom(sd, buff, sizeof(buff) - 1,
					 MSG_WAITALL,
					 (struct sockaddr *)&client, &len);

				log_data(buff, &client, true);

				// process data
				reply = check_data(buff, flags);

				// reset buffer
				memset(buff, '\0', sizeof(buff));

				// check for error
				if (!reply) {
					if (flags[2]) {
						log_data(err, &client, false);
						sendto(sd, err, strlen(err) + 1,
						       MSG_CONFIRM,
						       (const struct sockaddr
							    *)&client,
						       len);
					}
					continue;
				}

				log_data(reply, &client, false);

				// send reply
				sendto(sd, reply, strlen(reply) + 1,
				       MSG_CONFIRM,
				       (const struct sockaddr *)&client, len);

				// free reply
				if (reply) {
					free(reply);
				}
			}
		}
	}

	return true;
}

void log_data(char *data, struct sockaddr_in *client, bool recv)
{
	/*
	 * Log transmission payload data
	 */

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	// array for ip from inet_ntop
	char ip[16] = {'\0'};

	char to[] = "To";
	char from[] = "From";

	char *to_from = to;

	if (recv) {
		to_from = from;
	}

	// open log
	openlog("fdr", LOG_PID | LOG_PERROR, LOG_USER);

	// log data
	syslog(LOG_INFO,
	       "%s - "
	       "%d-%02d-%02d %02d:%02d:%02d - "
	       "%s:%hu - "
	       "\"%s\"\n",
	       to_from, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
	       tm.tm_hour, tm.tm_min, tm.tm_sec,
	       inet_ntop(AF_INET, &client->sin_addr.s_addr, ip, sizeof(ip)),
	       htons(client->sin_port), data);

	// close log (catiscat)
	closelog();
}

void close_server(int *sockets)
{
	// close sockets

	for (int i = 0; i < 3; i++) {
		close(sockets[i]);
	}
}

void print_help(void)
{
	// usage statement

	fprintf(stderr, "Usage: ./fdr [eir]\n"
			"e: Send Error Messages\n"
			"i: Case Matching\n"
			"r: Support Medieval Roman Numerals.\n");
}