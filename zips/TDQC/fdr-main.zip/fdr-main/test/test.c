#include <check.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#include "../roman_numeral.h"
#include "../dnum.h"

START_TEST(test_next_roman_dec)
{
	char four[] = "iv";
	char fourteen[] = "xiv";
	char *result = NULL;

	result = roman_to_dec(four, false, false);

	ck_assert(strcmp(result, "0x4") == 0);
	free(result);

	result = roman_to_dec(fourteen, false, false);
	ck_assert(strcmp(result, "0xe") == 0);
	free(result);
}
END_TEST

START_TEST(test_next_roman_dec_upper)
{
	char four[] = "iv";
	char fourteen[] = "xiv";
	char *result = NULL;

	result = roman_to_dec(four, false, true);

	ck_assert(strcmp(result, "0X4") == 0);
	free(result);

	result = roman_to_dec(fourteen, false, true);
	ck_assert(strcmp(result, "0XE") == 0);
	free(result);
}
END_TEST

START_TEST(test_next_roman_dec_medieval)
{
	char nineninefive[] = "add";
	char eightninethree[] = "zqg";
	char *result = NULL;

	result = roman_to_dec(nineninefive, true, true);

	ck_assert(strcmp(result, "0X3E3") == 0);
	free(result);

	result = roman_to_dec(eightninethree, true, true);
	ck_assert(strcmp(result, "0X37D") == 0);
	free(result);
}
END_TEST

START_TEST(test_uint64_to_hex_good)
{
	uint64_t test_num = UINT64_MAX;
	char *result = uint64_to_hex(test_num, true);
	ck_assert(strcmp(result, "0XFFFFFFFFFFFFFFFF") == 0);

	result = uint64_to_hex(test_num, false);
	ck_assert(strcmp(result, "0xffffffffffffffff") == 0);
	free(result);
}
END_TEST

START_TEST(test_check_data)
{
	char nineninefive[] = "Radd";
	char eightninethree[] = "Rzqg";
	char four[] = "riv";
	char fourteen[] = "rxiv";
	char *result = NULL;
	bool flags[3] = {true, true, true};

	result = check_data(four, flags);
	ck_assert(strcmp(result, "0x4") == 0);
	free(result);

	result = check_data(fourteen, flags);
	ck_assert(strcmp(result, "0xe") == 0);
	free(result);

	result = check_data(nineninefive, flags);
	ck_assert(strcmp(result, "0X3E3") == 0);
	free(result);

	result = check_data(eightninethree, flags);
	ck_assert(strcmp(result, "0X37D") == 0);
}
END_TEST

START_TEST(test_get_decimal_good)
{
	char input[] = "BAD STRING";
	char *result = get_decimal(input, false);
	ck_assert_ptr_eq(result, NULL);

	char input2[] = "30";
	result = get_decimal(input2, false);
	ck_assert(strcmp(result, "0x1e") == 0);

	result = get_decimal(input2, true);
	ck_assert(strcmp(result, "0X1E") == 0);
	free(result);
}
END_TEST

static TFun core_tests[] = {test_next_roman_dec,
			    test_next_roman_dec_upper,
			    test_next_roman_dec_medieval,
			    test_uint64_to_hex_good,
			    test_check_data,
			    test_get_decimal_good,
			    NULL};

Suite *suite_fdr(void)
{
	Suite *s = suite_create("fdr");

	TCase *tc = tcase_create("Core");
	TFun *curr = core_tests;
	while (*curr) {
		tcase_add_test(tc, *curr++);
	}

	suite_add_tcase(s, tc);

	return s;
}
