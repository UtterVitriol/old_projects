#ifndef FDR_ROMAN_NUMERAL_TO_DEC
#define FDR_ROMAN_NUMERAL_TO_DEC
/**
 * This header is intended to be used in the FDR project, and converts
 * Roman Numerals (optionally using the medieval notation) to
 * decimal numbers, not exceeding 4000 or below 1.
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <stdlib.h>

// Prototypes
bool isin(char tested, char *tester, char ending);
char *roman_to_dec(char *input, bool use_medieval, bool uppercase);
int16_t get_digit(char digit);

// default break value
#define MAX 10000
#endif
