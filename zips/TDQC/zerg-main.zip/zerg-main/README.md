# zerg

decode.c is a pcap decoder, decoding zerg pcaps and displaying pertinent information in a human readable format
encode.c is a pcap encoder, encoding zer pcaps from the same user readable format that is displayed by decode.c

## Installation

Clone or download

```bash
git clone "link"
```

## Usage

```bash
./decode [filename.pcap...]

./encode [-6bh] [description_file] [out_filename.pcap]

encode.c makes ipv4 packets by default
-6 make ipv6 packets
-b make pcap big endian
-h display help
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MEMES](https://www.youtube.com/watch?v=dQw4w9WgXcQ)
