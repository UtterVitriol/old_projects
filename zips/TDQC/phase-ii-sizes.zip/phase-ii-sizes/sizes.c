#include <limits.h>
#include <stdint.h>
#include <stdio.h>

union {
	uint16_t value;
	uint8_t bytes[2];
} endian;

int main(void)
{
	endian.value = 0x0102;
	if (endian.bytes[0] == 0x01) {
		puts("Big-Endian");
	} else {
		puts("Little-Endian");
	}

	// sizeof() always returns a type of size_t
	// %zu is a format for size_t
	printf("   CHAR_BIT: %u\n", CHAR_BIT);
	printf("      short: %zu\n", sizeof(short));
	printf("        int: %zu\n", sizeof(int));
	printf("       long: %zu\n", sizeof(long));
	printf("  long long: %zu\n", sizeof(long long));
	printf("     size_t: %zu\n", sizeof(size_t));
	printf("long double: %zu\n", sizeof(long double));
	printf("     void *: %zu\n", sizeof(void *));



}
