// I know I don't validate for whitespace.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include <ctype.h>

#include <wchar.h>
#include <locale.h>
#include <wctype.h>

void print_usage(void);
FILE *open_file(char *filename);
int read_file(wchar_t **sequence, FILE *fp);
int get_input(wchar_t **sequence, FILE *fp);
bool check_sequence(wchar_t *sequence);
bool check_split(wchar_t *first, wchar_t *second);
size_t check_unique(wchar_t *sequence);

int main(int argc, char **argv)
{
	setlocale(LC_ALL, "");

	FILE *fp = NULL;
	wchar_t *sequence = NULL;

	int err;
	int (*get_word)(wchar_t **sequence, FILE * fp);

	if (argc > 2) {
		// too many args
		print_usage();
		return 1;
	} else if (argc == 2) {
		// open the file
		if (!(fp = open_file(argv[1]))) {
			return 1;
		}

		// set function pointer
		get_word = read_file;
	} else {
		// set function pointer
		get_word = get_input;
	}

	while (true) {
		while ((err = get_word(&sequence, fp)) != 0) {

			// check if non-closing error
			if (err != 3) {
				if (fp) {
					fclose(fp);
				}
			}

			// check if error or quit
			if (err == 1) {
				return 1;
			} else if (err == 2) {
				return 0;
			}
		}

		if (!check_sequence(sequence)) {
			if (fp) {
				fclose(fp);
			}
			return 1;
		}

		free(sequence);
		sequence = NULL;
	}

	if (fp) {
		fclose(fp);
	}
}

FILE *open_file(char *filename)
{
	/*
	 * Open the file
	 */

	FILE *fp = NULL;

	fp = fopen(filename, "r");

	if (!fp) {
		// oops
		char *msg = strerror(errno);
		fprintf(stderr, "\nSomething went wrong: %s\n", msg);
		return NULL;
	}

	return fp;
}

int read_file(wchar_t **sequence, FILE *fp)
{
	// get line from file

	size_t size = 0;
	int word_len = 0;
	char *temp = NULL;

	if ((word_len = getline(&temp, &size, fp)) == -1) {
		// getline error

		if (temp) {
			free(temp);
		}

		if (feof(fp)) {
			return 2;
		}

		fprintf(stderr, "Out of memory.\n");
		return 1;
	}

	// number of bytes in string
	int bytes = strlen(temp);

	// alloc wchar
	*sequence = calloc(bytes, sizeof(*sequence));

	// this makes working with the double pointer easier.. I guess
	wchar_t *word = *sequence;

	// copy wchar bytes from char
	swprintf(word, bytes, L"%s", temp);

	free(temp);

	wchar_t *newline = NULL;

	// check for newline
	newline = wcschr(word, L'\n');

	// remove that sucker
	if (newline) {
		*newline = L'\0';
	}

	word_len--;

	// validate sequence length is at least 2
	if (word_len < 2) {
		free(word);
		puts("Sequence must be at least 2 characters long.");
		return 3;
	}

	return 0;
}

int get_input(wchar_t **sequence, FILE *fp)
{
	// get sequence from user

	(void)fp;

	size_t size = 0;
	int word_len = 0;
	char *temp = NULL;

	puts("Q to quit.");
	printf("Enter a sequence: ");

	if ((word_len = getline(&temp, &size, stdin)) == -1) {
		// getline error
		if (feof(stdin)) {
			puts("");
			return 2;
		}

		char *msg = strerror(errno);
		fprintf(stderr, "\nSomething went wrong: %s\n", msg);

		return 1;
	}

	// alloc wchar
	*sequence = calloc(strlen(temp), sizeof(*sequence));

	// this makes working with the double pointer easier.. I guess
	wchar_t *word = *sequence;

	// copy wchar bytes from char
	swprintf(word, strlen(temp), L"%s", temp);

	free(temp);

	wchar_t *newline = NULL;

	// check for newline
	newline = wcschr(word, L'\n');

	// remove that sucker
	if (newline) {
		*newline = L'\0';
	}

	word_len--;

	// validate sequence length is at least 2
	if (word_len < 2) {
		if (towlower(word[0]) == 'q') {
			puts("Goodbye.");
			free(word);
			return 2;
		}
		free(word);
		puts("Sequence must be at least 2 characters long.");
		return 3;
	}

	return 0;
}

bool check_sequence(wchar_t *sequence)
{
	// splits sequence to check if valid

	if (!sequence) {
		// see below
		puts("oops");
		return false;
	}

	bool has_split = false;
	size_t count = 1;
	wchar_t *first;
	wchar_t *second = sequence;

	printf("%ls:", sequence);

	while (*second) {
		second++;
		count++;

		// alloc first
		first = calloc(wcslen(sequence), sizeof(first));

		// copy count num of wchar's from sequence to first
		swprintf(first, count, L"%ls", sequence);

		if (!first) {
			fprintf(stderr, "Out of memory.\n");
			return false;
		}

		if (check_split(first, second)) {
			printf(" %ls,%ls ", first, second);
			has_split = true;
		}

		free(first);
	}

	if (!has_split) {
		puts(" None");
	} else {
		puts("");
	}

	return true;
}

bool check_split(wchar_t *first, wchar_t *second)
{
	// calls check_unique twice

	size_t result1 = check_unique(first);
	size_t result2 = check_unique(second);

	if (result1 != result2) {
		return false;
	}

	return true;
}

size_t check_unique(wchar_t *sequence)
{
	// gets unique number of wchar's from sequence

	wchar_t *in_seq = NULL;

	// alloc in_seq
	in_seq = calloc(wcslen(sequence) + 1, sizeof(*in_seq));

	if (!in_seq) {
		// out of memory
		puts("OOM");
		// No
		exit(1);
	}

	size_t count = 0;

	// this is probably really slow
	for (size_t i = 0; i < wcslen(sequence); i++) {
		if (!wcschr(in_seq, sequence[i])) {
			in_seq[count] = sequence[i];
			count++;
		}
	}

	size_t result = wcslen(in_seq);
	free(in_seq);
	return result;
}

void print_usage(void)
{
	// see below
	puts("Usage: ./splitter [file]");
}