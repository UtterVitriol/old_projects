# guess

guess is a Python library that let's you play the guess game.

## Installation

Clone or Download

```bash
git clone "link"
```

## Usage

```python
import guess

foo = guess.Game()
foo.start()
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## Memes
[Memes](https://reddit.com/r/programminghumor)
