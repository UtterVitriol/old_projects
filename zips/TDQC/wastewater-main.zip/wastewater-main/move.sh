cp -r Makefile compound.c compound.h detection.c detection.h structs.h wwater_serv.c wwater_serv.h is_it_poop.c is_it_poop.h residential/
cp -r Makefile compound.c compound.h detection.c detection.h structs.h wwater_serv.c wwater_serv.h is_it_poop.c is_it_poop.h stormdrain/
cp -r Makefile compound.c compound.h detection.c detection.h structs.h wwater_serv.c wwater_serv.h is_it_poop.c is_it_poop.h treatment/
cp -r Makefile compound.c compound.h detection.c detection.h structs.h wwater_serv.c wwater_serv.h is_it_poop.c is_it_poop.h testing/
