#ifndef COMPOUND_H
#define COMPOUND_H

#include <stdio.h>
#include <stdlib.h>

#include "structs.h"

void compounder(struct node *molecules, size_t len, struct contaminants *cont);

void child_linker(struct node *down, size_t *label, size_t counter, size_t len,
		  size_t x);
void parent_linker(struct node *molecules, size_t *label, size_t counter,
		   size_t len, size_t x);

void present_things(struct node *shifted, size_t *label, size_t len,
		    struct contaminants *cont);

void fuck_katen(struct node *punk, size_t *label, size_t len,
		struct contaminants *cont);

#endif