
Pretreatment

Industrial plants connect to this machine to dispose of hazardous wastes.
Right now it's just farms and farm runoff, since the town is pretty small.


There are literally hundreds of possible hazardous wastes, and they all have
to be treated in the right order.

Mercury is indicated by having a graph with multiple unreachable nodes.  The
lowest values are removed one at a time to remove the mercury.

Lead used to be indicated by cyclic graphs, but apparently Liam changed
it now so it has been taken out.

Selenium is indicated by having a circularly-linked list.  The highest-value
node is removed to remove the Selenium.

Sewage and phosphates are handled at the main treatment plant, since it would
also get residential sewage.

