
#ifndef STRUCTS_H
#define STRUCTS_H

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

extern const char *salt;

struct node {
	uint32_t data;
	uint16_t left;
	uint16_t rite;
};

enum states
{
	AEROSOLE,
	LIQUID,
	SOLID
};

enum contaminant
{
	LEAD,
	FECES,
	AMMONIA,
	AIR,
	DEBRIS,
	CHLORINE
};

struct hash {
	uint8_t code[64];
};

struct sludge {
	size_t count;
	size_t slots;
	struct hash *hashes;
};

struct hazmat {
	size_t count;
	size_t slots;
	struct hz_container *hazmats;
};

struct hz_container {
	uint32_t data;
	uint32_t custom;
};

struct debris_cont {
	size_t count;
	size_t slots;
	struct node *debris;
};

struct contaminants {
	struct hazmat hazmat;
	struct sludge sludge;
	struct debris_cont debri;
};

struct compound {
	bool has_debri;
	int state;
	size_t count;
	size_t slots;
	struct node *molecules;
};

struct header {
	uint16_t type;
	uint16_t size;
	char custom[4];
};

struct liquid {
	struct header *header;
	struct node *nodes;
};

bool serialize(const struct node *n, const size_t nmemb, char *buf,
	       const size_t sz);

// N nodes will require N+1 0 values
// This will stop when a node is full; 0s at the end may be ommitted
struct liquid *deserialize(const char *buf, size_t *nmemb);

#endif
