#ifndef WWATER_SERV_H
#define WWATER_SERV_H

#include <stdio.h>
#include <netinet/in.h>

#include "structs.h"

bool setup_server(int *sock);
bool serve_forever(int *sock);
bool new_connection(int sock);
void log_data(char *data, struct sockaddr_in *client, bool recv);
bool send_data(struct header *head, struct node *arr, size_t items);

bool send_junk(struct compound *compound);
bool send_hazmats(struct contaminants *cont);
bool send_sludge(struct contaminants *cont);
bool send_debris(struct contaminants *cont);

void convert_to_host(struct node *arr, size_t len);
void convert_to_net(struct node *arr, size_t len);

#endif