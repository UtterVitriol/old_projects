#ifndef DETECTION_H
#define DETECTION_H

#include <stdint.h>

#include "structs.h"

void init_contaminants(struct contaminants *cont);
void print_molecule(struct node thing, int idx);
bool is_prime(uint32_t value);
bool is_undulating(uint32_t value);
void content_check(struct node check);

void state_check(struct compound *compound, struct contaminants *cont);
void detect_contaminants(struct compound *compound, int *indegrees,
			 size_t indegrees_zero, struct contaminants *cont);
bool detect_mercury(struct compound *compound, int *indegrees,
		    size_t indegrees_zero, struct contaminants *cont);
bool detect_lead(struct compound *compound, int *indegrees,
		 struct contaminants *cont);
bool detect_feces(struct compound *compound, struct contaminants *cont);
bool detect_ammon(struct compound *compound, struct contaminants *cont);
bool detect_debri(struct compound *compound, struct contaminants *cont);
void update_children(struct compound *compound, size_t waste);

void add_hazmat(struct contaminants *cont, uint32_t data);
void print_hazmats(struct contaminants *cont);

void add_sludge(struct contaminants *cont, uint32_t data);
void do_sludge(uint32_t data, uint8_t *buf);

void add_debri(struct contaminants *cont, struct node *debri);

#endif