#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include <math.h>

#include "detection.h"
#include "structs.h"
#include "compound.h"
#include "wwater_serv.h"

void print_molecule(struct node thing, int idx)
{
	printf("Data: %u - %d\n", thing.data, idx);
	printf("Left: %u\n", thing.left);
	printf("Right: %u\n", thing.rite);
}

// bool is_prime(uint32_t value)
// {
// 	if (value < 2) {
// 		return false;
// 	} else if (value < 6 && value != 4) {
// 		return true;
// 	}
// 	if (value % 2 == 0 || value % 3 == 0) {
// 		return false;
// 	}
// 	uint32_t x = 5;
// 	while (x <= sqrt(value)) {
// 		if (value % x == 0 || value % (x + 2) == 0) {
// 			return false;
// 		}
// 		x += 6;
// 	}
// 	return true;
// }

// bool is_undulating(uint32_t value)
// {
// 	/* Returns 1 if value is undulating, and 0 if it's not
// 	 *
// 	 * 11 is a magic number used for the 1 + max number of digits
// 	 * uint32_t can support
// 	 */
// 	char *text = calloc(11, sizeof(char));
// 	size_t len = 0;
// 	size_t index = 1;
// 	bool inc = true;

// 	if (value < 10) {
// 		return true;
// 	}

// 	snprintf(text, 10, "%u", value);
// 	len = strlen(text);

// 	if (text[0] > text[1]) {
// 		inc = false;
// 	}

// 	while (text[index + 1] != '\0') {
// 		if (inc) {
// 			if (text[index] > text[index + 1]) {
// 				inc = !inc;
// 			} else {
// 				break;
// 			}
// 		} else {
// 			if (text[index] < text[index + 1]) {
// 				inc = !inc;
// 			} else {
// 				break;
// 			}
// 		}
// 		index++;
// 	}

// 	free(text);
// 	if (index + 1 == len) {
// 		return true;
// 	}
// 	return false;
// }

// void content_check(struct node check)
// {
// 	// Air Check (0)
// 	if (check.data == 0) {
// 		printf("It's air!\n");
// 		// Modify pointers
// 		// A: Lone Molecule: Discard
// 		// L: Optional: pointing to air molecule -> connect
// 		// corresponding air pointer S: pointing to air molecule -> set
// 		// to 0xFFFF
// 		return;
// 	}

// 	// Fecal Check (Prime)
// 	if (is_prime(check.data)) {
// 		printf("It's prime!\n");
// 		// A: Remove and sludge
// 		// L: pointing to fecal molecule -> connect corresponding
// 		// pointer S: pointing to fecal molecule -> connect
// 		// corresponding pointer
// 		return;
// 	}

// 	// Undulating Check (Non-prime)
// 	if (is_undulating(check.data)) {
// 		printf("It's undulating!\n");
// 		//
// 		return;
// 	}
// 	printf("Nothing special\n");
// }

void state_check(struct compound *compound, struct contaminants *cont)
{
	size_t len = compound->count;
	struct node *check = compound->molecules;

	int *indegrees = calloc(len + 1, sizeof(int));

	printf("Molecule count: %ld\n", compound->count);

	if (len == 1) {
		print_molecule(check[1], 1);
		puts("AIR\n");

		if (check[1].data == 0 && check[1].rite == 0 &&
		    check[1].left == 0) {
			return;
		}
		compound->state = AEROSOLE;

		detect_contaminants(compound, indegrees, 0, cont);

		return;
	}

	for (size_t x = 1; x < len + 1; x++) {
		print_molecule(check[x], x);

		if (check[x].left <= len && check[x].left > 0) {

			indegrees[check[x].left]++;
		}

		if (check[x].rite <= len && check[x].rite > 0 &&
		    check[x].rite != check[x].left) {
			indegrees[check[x].rite]++;
		}

		if (check[x].rite > len || check[x].left > len) {
			compound->has_debri = true;
		}
	}

	// solid has molecule with indegree of 2 or all molecules have indegree
	// > 0
	bool multiple_indegree = false;
	size_t indegrees_zero = 0;
	// DEBUG
	for (size_t x = 1; x < len + 1; x++) {
		if (indegrees[x] > 1) {
			multiple_indegree = true;
		}

		if (indegrees[x] == 0) {
			indegrees_zero++;
		}

		printf(" %d ", indegrees[x]);
	}

	// if (multiple_indegree || indegrees_zero != 1) {
	// 	compound->has_debri = false;
	// }

	if (multiple_indegree || indegrees_zero == 0 || compound->has_debri) {
		compound->state = SOLID;
		puts("Solid");
	} else {
		compound->state = LIQUID;
		puts("Liquid");
	}

	detect_contaminants(compound, indegrees, indegrees_zero, cont);

	puts("");

	free(indegrees);
}

void detect_contaminants(struct compound *compound, int *indegrees,
			 size_t indegrees_zero, struct contaminants *cont)
{
	switch (compound->state) {
	case AEROSOLE:
		break;
	case LIQUID:
		break;
	case SOLID:
		if (detect_lead(compound, indegrees, cont)) {
			compounder(compound->molecules, compound->count, cont);
			return;
		}

		break;
	}

	send_junk(compound);
}

bool detect_mercury(struct compound *compound, int *indegrees,
		    size_t indegrees_zero, struct contaminants *cont)
{
	/* Checks if molecule array contains lead.
	 * Returns 1 if lead was found, 0 if it wasn't
	 */

	size_t arr_len = compound->count;
	struct node *molecules = compound->molecules;

	if (arr_len == 1) {
		return false;
	}

	size_t mercury = INT32_MAX;

	for (size_t i = 1; i < arr_len + 1; i++) {
		if (indegrees[i] == 0) {
			if (mercury == 0) {
				mercury = i;
			} else if (molecules[i].data <
				   molecules[mercury].data) {
				mercury = i;
			}
		}
	}

	add_hazmat(cont, compound->molecules[mercury].data);

	printf("idx: %d Lead: D: %u, LC: %d, RC: %d\n\n", mercury,
	       compound->molecules[mercury].data,
	       compound->molecules[mercury].left,
	       compound->molecules[mercury].rite);

	compound->molecules[mercury].data = 0;
	compound->molecules[mercury].left = 0;
	compound->molecules[mercury].rite = 0;

	return true;
}

bool detect_lead(struct compound *compound, int *indegrees,
		 struct contaminants *cont)
{
	/* Checks if molecule array contains lead.
	 * Returns 1 if lead was found, 0 if it wasn't
	 */

	size_t arr_len = compound->count;

	if (arr_len == 1) {
		return false;
	}

	size_t indegrees_zero = 0;
	size_t lead_idx = INT32_MAX;

	for (size_t i = 1; i < arr_len + 1; i++) {
		if (indegrees[i] == 0) {
			lead_idx = i;
			indegrees_zero++;
		}
	}

	if (indegrees_zero != 1) {
		return false;
	}

	// if (compound->molecules[lead_idx].data == 0) {
	// 	printf("This is lead air -> D: 0 LC: %d - RC: %d\n",
	// 	       compound->molecules[lead_idx].left,
	// 	       compound->molecules[lead_idx].rite);
	// 	return false;
	// }

	add_hazmat(cont, compound->molecules[lead_idx].data);

	printf("idx: %d Lead: D: %u, LC: %d, RC: %d\n\n", lead_idx,
	       compound->molecules[lead_idx].data,
	       compound->molecules[lead_idx].left,
	       compound->molecules[lead_idx].rite);

	compound->molecules[lead_idx].data = 0;
	compound->molecules[lead_idx].left = 0;
	compound->molecules[lead_idx].rite = 0;

	return true;
}

// bool detect_feces(struct compound *compound, struct contaminants *cont)
// {
// 	size_t prime_idx = 0;

// 	struct node *molecules = compound->molecules;

// 	printf("checking primes\n");
// 	for (size_t i = 1; i < compound->count + 1; i++) {
// 		if (is_prime(molecules[i].data)) {
// 			prime_idx = i;
// 			printf("Feces: %lu\n", i);
// 			break;
// 		}
// 	}
// 	printf("done checking primes\n");

// 	if (prime_idx == 0) {
// 		return false;
// 	}

// 	printf("sluding and updated children\n");
// 	add_sludge(cont, molecules[prime_idx].data);
// 	update_children(compound, prime_idx);
// 	printf("done sluding and updated children\n");

// 	return true;
// }

// bool detect_ammon(struct compound *compound, struct contaminants *cont)
// {
// 	size_t weaku_idx = 0;

// 	struct node *molecules = compound->molecules;

// 	printf("checking undulation\n");
// 	for (size_t i = 1; i < compound->count + 1; i++) {
// 		if (is_undulating(molecules[i].data)) {
// 			weaku_idx = i;
// 			printf("Ammonia: %lu\n", i);
// 			break;
// 		}
// 	}
// 	printf("done checking undulation\n");

// 	if (weaku_idx == 0) {
// 		return false;
// 	}

// 	printf("sluding and updated children\n");
// 	add_sludge(cont, molecules[weaku_idx].data);
// 	update_children(compound, weaku_idx);
// 	printf("done sluding and updated children\n");

// 	return true;
// }

// bool detect_debri(struct compound *compound, struct contaminants *cont)
// {
// 	size_t len = compound->count;

// 	for (size_t i = 1; i < len + 1; i++) {
// 		if (compound->molecules[i].rite > len ||
// 		    compound->molecules[i].left > len) {
// 			puts("Debris here\n");

// 			if (compound->molecules[i].left > len) {
// 				compound->molecules[i].left = 0xffff;
// 			}

// 			if (compound->molecules[i].rite > len) {
// 				compound->molecules[i].rite = 0xffff;
// 			}

// 			add_debri(cont, &compound->molecules[i]);
// 			update_children(compound, i);
// 			return true;
// 		}
// 	}

// 	return false;
// }

// void update_children(struct compound *compound, size_t waste)
// {
// 	uint8_t left, rite;

// 	left = compound->molecules[waste].left;
// 	rite = compound->molecules[waste].rite;

// 	for (size_t i = 1; i < compound->count + 1; i++) {
// 		if (i == waste) {
// 			compound->molecules[i].data = 0;
// 			compound->molecules[i].left = 0;
// 			compound->molecules[i].rite = 0;
// 			continue;
// 		}

// 		if (compound->molecules[i].left == waste) {
// 			compound->molecules[i].left = left;
// 		}

// 		if (compound->molecules[i].rite == waste) {
// 			compound->molecules[i].rite = rite;
// 		}
// 	}
// }

void init_contaminants(struct contaminants *cont)
{
	cont->hazmat.count = 0;
	cont->hazmat.slots = 1;
	cont->hazmat.hazmats = calloc(1, sizeof(*cont->hazmat.hazmats));

	cont->sludge.count = 0;
	cont->sludge.slots = 1;
	cont->sludge.hashes = calloc(1, sizeof(*cont->sludge.hashes));

	cont->debri.count = 0;
	cont->debri.slots = 1;
	cont->debri.debris = calloc(1, sizeof(*cont->debri.debris));
}

void add_hazmat(struct contaminants *cont, uint32_t data)
{
	cont->hazmat.hazmats[cont->hazmat.count].data = data;

	cont->hazmat.count++;
	cont->hazmat.slots++;

	if (cont->hazmat.hazmats) {
		cont->hazmat.hazmats =
		    realloc(cont->hazmat.hazmats,
			    cont->hazmat.slots * sizeof(*cont->hazmat.hazmats));
	}
}

// void do_sludge(uint32_t data, uint8_t *buf)
// {
// 	char input[16] = {'\0'};
// 	snprintf(input, sizeof(input), "%u", data);
// 	const char *salt = "I Hate Liam Echlin";
// 	libscrypt_scrypt((uint8_t *)input, strlen(input), (uint8_t *)salt,
// 			 strlen(salt), 2048, 4, 4, buf, 64);
// }

// void add_sludge(struct contaminants *cont, uint32_t data)
// {
// 	do_sludge(data, cont->sludge.hashes[cont->sludge.count].code);

// 	cont->sludge.count++;
// 	cont->sludge.slots++;

// 	if (cont->sludge.hashes) {
// 		cont->sludge.hashes =
// 		    realloc(cont->sludge.hashes,
// 			    cont->sludge.slots * sizeof(*cont->sludge.hashes));
// 	}
// }

// void add_debri(struct contaminants *cont, struct node *debri)
// {
// 	cont->debri.debris[cont->debri.count].data = debri->data;
// 	cont->debri.debris[cont->debri.count].left = debri->left;
// 	cont->debri.debris[cont->debri.count].rite = debri->rite;

// 	cont->debri.count++;
// 	cont->debri.slots++;

// 	if (cont->debri.debris) {
// 		cont->debri.debris =
// 		    realloc(cont->debri.debris,
// 			    cont->debri.slots * sizeof(*cont->debri.debris));
// 	}
// }

void print_hazmats(struct contaminants *cont)
{
	for (size_t i = 0; i < cont->hazmat.count; i++) {
		printf("Cont: %d\n", cont->hazmat.hazmats[i].data);
	}
}