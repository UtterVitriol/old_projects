
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <errno.h>

void extract_ip_string(struct sockaddr *address, char *dst);

int main(int argc, char *argv[])
{

	int in, out, from;
	struct sockaddr_in down, me;
	void *buffer;
	int size;

	out = socket(AF_INET, SOCK_STREAM, 0);
	in = socket(AF_INET, SOCK_STREAM, 0);

	me.sin_family = AF_INET;
	me.sin_port = htons(1111);
	inet_aton(gethostbyname("localhost")->h_addr_list[0], &me.sin_addr);

	down.sin_family = AF_INET;
	down.sin_port = htons(1111);
	inet_aton(gethostbyname("downstream")->h_addr_list[0], &down.sin_addr);

	size_t addrlen = sizeof(down);

	int opt = 1;

	// set socket options
	if (setsockopt(in, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
		perror("Setsockopt");
		return 1;
	}

	if (bind(in, (struct sockaddr *)&me, sizeof(me)) < 0) {
		perror("Bind Failed");
		return 1;
	}

	char ip_as_str[30] = {'\0'};
	while (1) {
		from = accept(in, (sockaddr *)&me, (socklen_t *)&addrlen);

		sockaddr client = {0};
		socklen_t len = sizeof(client);

		getpeername(from, &client, &len);

		buffer = calloc(1, 65536);

		size = recvfrom(from, buffer, 65536, 0, NULL, NULL);

		extract_ip_string(&client, ip_as_str);

		openlog("pretreatment", LOG_PID | LOG_PERROR, LOG_USER);
		syslog(LOG_INFO, "%s is raining", ip_as_str);
		closelog();

		sendto(out, buffer, size, 0, NULL, 0);
	}
}

void extract_ip_string(struct sockaddr *address, char *dst)
{
	void *addr;

	if (address->sa_family == AF_INET) {
		// IPv6 Land
		addr = &((struct sockaddr_in6 *)address)->sin6_addr;
	} else {
		// IPv4 Land
		addr = &(((struct sockaddr_in *)address)->sin_addr);
	}
	inet_ntop(address->sa_family, addr, dst, sizeof(*address));
}
