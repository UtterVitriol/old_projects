
#include "deseeder.h"

#include <stdio.h>

int main(int argc, char *argv[])
{
	struct molecule stuff[] = {
		{ 55, 0, 0 },
		{ 55, 0, 0 },
		{ 24024, 0, 0 },
		{ 91, 0, 0 },
		{ 12012, 0, 0 }
	};

	int amount = deseeder(stuff, 5);

	printf("Removed %d\n", amount);
}
