#include <stdio.h>
#include <stdlib.h>

#include "structs.h"
#include "is_it_poop.h"

void make_data(struct node *arr, size_t len);

int main(void)
{
	struct node *arr = calloc(14, sizeof(arr));
	size_t len = 13;

		free(arr);
}

void make_data(struct node *arr, size_t len)
{
	arr[1].data = 0;
	arr[1].left = 0;
	arr[1].rite = 0;

	arr[2].data = 36155;
	arr[2].left = 2;
	arr[2].rite = 0;

	arr[3].data = 39481;
	arr[3].left = 0;
	arr[3].rite = 0;

	arr[4].data = 29824;
	arr[4].left = 0;
	arr[4].rite = 13;

	arr[5].data = 39626;
	arr[5].left = 13;
	arr[5].rite = 3;

	arr[6].data = 46338;
	arr[6].left = 4;
	arr[6].rite = 4;

	arr[7].data = 37643;
	arr[7].left = 8;
	arr[7].rite = 0;

	arr[8].data = 0;
	arr[8].left = 0;
	arr[8].rite = 0;

	arr[9].data = 53353;
	arr[9].left = 5;
	arr[9].rite = 0;

	arr[10].data = 38429;
	arr[10].left = 0;
	arr[10].rite = 1;

	arr[11].data = 0;
	arr[11].left = 0;
	arr[11].rite = 0;

	arr[12].data = 11716;
	arr[12].left = 220;
	arr[12].rite = 0;

	arr[13].data = 0;
	arr[13].left = 0;
	arr[13].rite = 0;
}