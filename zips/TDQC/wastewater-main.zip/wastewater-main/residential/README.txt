
Liam says Im supposed to write lots of comments so ppl know whats
going on.  So I made sure to comment every single line.

This is residenistial plant.  So ppl connect their home sewer lines
on port 1111 (general liqiud) and we preprocess the poo water before
sending it along.

Sometimes ppl flush trash like tampons and watches and things that dont
dissolve so we just send it on to trash directly lol.

To make it easy we flush poo or pee a single datum at a time.  The rest
of the water gets sent to the treatment plant for clhorination.

Checking for pee or poo seems to work just fine when i tried it on my
local box.

I added in the pee handling, some old guy wrote the poo handling im
not sure what they did exatcly lol.

You start the program with the almost last ovtet of your IP,
like if your IP is 10.0.42.66

./residential 42
