#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <netdb.h>

#include <syslog.h>
#include <time.h>

#include "wwater_serv.h"
#include "structs.h"
#include "is_it_poop.h"
#include "compound.h"

int main(int argc, char **argv)
{
	(void)argc;
	(void)argv;
	// List port will always be 1111

	int sock;

	if (!setup_server(&sock)) {
		return 1;
	}

	serve_forever(&sock);
}

bool setup_server(int *sock)
{
	/* Socket code courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up server to listen for connections
	 */

	int opt = 1;
	int len = sizeof(len);

	// create socket
	*sock = socket(AF_INET, SOCK_STREAM, 0);
	if (*sock == 0) {
		perror("Socket creation failed");
		return false;
	}

	// set socket options
	if (setsockopt(*sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
		perror("Setsockopt");
		return false;
	}

	struct sockaddr_in addr;

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons(1111);

	// bind socket to port
	if (bind(*sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("Bind failed");
		return false;
	}

	// listen for connections
	if (listen(*sock, 5) < 0) {
		perror("Listen failed");
		return false;
	}

	return true;
}

bool serve_forever(int *sock)
{
	/*
	 * Accept new connections
	 * Fork on new connection
	 */
	for (;;) {
		struct sockaddr_in addr;
		size_t addrlen = sizeof(addr);
		int new_socket;

		new_socket = accept(*sock, (struct sockaddr *)&addr,
				    (socklen_t *)&addrlen);
		if (new_socket < 0) {
			perror("accept");
			return false;
		}

		if (fork() == 0) {
			new_connection(new_socket);
			exit(0);
		} else {
			close(new_socket);
		}
	}

	return true;
}

bool new_connection(int sock)
{
	/*
	 * Handle new connection
	 */

	struct sockaddr_in client = {0};
	socklen_t len = sizeof(client);

	// get client data
	getpeername(sock, (struct sockaddr *)&client, &len);

	create_array(sock);

	close(sock);

	return true;
}

bool send_data(struct header *head, struct node *arr, size_t items)
{
	/* Courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up socket and connect to dispatcher
	 */

	int sock;
	struct sockaddr_in serv_addr;

	// create socket
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, "\nSocket creation error\n");
		return false;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(1111);

	struct hostent *he = NULL;

	he = gethostbyname("downstream");

	// convert ip
	if (inet_pton(AF_INET, inet_ntoa(**(struct in_addr **)he->h_addr_list),
		      &serv_addr.sin_addr) <= 0) {
		fprintf(stderr,
			"\nInvalid address or Address not supported \n");
		return false;
	}

	// connect to server
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) <
	    0) {
		fprintf(stderr, "\nConnection failed\n");
		return false;
	}

	printf("SENDING TO Downstream\n\n");

	// log_data("", &serv_addr, false);

	if (send(sock, head, sizeof(*head), 0) == -1) {
		fprintf(stderr, "bad send: head\n");
		return false;
	}

	struct node *temp = arr;
	temp++;

	printf("Items: %lu\n", items);

	if (send(sock, temp, items * sizeof(*arr), 0) == -1) {
		fprintf(stderr, "bad send: molecules\n");
		return false;
	}

	close(sock);

	return true;
}

void log_data(char *data, struct sockaddr_in *client, bool recv)
{
	/*
	 * Log transmission payload data
	 */

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	// array for ip from inet_ntop
	char ip[16] = {'\0'};

	char to[] = "To";
	char from[] = "From";

	char *to_from = to;

	if (recv) {
		to_from = from;
	}

	// open log
	openlog("server", LOG_PID | LOG_PERROR, LOG_USER);

	// log data
	syslog(LOG_INFO,
	       "%s - "
	       "%d-%02d-%02d %02d:%02d:%02d - "
	       "%s:%hu - "
	       "\"%s\"\n",
	       to_from, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
	       tm.tm_hour, tm.tm_min, tm.tm_sec,
	       inet_ntop(AF_INET, &client->sin_addr.s_addr, ip, sizeof(ip)),
	       htons(client->sin_port), data);

	// close log (catiscat)
	closelog();
}

bool send_junk(struct compound *compound)
{
	/* Courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up socket and connect to dispatcher
	 */

	int sock;
	struct sockaddr_in serv_addr;

	// create socket
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, "\nSocket creation error\n");
		return false;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(1111);

	struct hostent *he = NULL;

	he = gethostbyname("downstream");

	// convert ip
	if (inet_pton(AF_INET, inet_ntoa(**(struct in_addr **)he->h_addr_list),
		      &serv_addr.sin_addr) <= 0) {
		fprintf(stderr,
			"\nInvalid address or Address not supported \n");
		return false;
	}

	// connect to server
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) <
	    0) {
		fprintf(stderr, "\nConnection failed\n");
		return false;
	}

	printf("SENDING TO downstream junk\n\n");

	// log_data("", &serv_addr, false);

	struct header head = {0};
	head.type = htons(0);
	head.size = htons(sizeof(head) +
			  (compound->count * sizeof(*compound->molecules)));

	if (send(sock, &head, sizeof(head), 0) == -1) {
		fprintf(stderr, "bad send: head\n");
		return false;
	}

	convert_to_net(compound->molecules, compound->count);

	struct node *temp = compound->molecules;
	temp++;

	if (send(sock, temp, compound->count * sizeof(*compound->molecules),
		 0) == -1) {
		fprintf(stderr, "bad send: molecules\n");
		return false;
	}

	close(sock);

	return true;
}

bool send_hazmats(struct contaminants *cont)
{
	/* Courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up socket and connect to dispatcher
	 */

	if (cont->hazmat.count < 1) {
		return false;
	}

	int sock;
	struct sockaddr_in serv_addr;

	// create socket
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, "\nSocket creation error\n");
		return false;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(8888);

	struct hostent *he = NULL;

	he = gethostbyname("downstream");

	// convert ip
	if (inet_pton(AF_INET, inet_ntoa(**(struct in_addr **)he->h_addr_list),
		      &serv_addr.sin_addr) <= 0) {
		fprintf(stderr,
			"\nInvalid address or Address not supported \n");
		return false;
	}

	// connect to server
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) <
	    0) {
		fprintf(stderr, "\nConnection failed\n");
		return false;
	}

	// log_data("", &serv_addr, false);

	struct header head = {0};

	head.type = htons(4);
	head.size = htons(8 * (cont->hazmat.count + 1));

	for (size_t i = 0; i < cont->hazmat.count; i++) {
		cont->hazmat.hazmats[i].data =
		    htonl(cont->hazmat.hazmats[i].data);
	}

	printf("SENDING TO Downstream hazmat\n\n");

	int bytes_sent = 0;

	if ((bytes_sent = send(sock, &head, sizeof(head), 0)) == -1) {
		fprintf(stderr, "bad send: head\n");
		return false;
	}

	if (bytes_sent != sizeof(head)) {
		fprintf(stderr, "Headsize mismatch\n");
	}

	bytes_sent = 0;

	if ((bytes_sent = send(sock, cont->hazmat.hazmats,
			       8 * cont->hazmat.count, 0)) == -1) {
		fprintf(stderr, "bad send: molecules\n");
		return false;
	}

	if (bytes_sent != 8 * (int)cont->hazmat.count) {
		fprintf(stderr, "hz size mismatch\n");
	}

	close(sock);

	return true;
}

bool send_debris(struct node *debris, size_t len)
{
	/* Courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up socket and connect to dispatcher
	 */

	if (len < 1) {
		return false;
	}

	struct header head = {0};
	head.type = htons(1);
	head.size = htons(sizeof(head) + ((len) * sizeof(*debris)));

	int sock;
	struct sockaddr_in serv_addr;

	// create socket
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, "\nSocket creation error\n");
		return false;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(2222);

	struct hostent *he = NULL;

	he = gethostbyname("downstream");

	// convert ip
	if (inet_pton(AF_INET, inet_ntoa(**(struct in_addr **)he->h_addr_list),
		      &serv_addr.sin_addr) <= 0) {
		fprintf(stderr,
			"\nInvalid address or Address not supported \n");
		return false;
	}

	// connect to server
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) <
	    0) {
		fprintf(stderr, "\nConnection failed\n");
		return false;
	}

	printf("SENDING TO Downstream Debris\n\n");

	// log_data("", &serv_addr, false);

	if (send(sock, &head, sizeof(head), 0) == -1) {
		fprintf(stderr, "bad send: head\n");
		return false;
	}

	for (size_t i = 1; i < len + 1; i++) {
		debris[i].data = htonl(debris[i].data);
		debris[i].left = htons(debris[i].left);
		debris[i].rite = htons(debris[i].rite);
	}

	struct node *temp = debris;
	temp++;

	if (send(sock, temp, 8 * len, 0) == -1) {
		fprintf(stderr, "bad send: molecules\n");
		return false;
	}

	close(sock);

	return true;
}

bool send_sludge(struct contaminants *cont)
{
	/* Courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up socket and connect to dispatcher
	 */

	if (cont->sludge.count < 1) {
		return false;
	}

	int sock;
	struct sockaddr_in serv_addr;

	// create socket
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, "\nSocket creation error\n");
		return false;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(4444);

	struct hostent *he = NULL;

	he = gethostbyname("downstream");

	// convert ip
	if (inet_pton(AF_INET, inet_ntoa(**(struct in_addr **)he->h_addr_list),
		      &serv_addr.sin_addr) <= 0) {
		fprintf(stderr,
			"\nInvalid address or Address not supported \n");
		return false;
	}

	// connect to server
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) <
	    0) {
		fprintf(stderr, "\nConnection failed\n");
		return false;
	}

	printf("SENDING TO Downstream Sludge\n\n");

	log_data("", &serv_addr, false);

	struct header head = {0};
	head.type = htons(2);
	head.size = htons(8 + (64 * cont->sludge.count));

	int bytes_sent = 0;

	if ((bytes_sent = send(sock, &head, sizeof(head), 0)) == -1) {
		fprintf(stderr, "bad send: head\n");
		return false;
	}

	printf("Send %d bytes of header\n", bytes_sent);

	if (bytes_sent != sizeof(head)) {
		printf("Sludge head send error\n");
	}

	bytes_sent = 0;

	if ((bytes_sent = send(sock, cont->sludge.hashes,
			       64 * cont->sludge.count, 0)) == -1) {
		fprintf(stderr, "bad send: molecules\n");
		return false;
	}

	printf("Send %d bytes of sludges\n", bytes_sent);

	if (bytes_sent != 64 * cont->sludge.count) {
		printf("Sludge payload send error\n");
	}

	close(sock);

	return true;
}

void convert_to_host(struct node *arr, size_t len)
{
	for (size_t i = 1; i < len + 1; i++) {
		arr[i].data = ntohl(arr[i].data);
		arr[i].left = ntohs(arr[i].left);
		arr[i].rite = ntohs(arr[i].rite);
	}
}

void convert_to_net(struct node *arr, size_t len)
{
	for (size_t i = 1; i < len + 1; i++) {
		arr[i].data = htonl(arr[i].data);
		arr[i].left = htons(arr[i].left);
		arr[i].rite = htons(arr[i].rite);
	}
}