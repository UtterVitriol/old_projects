#include <stdio.h>
#include <string.h>

#include <stdint.h>

// // #include "libscrypt/b64.h"
// // #include "libscrypt/crypto_scrypt-hexconvert.h"
// #include "libscrypt/libscrypt.h"

// int main(void)
// {
// 	uint8_t buf[64] = {'\0'};
// 	uint32_t data = 67;
// 	char input[16] = {'\0'};
// 	snprintf(input, sizeof(input), "%u", data);
// 	char *salt = "I Hate Liam Echlin";
// 	libscrypt_scrypt((uint8_t *)input, strlen(input), (uint8_t *)salt,
// 			 strlen(salt), 2048, 4, 4, buf, sizeof(buf));

// 	// fwrite(buf, sizeof(buf), 1, stdout);

// 	for (int i = 0; i < sizeof(buf); i++) {
// 		if (i % 2 == 0) {
// 			printf(" ");
// 		}

// 		if (i % 16 == 0) {
// 			puts("");
// 		}
// 		printf("%02x", buf[i]);
// 	}

// 	puts("");
// }

// #include "detection.h"
#include <math.h>
#include <stdbool.h>
#include <stdlib.h>
bool is_prime(uint32_t value)
{
	if (value < 2) {
		return false;
	} else if (value < 6 && value != 4) {
		return true;
	}
	if (value % 2 == 0 || value % 3 == 0) {
		return false;
	}
	uint32_t x = 5;
	while (x <= sqrt(value)) {
		if (value % x == 0 || value % (x + 2) == 0) {
			return false;
		}
		x += 6;
	}
	return true;
}

bool is_undulating(uint32_t value)
{
	/* Returns 1 if value is undulating, and 0 if it's not
	 *
	 * 11 is a magic number used for the 1 + max number of digits
	 * uint32_t can support
	 */
	char *text = calloc(11, sizeof(char));
	size_t len = 0;
	size_t index = 1;
	bool inc = true;

	if (value == 0) {
		return false;
	} else if (value < 10) {
		return true;
	}

	snprintf(text, 10, "%u", value);
	len = strlen(text);

	if (text[0] > text[1]) {
		inc = false;
	}

	while (text[index + 1] != '\0') {
		if (inc) {
			if (text[index] > text[index + 1]) {
				inc = !inc;
			} else {
				break;
			}
		} else {
			if (text[index] < text[index + 1]) {
				inc = !inc;
			} else {
				break;
			}
		}
		index++;
	}

	free(text);
	if (index + 1 == len) {
		return true;
	}
	return false;
}

int main(void)
{
	printf("Undulating?: %s", is_undulating(616161) ? "TRUE" : "FALSE");
}