#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include <unistd.h>

#include "compound.h"
#include "structs.h"
#include "detection.h"

void add_molecule(struct compound *compound, struct node *node)
{
	compound->count++;
	compound->slots++;

	if (compound->molecules) {
		compound->molecules =
		    realloc(compound->molecules,
			    compound->slots * sizeof(*compound->molecules));
	}

	compound->molecules[compound->count].data = node->data;
	compound->molecules[compound->count].left = node->left;
	compound->molecules[compound->count].rite = node->rite;
}

// void print_compound(struct compound *compound)
// {
// 	printf("Count: %ld\n", compound->count);

// 	for (size_t i = 1; i < compound->count + 1; i++) {
// 		printf("macyg:#%d: LC:%d RC:%d\n", compound->molecules[i].data,
// 		       compound->molecules[i].left,
// 		       compound->molecules[i].rite);
// 	}
// 	printf("end\n");
// }

void present_things(struct node *shifted, size_t *label, size_t len,
		    struct contaminants *cont)
{
	size_t compound_num = 1;

	while (compound_num < len + 1) {
		struct compound compound = {false, INT32_MAX, 0, 1, NULL};
		compound.molecules = calloc(1, sizeof(compound.molecules));

		for (size_t x = 1; x < len + 1; x++) {
			if (label[x] == compound_num) {
				// printf("%d->#%d: LC:%d RC:%d\n", x,
				// shifted[x].data, shifted[x].left,
				// shifted[x].rite);
				add_molecule(&compound, &shifted[x]);
			}
		}

		if (compound.count) {
			printf("Compound #%ld:\n", compound_num);
			state_check(&compound, cont);
		}

		if (compound.molecules) {
			free(compound.molecules);
		}

		compound_num++;
	}
}

void fuck_katen(struct node *punk, size_t *label, size_t len,
		struct contaminants *cont)
{
	/* Shift them pointers around
	 */
	size_t compound = 1;
	size_t counter = 1;

	while (compound < len + 1) {
		// printf("\n\nIteration %d\n", compound - 1);
		// Looking for molecules in compound
		counter = 1;
		for (size_t x = 1; x < len + 1; x++) {
			if (label[x] == compound) {

				for (size_t y = 1; y < len + 1; y++) {
					if (label[y] == compound) {
						if (punk[y].left == x) {
							punk[y].left = counter;
						}
						if (punk[y].rite == x) {
							punk[y].rite = counter;
						}
					}
				}
				counter++;
			}
		}
		compound++;
	}

	present_things(punk, label, len, cont);
}

void child_linker(struct node *molecules, size_t *label, size_t counter,
		  size_t len, size_t x)
{
	if (molecules[x].left < len && molecules[x].left != 0 &&
	    label[molecules[x].left] != counter) {
		// printf("TestLC: #%d x:%d LC:%d RC:%d\n", counter, x,
		// molecules[x].left, molecules[x].rite); // DEBUG
		label[molecules[x].left] = counter;
		child_linker(molecules, label, counter, len, molecules[x].left);
		parent_linker(molecules, label, counter, len,
			      molecules[x].left);
	}
	if (molecules[x].rite < len && molecules[x].rite != 0 &&
	    label[molecules[x].rite] != counter) {
		// printf("TestRC: #%d x:%d LC:%d RC:%d\n", counter, x,
		// molecules[x].left, molecules[x].rite); // DEBUG
		label[molecules[x].rite] = counter;
		child_linker(molecules, label, counter, len, molecules[x].rite);
		parent_linker(molecules, label, counter, len,
			      molecules[x].rite);
	}
}

void parent_linker(struct node *molecules, size_t *label, size_t counter,
		   size_t len, size_t x)
{
	size_t y = 1;
	while (y < len) {
		if ((molecules[y].left == x || molecules[y].rite == x) &&
		    label[y] == 0) {
			// printf("TestP: #%d x:%d LC:%d RC:%d\n", counter, x,
			// molecules[x].left, molecules[x].rite); // DEBUG
			label[y] = counter;

			child_linker(molecules, label, counter, len,
				     molecules[y].left);
			child_linker(molecules, label, counter, len,
				     molecules[y].rite);
			parent_linker(molecules, label, counter, len, y);
		}
		y++;
	}
}

void compounder(struct node *molecules, size_t len, struct contaminants *cont)
{
	size_t *label = calloc(len + 1, sizeof(size_t));
	size_t counter = 1;

	for (size_t x = 1; x < len + 1; x++) {
		if (label[x] == 0) {

			label[x] = counter;

			child_linker(molecules, label, counter, len + 1, x);
			parent_linker(molecules, label, counter, len + 1, x);
			counter++;
		}
		// DEBUG
		// for (size_t x = 1; x < len; x++) {
		// 	printf(" %d -", label[x]);
		// }
		// puts("");
	}

	label[0] = 0;

	fuck_katen(molecules, label, len, cont);
}

void test1(void)
{
	// Test 1
	struct node *test = calloc(14, sizeof(struct node));
	test[1].data = 0; // Air
	test[1].left = 0;
	test[1].rite = 0;
	test[2].data = 36155; // Safe
	test[2].left = 2;
	test[2].rite = 0;
	test[3].data = 39481; // Chlorine
	test[3].left = 0;
	test[3].rite = 0;
	test[4].data = 29824; // Safe
	test[4].left = 0;
	test[4].rite = 13;
	test[5].data = 39626; // Safe
	test[5].left = 13;
	test[5].rite = 3;
	test[6].data = 46338; // Chlorine
	test[6].left = 4;
	test[6].rite = 4;
	test[7].data = 37643; // Feces
	test[7].left = 8;
	test[7].rite = 0;
	test[8].data = 0; // Air
	test[8].left = 0;
	test[8].rite = 0;
	test[9].data = 53353; // Feces
	test[9].left = 5;
	test[9].rite = 0;
	test[10].data = 38429; // Safe
	test[10].left = 0;
	test[10].rite = 1;
	test[11].data = 0; // Air
	test[11].left = 0;
	test[11].rite = 0;
	test[12].data = 11716; // Debris
	test[12].left = 220;
	test[12].rite = 0;
	test[13].data = 0; // Air
	test[13].left = 0;
	test[13].rite = 0;

	struct contaminants yucky = {0};
	init_contaminants(&yucky);

	compounder(test, 13, &yucky);

	// for (size_t x = 1; x < 14; x++) {
	// 	printf(" %d -", list[x]);
	// }
}

void test2(void)
{
	// Test 2
	struct node *test = calloc(31, sizeof(struct node));
	test[1].data = 12154;
	test[1].left = 16;
	test[1].rite = 0;
	test[2].data = 0;
	test[2].left = 0;
	test[2].rite = 0;
	test[3].data = 1254;
	test[3].left = 0;
	test[3].rite = 22;
	test[4].data = 0;
	test[4].left = 0;
	test[4].rite = 0;
	test[5].data = 0;
	test[5].left = 0;
	test[5].rite = 0;
	test[6].data = 0;
	test[6].left = 0;
	test[6].rite = 0;
	test[7].data = 0;
	test[7].left = 0;
	test[7].rite = 0;
	test[8].data = 8707;
	test[8].left = 28;
	test[8].rite = 28;
	test[9].data = 0;
	test[9].left = 0;
	test[9].rite = 0;
	test[10].data = 24198;
	test[10].left = 29;
	test[10].rite = 0;
	test[11].data = 9529;
	test[11].left = 24;
	test[11].rite = 0;
	test[12].data = 0;
	test[12].left = 0;
	test[12].rite = 0;
	test[13].data = 22422;
	test[13].left = 0;
	test[13].rite = 25;
	test[14].data = 55370;
	test[14].left = 0;
	test[14].rite = 1;
	test[15].data = 0;
	test[15].left = 0;
	test[15].rite = 0;
	test[16].data = 12921;
	test[16].left = 11;
	test[16].rite = 19;
	test[17].data = 29418;
	test[17].left = 16;
	test[17].rite = 18;
	test[18].data = 54360;
	test[18].left = 10;
	test[18].rite = 0;
	test[19].data = 17449;
	test[19].left = 28;
	test[19].rite = 8;
	test[20].data = 36632;
	test[20].left = 0;
	test[20].rite = 19;
	test[21].data = 0;
	test[21].left = 0;
	test[21].rite = 0; // Change to 27 to test cycles
	test[22].data = 41456;
	test[22].left = 20;
	test[22].rite = 20;
	test[23].data = 0;
	test[23].left = 0;
	test[23].rite = 0;
	test[24].data = 40171;
	test[24].left = 3;
	test[24].rite = 0;
	test[25].data = 774;
	test[25].left = 0;
	test[25].rite = 14;
	test[26].data = 0;
	test[26].left = 0;
	test[26].rite = 0;
	test[27].data = 0;
	test[27].left = 0; // Change to 21 to test cycles
	test[27].rite = 0;
	test[28].data = 13038;
	test[28].left = 0;
	test[28].rite = 0;
	test[29].data = 25925;
	test[29].left = 13;
	test[29].rite = 0;
	test[30].data = 0;
	test[30].left = 0;
	test[30].rite = 0;

	struct contaminants yucky = {0};
	init_contaminants(&yucky);

	compounder(test, 30, &yucky);

	// size_t *list = calloc(31, sizeof(size_t));
	// compounder(test, list, 31);

	// for (size_t x = 1; x < 31; x++) {
	// 	printf(" %d -", list[x]);
	// }
	// puts("");
	// fuck_katen(test, list, 31);

	// free(test);
	// free(list);
}

void test3(void)
{
	/// macy big dummy can't talk english

	struct node *test = calloc(31, sizeof(struct node));
	test[1].data = 1;
	test[1].left = 16;
	test[1].rite = 0;

	test[2].data = 2;
	test[2].left = 0;
	test[2].rite = 0;

	test[3].data = 3;
	test[3].left = 0;
	test[3].rite = 22;

	test[4].data = 0;
	test[4].left = 0;
	test[4].rite = 0;

	test[5].data = 0;
	test[5].left = 0;
	test[5].rite = 0;

	test[6].data = 0;
	test[6].left = 0;
	test[6].rite = 0;

	test[7].data = 0;
	test[7].left = 0;
	test[7].rite = 0;

	test[8].data = 4;
	test[8].left = 28;
	test[8].rite = 28;

	test[9].data = 0;
	test[9].left = 0;
	test[9].rite = 0;

	test[10].data = 5;
	test[10].left = 29;
	test[10].rite = 0;

	test[11].data = 6;
	test[11].left = 24;
	test[11].rite = 0;

	test[12].data = 0;
	test[12].left = 0;
	test[12].rite = 0;

	test[13].data = 7;
	test[13].left = 0;
	test[13].rite = 25;

	test[14].data = 8;
	test[14].left = 0;
	test[14].rite = 1;

	test[15].data = 0;
	test[15].left = 0;
	test[15].rite = 0;

	test[16].data = 9;
	test[16].left = 11;
	test[16].rite = 19;

	test[17].data = 10;
	test[17].left = 16;
	test[17].rite = 18;

	test[18].data = 11;
	test[18].left = 10;
	test[18].rite = 0;

	test[19].data = 12;
	test[19].left = 28;
	test[19].rite = 8;

	test[20].data = 13;
	test[20].left = 0;
	test[20].rite = 19;

	test[21].data = 0;
	test[21].left = 0;
	test[21].rite = 0; // Change to 27 to test cycles

	test[22].data = 14;
	test[22].left = 20;
	test[22].rite = 20;

	test[23].data = 0;
	test[23].left = 0;
	test[23].rite = 0;

	test[24].data = 15;
	test[24].left = 3;
	test[24].rite = 0;

	test[25].data = 16;
	test[25].left = 0;
	test[25].rite = 14;

	test[26].data = 0;
	test[26].left = 0;
	test[26].rite = 0;

	test[27].data = 0;
	test[27].left = 0; // Change to 21 to test cycles
	test[27].rite = 0;

	test[28].data = 17;
	test[28].left = 0;
	test[28].rite = 0;

	test[29].data = 18;
	test[29].left = 13;
	test[29].rite = 0;

	test[30].data = 0;
	test[30].left = 0;
	test[30].rite = 0;

	struct contaminants yucky = {0};
	init_contaminants(&yucky);

	compounder(test, 30, &yucky);
}

void test4(void)
{
	struct node *test = calloc(18, sizeof(struct node));
	test[1].data = 1;
	test[1].left = 8;
	test[1].rite = 0;

	test[2].data = 3;
	test[2].left = 0;
	test[2].rite = 13;

	test[3].data = 8;
	test[3].left = 16;
	test[3].rite = 16;

	test[4].data = 10;
	test[4].left = 17;
	test[4].rite = 0;

	test[5].data = 11;
	test[5].left = 14;
	test[5].rite = 0;

	test[6].data = 13;
	test[6].left = 0;
	test[6].rite = 15;

	test[7].data = 14;
	test[7].left = 0;
	test[7].rite = 1;

	test[8].data = 16;
	test[8].left = 5;
	test[8].rite = 11;

	test[9].data = 17;
	test[9].left = 8;
	test[9].rite = 10;
	// test[9].left = 0;
	// test[9].rite = 0;

	test[10].data = 18;
	test[10].left = 4;
	test[10].rite = 0;

	test[11].data = 19;
	test[11].left = 16;
	test[11].rite = 3;

	test[12].data = 20;
	test[12].left = 0;
	test[12].rite = 11;

	test[13].data = 22;
	test[13].left = 12;
	test[13].rite = 12;

	test[14].data = 24;
	test[14].left = 2;
	test[14].rite = 0;

	test[15].data = 25;
	test[15].left = 0;
	test[15].rite = 7;

	test[16].data = 28;
	test[16].left = 0;
	test[16].rite = 0;

	test[17].data = 29;
	test[17].left = 6;
	test[17].rite = 0;

	struct contaminants yucky = {0};
	init_contaminants(&yucky);

	compounder(test, 17, &yucky);

	print_hazmats(&yucky);
}

// size_t main(void)
// {
// 	// test1();
// 	// test2();
// 	// test3();
// 	test4();
// 	return 0;
// }
