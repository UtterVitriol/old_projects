#ifndef IS_IT_POOP_H
#define IS_IT_POOP_H

#include <stdbool.h>

#include "structs.h"

bool create_array(int sock);
void print_arr(struct header *head, struct node *arr, int items);

#endif