#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>

#include <arpa/inet.h>

#include "is_it_poop.h"
#include "wwater_serv.h"
#include "compound.h"
#include "detection.h"

bool create_array(int sock)
{
	size_t bytes_read;

	struct header head = {0};

	// read request
	bytes_read = read(sock, &head, sizeof(head));

	if (bytes_read < sizeof(head)) {
		// TODO:  need to log this and send report packet
		perror("Did not receive a full header\n");
		close(sock);
		return false;
	}

	// This is the only place where a ntoh_ call is needed
	size_t items = (ntohs(head.size) - sizeof(head)) / sizeof(struct node);

	// leave first one blank?
	struct node *payload = NULL;
	payload = calloc(items + 1, sizeof(*payload));

	if (!payload) {
		fprintf(stderr, "Calloc is dumb\n");
		exit(1);
	}
	bytes_read = 0;

	size_t count = 1;

	// Read in the entire payload
	do {
		ssize_t amt =
		    read(sock, &payload[count], sizeof(payload[count]));

		if (amt < 0) {
			// TODO: Should log this and send a report packet
			fprintf(stderr, "Did not receive a entire packet\n");
			continue;
		}

		bytes_read += amt;
		count++;

	} while (count < items + 1);

	print_arr(&head, payload, items);
	printf("Items: %ld, REad: %ld\n", items, bytes_read / 8);

	convert_to_host(payload, items);

	struct contaminants yucky = {0};
	init_contaminants(&yucky);

	compounder(payload, items, &yucky);

	send_hazmats(&yucky);
	// send_debris(&yucky); changed
	send_sludge(&yucky);

	// send_data(&head, payload, items);

	free(payload);

	return true;
}

void print_arr(struct header *head, struct node *arr, int items)
{
	printf("Type: %u\n"
	       "Size: %u\n"
	       "Custom: %s\n"
	       "Molecules: %d\n",
	       ntohs(head->type), ntohs(head->size), head->custom, items);

	puts("---------------");
	puts("---------------");

	for (int i = 1; i < items + 1; i++) {
		printf("Molecule: %d\n", i);
		printf("Data: %u\n"
		       "Left: %u\n"
		       "Right: %u\n",
		       ntohl(arr[i].data), ntohs(arr[i].left),
		       ntohs(arr[i].rite));
		puts("---------------");
	}
}

bool is_binary_tree(struct node *arr, int items)
{
	for (int i = 0; i < items; i++) {
		if (arr[arr[i].left].data > arr[i].data) {
			return false;
		}

		if (arr[arr[i].rite].data < arr[i].data) {
			return false;
		}
	}

	return true;
}

bool is_linked_list(struct node *arr, int items)
{
	for (int i = 0; i < items; i++) {
		int lcount = 0;
		int rcount = 0;

		for (int j = 0; j < items; j++) {
			if (i == j) {
				continue;
			}

			if (lcount > 1 || rcount > 1) {
				return false;
			}

			if (arr[j].left == i + 1) {
				lcount += 1;
			} else if (arr[j].rite == i + 1) {
				rcount += 1;
			}
		}
	}

	return true;
}