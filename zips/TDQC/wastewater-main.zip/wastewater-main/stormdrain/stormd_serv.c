#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <netdb.h>

#include <syslog.h>
#include <time.h>

#include "structs.h"
#include "is_it_poop.h"

bool setup_server(int *sock);
bool serve_forever(int *sock);
bool new_connection(int sock);
void log_data(char *data, struct sockaddr_in *client, bool recv);
bool send_data(struct header *head);

int main(int argc, char **argv)
{
	(void)argc;
	(void)argv;
	// List port will always be 1111

	int sock;

	if (!setup_server(&sock)) {
		return 1;
	}

	serve_forever(&sock);
}

bool setup_server(int *sock)
{
	/* Socket code courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up server to listen for connections
	 */

	int opt = 1;
	int len = sizeof(len);

	// create socket
	*sock = socket(AF_INET, SOCK_STREAM, 0);
	if (*sock == 0) {
		perror("Socket creation failed");
		return false;
	}

	// set socket options
	if (setsockopt(*sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
		perror("Setsockopt");
		return false;
	}

	struct sockaddr_in addr;

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons(1111);

	// bind socket to port
	if (bind(*sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("Bind failed");
		return false;
	}

	// listen for connections
	if (listen(*sock, 5) < 0) {
		perror("Listen failed");
		return false;
	}

	return true;
}

bool serve_forever(int *sock)
{
	/*
	 * Accept new connections
	 * Fork on new connection
	 */
	for (;;) {
		struct sockaddr_in addr;
		size_t addrlen = sizeof(addr);
		int new_socket;

		new_socket = accept(*sock, (struct sockaddr *)&addr,
				    (socklen_t *)&addrlen);
		if (new_socket < 0) {
			perror("accept");
			return false;
		}

		if (fork() == 0) {
			new_connection(new_socket);
			exit(0);
		} else {
			close(new_socket);
		}
	}

	return true;
}

bool new_connection(int sock)
{
	/*
	 * Handle new connection
	 */

	size_t bytes_read;

	struct sockaddr_in client = {0};
	socklen_t len = sizeof(client);

	// get client data
	getpeername(sock, (struct sockaddr *)&client, &len);

	struct header head = {0};

	// read request
	bytes_read = read(sock, &head, sizeof(head));

	printf("Type: %d\nSize: %d\nCustom: %s\n", head.type, ntohs(head.size),
	       head.custom);

	char buff[65535] = {'\0'};

	bytes_read = read(sock, &buff, ntohs(head.size) - bytes_read);
	printf("Bytes: %ld\n", bytes_read);

	// send_data(&head);

	close(sock);

	return true;
}

bool send_data(struct header *head)
{
	/* Courtesy of
	 * https://www.geeksforgeeks.org/socket-programming-cc/
	 * Set up socket and connect to dispatcher
	 */

	int sock;
	struct sockaddr_in serv_addr;

	// create socket
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, "\nSocket creation error\n");
		return false;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(1111);

	struct hostent *he = NULL;

	he = gethostbyname("pretreatment");

	// convert ip
	if (inet_pton(AF_INET, inet_ntoa(**(struct in_addr **)he->h_addr_list),
		      &serv_addr.sin_addr) <= 0) {
		fprintf(stderr,
			"\nInvalid address or Address not supported \n");
		return false;
	}

	// connect to server
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) <
	    0) {
		fprintf(stderr, "\nConnection failed\n");
		return false;
	}

	printf("SENDING TO PRETREATMENT\n\n");

	log_data("", &serv_addr, false);

	if (send(sock, head, sizeof(*head), 0) == -1) {
		return false;
	}

	close(sock);

	return true;
}

void log_data(char *data, struct sockaddr_in *client, bool recv)
{
	/*
	 * Log transmission payload data
	 */

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	// array for ip from inet_ntop
	char ip[16] = {'\0'};

	char to[] = "To";
	char from[] = "From";

	char *to_from = to;

	if (recv) {
		to_from = from;
	}

	// open log
	openlog("server", LOG_PID | LOG_PERROR, LOG_USER);

	// log data
	syslog(LOG_INFO,
	       "%s - "
	       "%d-%02d-%02d %02d:%02d:%02d - "
	       "%s:%hu - "
	       "\"%s\"\n",
	       to_from, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
	       tm.tm_hour, tm.tm_min, tm.tm_sec,
	       inet_ntop(AF_INET, &client->sin_addr.s_addr, ip, sizeof(ip)),
	       htons(client->sin_port), data);

	// close log (catiscat)
	closelog();
}
