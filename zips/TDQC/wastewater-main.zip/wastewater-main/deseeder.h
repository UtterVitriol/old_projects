#ifndef DESEEDER_H
#define DESEEDER_H

#include <stdint.h>
#include <stdlib.h>

struct molecule {
	uint32_t data;
	uint16_t left;
	uint16_t rite;
};


int deseeder(struct molecule *data, size_t sz);


#endif
