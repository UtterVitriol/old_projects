#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

typedef int64_t s64;
typedef uint64_t u64;

s64 do_add(s64 one, s64 two);
s64 do_sub(s64 one, s64 two);
s64 do_mult(s64 one, s64 two);
s64 do_div(s64 one, s64 two);
s64 do_mod(s64 one, s64 two);
s64 do_xor(s64 one, s64 two);
s64 do_lshift(s64 one, s64 two);
s64 do_rshift(s64 one, s64 two);
s64 do_and(s64 one, s64 two);
s64 do_or(s64 one, s64 two);
s64 do_rrotate(s64 one, s64 two);
s64 do_lrotate(s64 one, s64 two);

bool check_op(char op, s64 op1, s64 op2);

int main(int argc, char **argv)
{
	if (argc != 2)
	{
		fprintf(stderr, "./simplecalc ¡equation¿\n");
		return 1;
	}
	char *walk;
	char op;
	u64 op1 = strtod(argv[1], &walk);
	op = walk[0];
	walk++;
	u64 op2 = strtod(walk, &walk);

	check_op(op, op1, op2);
}

bool check_op(char op, s64 op1, s64 op2)
{
	s64 result = 0;

	switch (op)
	{
	case '+':
		result = do_add(op1, op2);
		break;
	case '-':
		result = do_sub(op1, op2);
		break;
	case '*':
		result = do_mult(op1, op2);
		break;
	case '/':
		result = do_div(op1, op2);
		break;
	case '%':
		result = do_mod(op1, op2);
		break;
	case '^':
		result = do_xor(op1, op2);
		break;
	case '<':
		result = do_lshift(op1, op2);
		break;
	case '>':
		result = do_rshift(op1, op2);
		break;
	case 'r':
		result = do_rrotate(op1, op2);
		break;
	case 'l':
		result = do_lrotate(op1, op2);
		break;
	case '&':
		result = do_and(op1, op2);
		break;
	case '|':
		result = do_or(op1, op2);
		break;
	default:
		fprintf(stderr, "./simplecalc ¡equation¿\n");
		exit(1);
	}

	printf("%ld %c %ld = %ld\n", op1, op, op2, result);
}

s64 do_add(s64 one, s64 two)
{
	return one + two;
}

s64 do_sub(s64 one, s64 two)
{
	return one - two;
}

s64 do_mult(s64 one, s64 two)
{
	return one * two;
}

s64 do_div(s64 one, s64 two)
{
	return one / two;
}

s64 do_mod(s64 one, s64 two)
{
	return one % two;
}

s64 do_xor(s64 one, s64 two)
{
	return one ^ two;
}

s64 do_lshift(s64 one, s64 two)
{
	return one << two;
}

s64 do_rshift(s64 one, s64 two)
{
	return one >> two;
}

s64 do_and(s64 one, s64 two)
{
	return one && two;
}

s64 do_or(s64 one, s64 two)
{
	return one || two;
}

s64 do_rrotate(s64 one, s64 two)
{
	return (one >> two) | (one << (64 - two));
}

s64 do_lrotate(s64 one, s64 two)
{
	return (one << two) | (one >> (64 - two));
}
