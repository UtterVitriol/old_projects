# ticker

