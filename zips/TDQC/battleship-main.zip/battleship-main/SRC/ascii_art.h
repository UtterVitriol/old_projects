#pragma once

// ascii art
extern const char *logo_one;
extern const char *logo_two;
extern const char *logo_three;
extern const char *logo_four;
extern const char *logo_five;
extern const char *logo_six;

extern const char *hit_one;
extern const char *hit_two;
extern const char *hit_three;
extern const char *hit_four;
extern const char *hit_five;
extern const char *hit_six;
extern const char *hit_seven;
extern const char *hit_eight;
extern const char *hit_nine;

extern const char *miss_one;
extern const char *miss_two;
extern const char *miss_three;
extern const char *miss_four;
extern const char *miss_five;
extern const char *miss_six;
extern const char *miss_seven;
extern const char *miss_eight;
extern const char *miss_nine;
