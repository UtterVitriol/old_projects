# Wordsorter

Wordsorter is a program the sorts and prints words

## Installation

Clone or Download..

```bash
git clone "link"
```

## Usage

```bash
    Usage: ./ws [-rnlsSauih] [-c <n>] [-C <n>] [file_name(s)...]
    
 	Each flag, except r can only be input once..
 	
 	-c - prints first <n> number of results from sorted list
 	-C - prints last <n> number of results from sorted list
 	-r sorts in reverse order
 	-n sorts by leading numbers in words
 	-l sorts by word length
 	-s sorts words by scrabble score
 	-S sorts by scrabble score and removes impossible words
 	-a sorts alphabetically
 	-u prints only unique words
 	-i has sorts treat words as lowercase
 	-h prints this help message
 	
 	If no arguments are given, words will be retrieved one at a time from stdin
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[memes](https://reddit.com/r/programminghumor)
