SELECT game_id AS 'Game with most points scored', name AS 'Team Name',
	points_scored AS 'points scored'
FROM Score
INNER JOIN Team ON Score.team_id = Team.team_id
WHERE game_id = (SELECT game_id 
	FROM Score
	GROUP BY game_id
	ORDER BY SUM(points_scored) DESC
	LIMIT 1);

