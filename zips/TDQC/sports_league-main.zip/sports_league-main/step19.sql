SELECT name AS 'Team Name'
FROM Team
INNER JOIN Score ON Team.team_id = Score.team_id
WHERE win_lose_tie = 'W'
GROUP BY Score.team_id
ORDER BY count(Score.team_id) DESC
LIMIT 1;
