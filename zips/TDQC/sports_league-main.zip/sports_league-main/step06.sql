INSERT INTO Team (team_id, name, logo)
	VALUES	(001, 'Scarecrows', 'Inkblot'),
    		(002, 'Riddlers', 'Question Mark'),
    		(003, 'Jokers', 'Playing Card'),
			(004, 'BATMAN', 'ManBat');

INSERT INTO Player (first_name, last_name)
	VALUES	('Nathan', 'Drake'),
			('Donald', 'Duck');

INSERT INTO Player(first_name, last_name, team_id, player_number)
	VALUES	('Johnathan', 'Crane', 1, 10),
			('Ray', 'Bolger', 1, 11),
			('Herald', 'Golpher', 1, 12),
			('Oscar', 'Wilde', 1, 13),
			('Edward', 'Nygma', 2, 20),
			('Morgan', 'Hed', 2, 21),
			('Alfred', 'Pennyworth', 2, 22),
			('Titus', 'Vespa', 2, 23),
			('Jack', 'Napier', 3, 30),
			('Arthur', 'Fleck', 3, 31),
			('Thomas', 'Payne', 3, 32),
			('Joseph', 'Perry', 3, 33),
			('Bruce', 'Wayne', 4, 40),
			('Terry', 'McGinnis', 4, 41),
			('Dick', 'Grayson', 4, 42),
			('Jason', 'Todd', 4, 43);

INSERT INTO Stat(player_id, height, weight, age)
	VALUES	(1, 181.4, 100.01, 30),
			(2, 159.9, 70.5, 23);

INSERT INTO Stat(player_id, height, weight, age, player_number)
	VALUES	(3, 170.8, 81, 21, 10),
			(4, 165.1, 76, 28, 11),
			(5, 165.1, 94.1, 19, 12),
			(6, 177.1, 93.41, 34, 13),
			(7, 159.4, 94.4, 26, 20),
			(8, 164.8, 91.77, 38, 21),
			(9, 180.2, 106.9, 27, 22),
			(10, 176.3, 105.37, 20, 23),
			(11, 170.9, 60.25, 21, 30),
			(12, 170.7, 100.46, 20, 31),
			(13, 159.3, 76.69, 19, 32),
			(14, 163.5, 66.36, 18, 33),
			(15, 176.9, 70.45, 16, 40),
			(16, 159.4, 67.42, 24, 41),
			(17, 177.7, 76.96, 23, 42),
			(18, 160.2, 120, 21, 43);

INSERT INTO Game(game_date, start_time, home_team, visitor_team)
	VALUES	('2005-01-15', '14:15:00', 1, 2),
			('2005-01-30', '15:30:00', 1, 3),
			('2005-02-15', '12:45:00', 1, 4),
			('2005-02-28', '11:30:00', 2, 3),
			('2005-03-13', '14:25:00', 2, 4),
			('2005-04-12', '15:00:00', 3, 4);

INSERT INTO Score(game_id, team_id, points_scored, win_lose_tie)
	VALUES	(1, 1, 1, 'T'),
			(1, 2, 1, 'T'),
			(2, 1, 23, 'W'),
			(2, 3, 10, 'L'),
			(3, 1, 8, 'L'),
			(3, 4, 30, 'W'),
			(4, 2, 17, 'T'),
			(4, 3, 17, 'T'),
			(5, 2, 20, 'L'),
			(5, 4, 21, 'W'),
			(6, 3, 10, 'L'),
			(6, 4, 30, 'W');
