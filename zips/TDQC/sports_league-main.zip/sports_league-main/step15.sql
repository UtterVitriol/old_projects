SELECT COUNT(*) AS `Number of Players`
FROM Player;
