SELECT COUNT(*) AS `Number of games on 2005-1-30`
FROM Game
GROUP BY game_date
HAVING game_date = '2005-1-30';
