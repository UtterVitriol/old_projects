SELECT game_date AS Date, Home.name AS `Home Team`, Away.name AS `Away Team`
FROM Game
INNER JOIN Team AS Home ON Home.team_id = Game.home_team
INNER JOIN Team AS Away ON Away.team_id = Game.visitor_team;
