main():

    """Create sql script with select statement that gets all
       records from table, table_name
    """

    # get table name from user
    table_name = input("Enter Table Name: ")

    # write sql script
    with open("step25.sql", "w",) as file:
        file.write("".join(("SELECT * FROM ", table_name, ";")))


if __name__ == "__main__":
    main()
