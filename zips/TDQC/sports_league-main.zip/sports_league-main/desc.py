from mysql_utils import get_connection


def get_desc():
    connection = get_connection()
    sql = ("SELECT * FROM Player")
    cursor = connection.cursor()
    cursor.execute(sql)
    c_names = [item[0] for item in cursor.description]
    row_format = "{:>15}" * (len(c_names))

    # for c_name in cursor.description:
    #     print(c_name[0][0].upper(), c_name[0]
    #           [1:].replace("_", " ", 1), sep="", end=" ")
    #     print("|", end=" ")

    # print()
    def conv(i): return i or "None"
    print(row_format.format(*c_names))
    for item in cursor.fetchall():
        item = [conv(i) for i in item]
        print(row_format.format(*item))
        break
    cursor.reset()
    cursor.close()
    connection.close()


get_desc()
