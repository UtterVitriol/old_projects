/* Prints the highest scoring team name with the highest score they achieved.
*/
SELECT name AS `Team Name`, MAX(points_scored) AS `Highest Score`
FROM Team INNER JOIN Score
WHERE Team.team_id = Score.team_id
GROUP BY Team.name;
