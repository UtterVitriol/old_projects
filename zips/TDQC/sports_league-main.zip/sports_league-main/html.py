from mysql_utils import get_connection


def get_info():
    connection = get_connection()
    sql = ("SELECT * FROM Game")
    cursor = connection.cursor()
    cursor.execute(sql)
    make_html("Game", cursor)
    cursor.close()
    connection.close()


def create_row(data):
    row = []
    for item in data:
        row.append(f"<td>{item}</td>")
    return "".join(row)


def create_table(title, cursor):
    html = []
    html.append("<table>")
    html.append(f"<caption>{title}</caption>")
    html.append("<thead>")
    html.append("<tr>")
    table_heads = []
    for name in cursor.column_names:
        table_heads.append(f"<th>{name}</th>")
    html.append("".join(table_heads))
    html.append("</tr>")
    html.append("</thead>")
    html.append("<tbody>")
    for row in cursor.fetchall():
        html.append("<tr>")
        html.append(create_row(row))
        html.append("</tr>")
    html.append("</tbody>")
    html.append("</table>")

    return html


def make_html(name, cursor):
    html = ["<!doctype html>",
            "<html>",
            "<head>",
            "<link href='styling.css' type='text/css' rel='stylesheet'/>",
            f"<title>{name}</title>", ]
    html.extend(create_table(name, cursor))
    html.extend(["</head>", "</html>"])
    html = ["".join((item, "\n")) for item in html]
    html = "".join(html)
    with open("test.html", "w") as file:
        file.write(html)


get_info()
