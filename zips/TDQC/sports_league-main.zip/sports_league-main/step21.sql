/*	Creates a subquery for wins, losses, and ties then left joins them to Team
	to ensure every team still shows in the final product. We use IFNULL to
	replace the NULL values with 0's
*/
SELECT name AS 'Team Name', IFNULL(Win.win_lose_tie, 0) AS 'Wins',
IFNULL(Lose.win_lose_tie, 0) AS 'Losses', IFNULL(Tie.win_lose_tie, 0) AS 'Ties'
FROM Team
LEFT JOIN
	(SELECT team_id, COUNT(win_lose_tie) AS win_lose_tie
	FROM Score
	WHERE win_lose_tie = 'W'
	GROUP BY team_id, win_lose_tie)
AS Win
ON Team.team_id = Win.team_id
LEFT JOIN
	(SELECT team_id, count(win_lose_tie) AS win_lose_tie
	FROM Score
	WHERE win_lose_tie = 'L'
	GROUP BY team_id, win_lose_tie)
AS Lose
ON Team.team_id = Lose.team_id
LEFT JOIN
	(SELECT team_id, count(win_lose_tie) AS win_lose_tie
	FROM Score
	WHERE win_lose_tie = 'T'
	GROUP BY team_id, win_lose_tie)
AS Tie
ON Team.team_id = Tie.team_id;
