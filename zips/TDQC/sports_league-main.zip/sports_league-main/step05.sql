/*	ENUM is used to allow for (W)ins, (L)osses, and (T)ies.
*/
CREATE TABLE Score (
    game_id			INT UNSIGNED NOT NULL,
    team_id			INT UNSIGNED NOT NULL,
    points_scored	INT UNSIGNED DEFAULT 0,
    win_lose_tie	ENUM('W', 'L', 'T')
);
