/*	Concatinates last and first name with the alias name, concatinates height
	in cm aliased to height, pads the weight to 6 characters(to account for 100+
	kg and 2 decimal places) with spaces to the left then concatinates with kg
	as weight. Ordering the results by last name.
	This one required an inner join between the Player and Stat tables.
*/
SELECT CONCAT(last_name, ' ', first_name) AS name, age,
	CONCAT(height, ' cm') as 'height', CONCAT(lpad(weight, 6,' '), ' kg') AS 'weight'
FROM Player
INNER JOIN Stat ON Player.player_id = Stat.player_id
ORDER BY last_name;
