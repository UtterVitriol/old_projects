CREATE TABLE Game (
    game_id			INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    game_date		DATE NOT NULL,
    start_time		TIME NOT NULL,
    home_team		INT UNSIGNED NOT NULL,
    visitor_team	INT UNSIGNED NOT NULL
);
