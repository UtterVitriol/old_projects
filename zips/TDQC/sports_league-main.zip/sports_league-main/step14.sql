SELECT COUNT(*) AS `Number of Teams`
FROM Team;
