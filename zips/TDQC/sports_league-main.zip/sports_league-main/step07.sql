/*	Gets the average height of players, then formats it to be 2 decimal places
	before concatinating the string to include the scale.
*/
SELECT CONCAT(FORMAT(AVG(height), 2), " cm") as 'Average Height' from Stat;
