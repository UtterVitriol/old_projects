/*	Gets the averages for each team, then gets the max of all of the averages
	Returns the team that matches the highest average.
*/
SELECT name `Highest AVG Scoring Team`
FROM Team
inner join 
	(SELECT AVG(points_scored) AS 'avg', team_id
	FROM Score
	GROUP BY team_id)
	AS Average
WHERE avg = (SELECT MAX(average)
	FROM (SELECT AVG(points_scored) AS 'average', team_id
	FROM Score
	GROUP BY team_id) AS MaxAverage)
AND Team.team_id = Average.team_id;
