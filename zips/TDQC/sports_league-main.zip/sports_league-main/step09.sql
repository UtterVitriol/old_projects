/*	Gets all playes and player numbers from a specified team(4) and orders them
	by player_number
*/
SELECT CONCAT(first_name, ' ', last_name) AS 'Name', player_number as 'Player Number'
FROM Player
WHERE team_id = 4
ORDER BY player_number;
