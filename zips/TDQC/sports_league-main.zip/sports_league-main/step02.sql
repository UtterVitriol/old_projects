/*	Auto_increment is used to get the next number every time a player is added.
*/
CREATE TABLE Player (
	player_id		INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	first_name		VARCHAR(10) NOT NULL,
	last_name		VARCHAR(10) NOT NULL,
	team_id			INT UNSIGNED,
	player_number	INT UNSIGNED
);
