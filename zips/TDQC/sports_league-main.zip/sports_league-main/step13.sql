/* Gets only players that are not assigned to a team, and prints their name.
*/
SELECT CONCAT(first_name, ' ', last_name) as Name
FROM Player
WHERE team_id is NULL;
