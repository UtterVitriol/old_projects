/* We use height minimum of 100 cm, weight minimum of 50 kg, and age minimum of 15
   Unsigned integers were used because they shouldn't have a negative range.
*/
CREATE TABLE Stat (
	player_id		INT UNSIGNED NOT NULL PRIMARY KEY,
	height			DOUBLE NOT NULL CHECK (height > 100),
	weight			DOUBLE NOT NULL CHECK(weight > 50),
	age				TINYINT UNSIGNED NOT NULL CHECK(age > 15),
	player_number	INT UNSIGNED
);
