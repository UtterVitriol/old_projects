-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: sport
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Game`
--

DROP TABLE IF EXISTS `Game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Game` (
  `game_id` int unsigned NOT NULL AUTO_INCREMENT,
  `game_date` date NOT NULL,
  `start_time` time NOT NULL,
  `home_team` int unsigned NOT NULL,
  `visitor_team` int unsigned NOT NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Game`
--

LOCK TABLES `Game` WRITE;
/*!40000 ALTER TABLE `Game` DISABLE KEYS */;
INSERT INTO `Game` VALUES (1,'2005-01-15','14:15:00',1,2),(2,'2005-01-30','15:30:00',1,3),(3,'2005-02-15','12:45:00',1,4),(4,'2005-02-28','11:30:00',2,3),(5,'2005-03-13','14:25:00',2,4),(6,'2005-04-12','15:00:00',3,4);
/*!40000 ALTER TABLE `Game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Player`
--

DROP TABLE IF EXISTS `Player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Player` (
  `player_id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10) NOT NULL,
  `last_name` varchar(10) NOT NULL,
  `team_id` int unsigned DEFAULT NULL,
  `player_number` int unsigned DEFAULT NULL,
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Player`
--

LOCK TABLES `Player` WRITE;
/*!40000 ALTER TABLE `Player` DISABLE KEYS */;
INSERT INTO `Player` VALUES (1,'Nathan','Drake',NULL,NULL),(2,'Donald','Duck',NULL,NULL),(3,'Johnathan','Crane',1,10),(4,'Ray','Bolger',1,11),(5,'Herald','Golpher',1,12),(6,'Oscar','Wilde',1,13),(7,'Edward','Nygma',2,20),(8,'Morgan','Hed',2,21),(9,'Alfred','Pennyworth',2,22),(10,'Titus','Vespa',2,23),(11,'Jack','Napier',3,30),(12,'Arthur','Fleck',3,31),(13,'Thomas','Payne',3,32),(14,'Joseph','Perry',3,33),(15,'Bruce','Wayne',4,40),(16,'Terry','McGinnis',4,41),(17,'Dick','Grayson',4,42),(18,'Jason','Todd',4,43);
/*!40000 ALTER TABLE `Player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Score`
--

DROP TABLE IF EXISTS `Score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Score` (
  `game_id` int unsigned NOT NULL,
  `team_id` int unsigned NOT NULL,
  `points_scored` int unsigned DEFAULT '0',
  `win_lose_tie` enum('W','L','T') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Score`
--

LOCK TABLES `Score` WRITE;
/*!40000 ALTER TABLE `Score` DISABLE KEYS */;
INSERT INTO `Score` VALUES (1,1,1,'T'),(1,2,1,'T'),(2,1,23,'W'),(2,3,10,'L'),(3,1,8,'L'),(3,4,30,'W'),(4,2,17,'T'),(4,3,17,'T'),(5,2,20,'L'),(5,4,21,'W'),(6,3,10,'L'),(6,4,30,'W');
/*!40000 ALTER TABLE `Score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Stat`
--

DROP TABLE IF EXISTS `Stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Stat` (
  `player_id` int unsigned NOT NULL,
  `height` double NOT NULL,
  `weight` double NOT NULL,
  `age` tinyint unsigned NOT NULL,
  `player_number` int unsigned DEFAULT NULL,
  PRIMARY KEY (`player_id`),
  CONSTRAINT `Stat_chk_1` CHECK ((`height` > 1)),
  CONSTRAINT `Stat_chk_2` CHECK ((`weight` > 1)),
  CONSTRAINT `Stat_chk_3` CHECK ((`age` > 15))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Stat`
--

LOCK TABLES `Stat` WRITE;
/*!40000 ALTER TABLE `Stat` DISABLE KEYS */;
INSERT INTO `Stat` VALUES (1,181.4,100.01,30,NULL),(2,159.9,70.5,23,NULL),(3,170.8,81,21,10),(4,165.1,76,28,11),(5,165.1,94.1,19,12),(6,177.1,93.41,34,13),(7,159.4,94.4,26,20),(8,164.8,91.77,38,21),(9,180.2,106.9,27,22),(10,176.3,105.37,20,23),(11,170.9,60.25,21,30),(12,170.7,100.46,20,31),(13,159.3,76.69,19,32),(14,163.5,66.36,18,33),(15,176.9,70.45,16,40),(16,159.4,67.42,24,41),(17,177.7,76.96,23,42),(18,160.2,120,21,43);
/*!40000 ALTER TABLE `Stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Team`
--

DROP TABLE IF EXISTS `Team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Team` (
  `team_id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `logo` varchar(20) DEFAULT 'NO LOGO',
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Team`
--

LOCK TABLES `Team` WRITE;
/*!40000 ALTER TABLE `Team` DISABLE KEYS */;
INSERT INTO `Team` VALUES (1,'Scarecrows','Inkblot'),(2,'Riddlers','Question Mark'),(3,'Jokers','Playing Card'),(4,'BATMAN','ManBat');
/*!40000 ALTER TABLE `Team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-14 11:25:12
