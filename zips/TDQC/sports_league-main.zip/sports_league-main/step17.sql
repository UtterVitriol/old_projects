SELECT CONCAT(first_name, ' ', last_name) AS `Tallest Player`
FROM Player INNER JOIN Stat
WHERE Player.player_id = Stat.player_id
AND Stat.height = (SELECT MAX(height) FROM Stat);
