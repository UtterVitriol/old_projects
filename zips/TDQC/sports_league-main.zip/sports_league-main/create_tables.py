from mysql_utils import get_connection


def create_table(query):
    connection = get_connection()
    sql = (query)
    cursor = connection.cursor()
    cursor.execute(sql)
    cursor.close()
    connection.close()


def main():
    query_one = ("CREATE TABLE Team ("
                 "team_id TINYINT UNSIGNED NOT NULL"
                 " AUTO_INCREMENT PRIMARY KEY, "
                 "name VARCHAR(20) NOT NULL,"
                 "logo VARCHAR(20) DEFAULT 'NO LOGO'"
                 ")")

    query_two = ("CREATE TABLE Player("
                 "player_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,"
                 "first_name VARCHAR(10) NOT NULL,"
                 "last_name VARCHAR(10) NOT NULL,"
                 "team_id INT UNSIGNED,"
                 "player_number INT UNSIGNED"
                 ")")
    query_three = ("CREATE TABLE Stat("
                   "player_id INT UNSIGNED NOT NULL PRIMARY KEY,"
                   "height DOUBLE NOT NULL CHECK(height > 100),"
                   "weight DOUBLE NOT NULL CHECK(weight > 50),"
                   "age TINYINT UNSIGNED NOT NULL CHECK(age > 15),"
                   "player_number INT UNSIGNED"
                   ")")

    query_four = ("CREATE TABLE Score("
                  "game_id INT UNSIGNED NOT NULL,"
                  "team_id INT UNSIGNED NOT NULL,"
                  "points_scored INT UNSIGNED DEFAULT 0,"
                  "win_lose_tie ENUM('W', 'L', 'T')"
                  ")")

    query_five = ("CREATE TABLE Game("
                  "game_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,"
                  "game_date DATE NOT NULL,"
                  "start_time TIME NOT NULL,"
                  "home_team INT UNSIGNED NOT NULL,"
                  "visitor_team INT UNSIGNED NOT NULL"
                  ")")

    # create_table(query_one)
    # create_table(query_two)
    # create_table(query_three)
    # create_table(query_four)
    create_table(query_five)


if __name__ == "__main__":
    main()


"""
"CREATE TABLE Team ("
team_id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,"
"name VARCHAR(20) NOT NULL, logo VARCHAR(20) DEFAULT 'NO LOGO'
")"
"""
