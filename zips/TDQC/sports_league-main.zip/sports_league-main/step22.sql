/*	Creates an alias for Team and Score to allow one for both Home and Away teams.
	From there it was a simple inner join to get the correct information showing.
*/
SELECT Game.game_id AS 'Game #', Home.name AS 'Home Team', Score.points_scored AS 'Home Score',
Away.name AS 'Away Team', Score2.points_scored AS 'Away Score'
FROM Game
INNER JOIN Team AS Home ON Game.home_team = Home.team_id
INNER JOIN Score ON Game.game_id = Score.game_id
INNER JOIN Team AS Away ON Game.visitor_team = Away.team_id
INNER JOIN Score AS Score2 ON Game.game_id = Score2.game_id
WHERE Game.home_team = Score.team_id
	AND Game.visitor_team = Score2.team_id;
