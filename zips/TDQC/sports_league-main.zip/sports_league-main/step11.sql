/*	Prints the Team name and points scored by the team that has the highest points
	scored through all games.
*/
SELECT name AS 'Team Name', SUM(points_scored) AS 'Points Scored'
FROM Score
INNER JOIN Team ON Score.team_id = Team.team_id
WHERE Score.team_id = 
	(SELECT team_id
	FROM Score
	GROUP BY team_id 
	ORDER BY SUM(points_scored) DESC
	LIMIT 1)
GROUP BY Score.team_id;
