from mysql_utils import get_connection


def do_step7():
    connection = get_connection()
    sql = ("SELECT CONCAT(FORMAT(AVG(height), 2), ' cm') as"
           " 'Average Height' from Stat")
    cursor = connection.cursor()
    cursor.execute(sql)
    for column_description in cursor.description:
        print(column_description[0])
    print(*cursor.fetchall()[0])
    cursor.close()
    connection.close()


def main():
    do_step7()


if __name__ == "__main__":
    main()
