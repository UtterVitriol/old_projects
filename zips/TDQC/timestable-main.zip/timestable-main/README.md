# Timestable

Times table is a c program that makes a timestable.

## Installation

clone or download "link"

```bash
git clone "link"
```

## Usage

```bash
./timestable [-h] [number1 1-100] [number2 1-100]
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## Memes
[Memes](https://reddit.com/r/programminghumor)
