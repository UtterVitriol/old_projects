in_int = 0
while True:
    try:
        in_int += int(input("Gimme number: "))
    except ValueError:
        print("Not a good number, fam.")
    except KeyboardInterrupt:
        print("\nHAHAHAHA! Nice try, nerd!")
    except EOFError:
        print("\nSum of nums =", in_int)

        
        
    
    
