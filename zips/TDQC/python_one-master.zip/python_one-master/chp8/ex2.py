my_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


while True:
    try:
        in_num = int(input("Gimme number: "))
    except:
        print("\nPlease enter a number\nex: 1\n")
        continue
    
    if in_num == "end":
        break
        
    try:        
        print(my_list[in_num])
    except IndexError:
        print(f"Please enter and number between 0 and {len(my_list)-1}.")
