data = True
set_numbers = set()
counter = 0

while data != "end":
    data = input("Enter number, end to quit: ")

    if data not in set_numbers and data != "end":
        set_numbers.add(data)
    else:
        counter += 1

fmt = "{}\n{}"
print(fmt.format(set_numbers, counter-1), sep=" ")
