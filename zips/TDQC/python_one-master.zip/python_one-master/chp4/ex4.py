string = input("Enter some words: ")

words = string.split()

words_dict = {}

for word in words:
    if word in words_dict:
        words_dict[word] += 1
    else:
        words_dict[word] = 1

words_sorted_words = sorted(list(words_dict))
words_sorted_count = sorted(list(words_dict.items()), key=lambda x:  x[1])

print(*words_sorted_words, sep=", ")

for word, count in words_sorted_count:
    print(word, end=", ")
