string = True

unique_words = set()

while string != "end":
    string = input("Enter some words: ")
    if string != "end":
        words = string.split()
        for word in words:
            unique_words.add(word)

print(sorted(unique_words), len(unique_words), sep="\n")
