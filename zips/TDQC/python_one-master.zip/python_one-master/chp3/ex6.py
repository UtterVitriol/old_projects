number_one = int(input("Enter low #: "))
number_two = int(input("Enter high #: "))
step = int(input("Enter step #: "))

series = range(number_one, number_two+1, step)

for number in series:
    print(number)
