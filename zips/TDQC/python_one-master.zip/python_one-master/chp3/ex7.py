fmt1 = "{:>2} "
fmt2 = "{:>2}\n"
for number in range(0, 50):
    print(fmt2.format(number) if str(number).endswith("9")
          else fmt1.format(number), end="")
