lucky_number = input("Enter a lucky number: ")

print("Not a number..." if not lucky_number.isnumeric()
      else len(lucky_number))
