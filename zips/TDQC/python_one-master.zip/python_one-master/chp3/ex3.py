number_one = input("Enter a digit: ")
number_two = input("Enter a digit: ")

outcome = number_one

if number_two > number_one:
    outcome = number_two
else:
    outcome = "They are equal"

print(outcome)
