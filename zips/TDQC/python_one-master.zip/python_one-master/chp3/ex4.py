number_one = input("Enter digit: ")
number_two = input("Enter digit: ")

numbers = range(int(number_one), int(number_two)+1)
sum_ = sum(numbers)
print(sum_)
