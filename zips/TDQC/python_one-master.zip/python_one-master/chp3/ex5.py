numbers_string = input("Enter numbers: ")

numbers_list = numbers_string.split()

for number in numbers_list:
    print(number if number.isnumeric() and int(number) > 0 else "Not digit")
