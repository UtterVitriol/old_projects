number_one = input("Enter digit: ")
number_two = input("Enter digit: ")

big_number = max(int(number_one), int(number_two))
smol_number = min(int(number_one), int(number_two))

numbers = range(smol_number, big_number+1)
sum_ = sum(numbers)
print(sum_)
