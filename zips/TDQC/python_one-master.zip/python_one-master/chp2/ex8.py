text = input("slap digis")
text_two = input("slap digis")

print(int(text) ** int(text_two))
