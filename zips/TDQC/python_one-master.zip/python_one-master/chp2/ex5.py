text = input("rad bro")

print(3.14159 * (int(text)**2))
