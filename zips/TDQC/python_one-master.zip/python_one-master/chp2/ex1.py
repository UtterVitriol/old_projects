text = input("slap dah keys")
print(text, "\n", len(text))
