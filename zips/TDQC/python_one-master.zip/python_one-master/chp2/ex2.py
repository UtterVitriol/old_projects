text_one = input("first name: ")
text_two = input("last name: ")

print(text_one, text_two, "\n", text_one[0], text_two[0])
