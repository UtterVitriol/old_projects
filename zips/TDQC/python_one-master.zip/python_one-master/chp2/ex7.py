text = input("slap da alphas")
text_two = input("slap da digis")

print(text * int(text_two))
