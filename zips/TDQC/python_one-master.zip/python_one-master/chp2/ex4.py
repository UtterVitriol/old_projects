text = input("slap da keys")

print(text[0], text.count(text[0]), text[-1], text.count(text[-1]))
