text = input("slap dig")
text_two = input("again bruh")

print(int(text) + int(text_two))

