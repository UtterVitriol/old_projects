text = input("Slap da keys")

print(text.endswith("."), text.isalpha(), "x" in text)

e = text.replace('e', 'E')

print(e)
