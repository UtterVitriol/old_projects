with open('comps.txt') as data:
    data = data.readlines()
    
print(*list({k.split()[0]: {y.split()[1]: sum([int(x.split()[2])
      for x in data if " ".join([y.split()[0], y.split()[1]]) in x])
      for y in data if k.split()[0] in y} for k in data}.items()), sep="\n")

