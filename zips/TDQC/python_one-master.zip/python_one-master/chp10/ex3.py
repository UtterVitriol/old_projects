import math
facts = {k: math.factorial(k) for k in range(1,10)}
print(facts[6] * facts[5])
