print([x for x in range(1,100) if x % 5 == 0])
