import math

print([(x, math.factorial(x)) for x in range(5, 11)])
