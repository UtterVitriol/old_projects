def longest_string(strings):
    return len(sorted(strings, key=len)[-1])
    

def main():
    collection = ["to", "tre", "four", "fivee"]
    
    fmt = "{:>{}}"
    
    for string in collection:
        print(fmt.format(string, longest_string(collection)))


if __name__ == "__main__":
    main()
