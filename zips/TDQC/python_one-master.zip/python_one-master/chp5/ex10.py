def outer():
    return lambda x: x + 1

    
beans = outer()    
print(beans(1))
