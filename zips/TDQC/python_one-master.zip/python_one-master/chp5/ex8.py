def outer(x, y):
    def inner():
        return x + y
    return inner
    
print(outer(1, 1)())
