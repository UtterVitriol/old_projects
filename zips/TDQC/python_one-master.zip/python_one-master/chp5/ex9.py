def outer():
    def inner(x, y):
        return x + y
    return inner
    
beans = outer()    
print(beans(1, 2))
