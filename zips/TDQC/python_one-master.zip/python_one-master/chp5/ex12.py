def dict_add_to_value(num, dict_):
    for key in dict_:
        dict_[key] += num
    return dict_
    

this_dict = {"one": 0, "two": 1}

print(dict_add_to_value(1, this_dict))
