def sum_(*numbers):
    output = 0
    for x in numbers:
        output += x
    return output
    
    
print(sum_(1, 1, 1, 1, 1, 1, 1, 1, 1, 1))  # 10
