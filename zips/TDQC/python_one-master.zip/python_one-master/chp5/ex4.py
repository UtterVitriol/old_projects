def sum_average(*numbers):
    output = 0
    for x in numbers:
        output += x
    output = (output, output/len(numbers))
    return output
    

print(sum_average(1, 1, 1, 1, 1, 100, 1, 1, 1, 1))  
