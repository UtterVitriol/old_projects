def iter_greater(*nums, evaluee_num):
    num_greater = 0
    
    for num in nums:
        if num > evaluee_num:
            num_greater += 1
            
    return num_greater


print(iter_greater(5, -5, -4, 3, 2, 1, evaluee_num = 0))
