def these_are_pos(numbers):
    return [pos for pos in numbers if pos.replace(".", "").isnumeric()]
    
    
num_list = ["1", "-1", "fuck", "3", "-100", "100", "9.9", "-9.9", "969.100"]

print(*these_are_pos(num_list))
