def this_exist(col, index, num):
    matches = list(filter(lambda a: a == index, col))
    
    if len(matches) >= num:
        return matches[num-1]
    else:
        return "Doesn't exist"
    
    
bean = ['a', 'b', 'c', 'a']

print(this_exist(bean, 'a', 2))
    
        
