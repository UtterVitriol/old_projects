def same_same(list1, list2):
    return(list(set(list1).intersection(set(list2))))
    
    
list1 = ["1", "2", "3"]

list2 = ["4", "5", "1"]


print(same_same(list1, list2))
