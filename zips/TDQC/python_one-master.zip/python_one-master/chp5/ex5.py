def add(int1, int2):
    return int1 + int2


def subtract(int1, int2):
    return int1 - int2


def multiply(int1, int2):    
    return int1 * int2


def divide(int1, int2):
    return int1 / int2


def quit_():
    exit()
    
choices = {"1": add, "2": subtract, "3": multiply, "4": divide, "5": quit_}
    
print("Calculator options:\n",
      "\t1.Add\n",
      "\t2.Subtract\n",
      "\t3.Multiply\n",
      "\t4.Divide\n",
      "\t5.Quit")
      
operator = input("Selection: ")
operand1 = input("Enter first operand: ")
operand2 = input("Enter second operand: ")
operand1 = int(operand1) if operand1.isnumeric() else exit("That's not an int")
operand2 = int(operand2) if operand2.isnumeric() else exit("That's not an int")



print("Answer:", choices.get(operator)(operand1, operand2))
