def is_pos_num():
    """Abide by pep257//things required to be explained...
       incoming params (unless they are named in a way that makes it clear)
       return values, if it has one
       if it might raise exception"""
    response = input("Enter a positive integer: ")
    return response if response.isnumeric() else "0"


def main():
    result = is_pos_num()
    if result == "0":
        print("Not valid positive integer.")


if __name__ == "__main__":
    main()
