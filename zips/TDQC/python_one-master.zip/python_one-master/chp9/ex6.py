import os
import sys
import time

def main(arg):
    try:
        files = os.listdir(arg[1])
        for _file in files:
            file_stat = os.stat(_file)
            file_size = file_stat.st_size
            mod_time = time.strftime("%Y-%m-%d %H:%M:%S",
                                     time.localtime(file_stat.st_mtime))
            if file_size > int(arg[2]):
                print(_file, file_size, mod_time)

    except:
        print("Usage statement")
        
if __name__ == "__main__":
    main(sys.argv)
