in_file = input("Input File: ")
out_file = input("Output File: ")

with open(in_file) as in_data, open(out_file, 'w') as out_data:
    for line in in_data.readlines():
        out_data.write(line)
