import os
import sys
import re


def meta_file(f_name, _file):
    lines = list(filter(None, _file.split('\n')))
    words = list(filter(None, re.split('[^a-zA-Z]', _file)))
    chars = [char for char in _file if char.isalpha()]
    #print("File:", f_name, "Lines:", len(lines), "Words:", len(words), 
    #      "Characters:", len(chars))
    return len(lines), len(words), len(chars)

def main(arg):
    line_count = 0
    word_count = 0
    char_count = 0
    
    if len(arg) > 1:
        for _file in arg[1:]:
            if os.path.exists(_file):
                with open(_file) as data:
                    count = meta_file(_file, data.read())
                    line_count += count[0]
                    word_count += count[1]
                    char_count += count[2]
                    
    print("Lines:", line_count, "Words:", word_count, 
          "Characters:", char_count)
            
    
    
if __name__ == "__main__":
    main(sys.argv)    
