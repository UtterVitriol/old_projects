import sys


def get_input():
    in_file = input("Input File: ")
    out_file = input("Output File: ")
    return in_file, out_file


def main(arg):
    if len(arg) == 3:
        in_file = arg[1]
        out_file = arg[2]
    else:
        in_file, out_file = get_input()
    
    
    
    with open(in_file) as in_data:
        with open(out_file, 'w') as out_data:
            for line in in_data.readlines():
                out_data.write(line)
            
            
if __name__ == "__main__":
    main(sys.argv)
