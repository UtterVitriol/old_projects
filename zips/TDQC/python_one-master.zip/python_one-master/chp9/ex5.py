import sys


def main(arg):
    if len(arg) == 3:
        in_file = arg[1]
        out_file = arg[2]
    else:
        in_file = input("Input File: ")
        out_file = input("Output File: ")
    
    
    try:
        with open(in_file) as in_data:   
            with open(out_file, 'w') as out_data:
                for line in in_data.readlines():
                    out_data.write(line)
    except OSError:
        print("File doesn't exist")
        main(arg)
            
            
if __name__ == "__main__":
    main(sys.argv)
