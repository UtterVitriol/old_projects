import os
import sys
import time


def is_in_file(file_name, names):
    try:
        with open(file_name) as data:
            data = data.readlines()
    except FileNotFoundError:
        print(f"File: {file_name} does not exist.")
        return False

    data_fixed = []
    
    for line in data:
        data_fixed.append(line.split()[0])
        
    for name in names:
        if name in data_fixed:
            names[name] += 1
    
    for line in data_fixed:
        if line not in names:
            names[line.split()[0]] = 1
                
    return names


def main(arg):
    names = {}        
    for file_name in arg[1:]:
        names = is_in_file(file_name, names)

    if names:
        names = sorted(names.items(), key=lambda x: x[0])
        for name in names:
            print(f"{name[0]:<10} {name[1]}")


if __name__ == "__main__":
    try:
        main(sys.argv)
    except (SystemExit, KeyboardInterrupt, GeneratorExit, Exception):
        print("Check your file contents")
