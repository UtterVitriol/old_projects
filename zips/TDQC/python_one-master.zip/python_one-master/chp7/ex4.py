class Worker:
    def __init__(self, name, salary, years, level=.10):
        self.name = name
        self.salary = salary
        self.years = years
        self.level = level
        
    
    def pension(self):
        return self.years * (self.salary * self.level)
        
        
    def lamaw(self):
        return "Yeet"
        
    @property
    def name(self):
        return self._name
        
    @name.setter
    def name(self, name):
        self._name = name
        
    def get_sal(self):
        return self._salary
        
    
    def set_sal(self, salary):
        self._salary = salary
        
    salary = property(get_sal, set_sal)
        
        
class Manager(Worker):
    def __init__(self, name, salary, years, level=.20):
        super().__init__(name, salary, years, level)

    
    def lamaw(self):
        return "beans"


class Executive(Manager):
    def __init__(self, name, salary, years, level=.30):
        super().__init__(name, salary, years, level)

    def lamaw(self):
        return "soup"


def main():
    bob = Worker('bob', 30000, 20)
    print(bob.pension(), bob.lamaw())
    
    beb = Manager("beb", 60000, 20)
    print(beb.pension(), beb.lamaw())
    
    bib = Executive("bib", 120000, 20)
    print(bib.pension(), bib.lamaw())
    
    print(bib.name)


if __name__ == "__main__":
    main()
    
