from ex2 import Family

def main():
    f = Family('mom', 'dad', 'kid1', 'kid2')
    b = Family('mom', 'dad', 'kid1', 'beans', 'beans')
    
    print(f)
    
    if (f > b):
        print("more")
        
    if (f == b):
        print("same")
        
    if (f < b):
        print("less")
    
if __name__ == "__main__":
    main()
