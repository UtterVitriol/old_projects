class Family:
    def __init__(self, mom, dad, *children):
        self.mom = mom
        self.dad = dad
        self.children = list(children)
        
    def __str__(self):
        return(self.mom)
        
    def __lt__(self, other):
        left = len(self.children)
        right = len(other.children)
        return left < right
        
    def __eq__(self, other):
        left = len(self.children)
        right = len(other.children)
        return left == right
        
    def __gt__(self, other):
        left = len(self.children)
        right = len(other.children)
        return left > right
        
    def add(self, child):
        self.children.append(child)


class Person:
    def __init__(self, name, age, gender):
        self.name = name
        self.age = age
        self.gender = gender
        
    def __str__(self):
        return self.name


def main():
    dad = Person("Bobbert", 45, 'M')
    mom = Person("Marge", 30, 'F')
    kid1 = Person("Yeet", 10, 'm')
    kid2 = Person("Billy", 12, 'm')
    family = Family(mom, dad, kid1, kid2)
    print(family)
    
    
if __name__ == "__main__":
    main()
