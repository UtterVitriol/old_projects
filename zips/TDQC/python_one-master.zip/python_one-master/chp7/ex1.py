class Person:
    def __init__(self, name, age, gender):
        self.name = name
        self.age = age
        self.gender = gender
        
    def __str__(self):
        return self.name

def main():
    bob = Person('Bobert Helton',23, "m")
    print(bob)
    

if __name__ == "__main__":
    main()
