#!/usr/bin/env python3
"""Text viewer wowee"""

from tkinter import *

window = Tk()
window.configure(bg="grey")


def get_text():
    with open(text.get("1.0", "end-1c")) as f:
        read_data = f.read()
        text1.delete("1.0", "end-1c")
        text1.insert(END, read_data)


def del_text():
    text1.delete("1.0", END)


label = Label(window, text="Enter File Name", bg="grey", fg="black",
              highlightbackground="grey").pack()

text = Text(window, height=1, width=30)
text.pack()

frame = Frame(window)

button1 = Button(frame, text="Display File", command=get_text,
                 bg="grey", fg="black", highlightbackground="grey")
button1.pack(side=LEFT)

button2 = Button(frame, text="DeleteText", command=del_text,
                 bg="grey", fg="black", highlightbackground="grey")
button2.pack(side=LEFT)

button3 = Button(frame, text="Exit App", command=window.quit,
                 bg="grey", fg="black", highlightbackground="grey")
button3.pack(side=LEFT)

frame.pack()

text1 = Text(window, height=10, width=50, bg="black",
             fg="red")
text1.pack(fill=BOTH, expand=1)
window.mainloop()
