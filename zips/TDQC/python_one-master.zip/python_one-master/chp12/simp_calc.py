#!/usr/bin/env python3
"""A simple add/multiply calc"""

import tkinter as tk


def add():
    text_box_answer.delete("1.0", END)
    text_box_answer.insert(tk.END,
                           str(int(text_box_one.get("1.0", END)) +
                               int(text_box_two.get("1.0", END))))


def mult():
    text_box_answer.delete("1.0", END)
    text_box_answer.insert(tk.END,
                           str(int(text_box_one.get("1.0", END)) *
                               int(text_box_two.get("1.0", END))))


window = tk.Tk()

label_one = tk.Label(window, text="Enter first number").pack()

text_box_one = tk.Text(window, height=1, width=30).pack()

label_two = tk.Label(window, text="Enter second number").pack()

text_box_two = tk.Text(window, height=1, width=30).pack()

label_answer = tk.Label(window, text="Answer").pack()

text_box_answer = tk.Text(window, height=1, width=30).pack()

button_add = tk.Button(window, width=10, text="ADD", command=add).pack()

button_mult = tk.Button(window, width=10, text="MULT",
                        command=mult).pack()

button_exit = tk.Button(window, width=10, text="exit",
                        command=window.quit).pack()

window.mainloop()
