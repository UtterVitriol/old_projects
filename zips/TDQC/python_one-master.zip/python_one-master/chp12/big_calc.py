#!/usr/bin/env python3
"""What am I doing with my life?????
   fix this program"""

from tkinter import *

history_duhh = []


def record(x, y, outcome, operator):
    global history_duhh
    fmt = "{} {} {} = {}"
    operation = fmt.format(x, operator, y, outcome)
    history_duhh.append(operation)


def add():
    answer.delete("1.0", END)
    x = int(first.get("1.0", END))
    y = int(second.get("1.0", END))
    z = str(x+y)
    answer.insert(END, z)
    record(x, y, z, "+")


def mult():
    answer.delete("1.0", END)
    x = int(first.get("1.0", END))
    y = int(second.get("1.0", END))
    z = str(x*y)
    answer.insert(END, z)
    record(x, y, z, "*")


def power():
    x = int(first.get("1.0", END))
    y = int(second.get("1.0", END))
    z = str(x ** y)
    answer.insert(END, z)
    record(int(x), int(y), z, "^")


def clear():
    first.delete("1.0", END)
    second.delete("1.0", END)
    answer.delete("1.0", END)


def disp_hist():
    for x in history_duhh:
        print(x)


window = Tk()

menubar = Menu(window)

func_menu = Menu(menubar, tearoff=0)
func_menu.add_command(label="add", command=add)
func_menu.add_command(label="mult", command=mult)
func_menu.add_command(label="raise", command=power)
menubar.add_cascade(label="Functions", menu=func_menu)

exit_menu = Menu(menubar, tearoff=0)
exit_menu.add_command(label="Clear", command=clear)
exit_menu.add_command(label="Exit", command=window.quit)
menubar.add_cascade(label="Exit", menu=exit_menu)

window.config(menu=menubar)

label = Label(window, text="Select from the following choices")
label.pack()

btns = Frame(window)

add = Button(btns, text="add", command=add)
add.pack(side=LEFT)

mult = Button(btns, text="mult", command=mult)
mult.pack(side=LEFT)

rais_e = Button(btns, text="raise", command=power)
rais_e.pack(side=LEFT)

goodbye = Button(btns, text="exit", command=window.quit)
goodbye.pack(side=LEFT)

clear = Button(btns, text="clear", command=clear)
clear.pack(side=LEFT)

btns.pack()

boxes = Frame(window, bg="grey")

label1 = Label(boxes, text="First Value here")
label1.pack()

first = Text(boxes, height=1, width=20)
first.pack()

label2 = Label(boxes, text="Second Value here")
label2.pack()

second = Text(boxes, height=1, width=20)
second.pack()

label3 = Label(boxes, text="Answer Here")
label3.pack()

answer = Text(boxes, height=1, width=20)
answer.pack()

boxes.pack(fill=BOTH, expand=1)

hist = Frame(window)

hist_btn = Button(hist, text="Display History", command=disp_hist)
hist_btn.pack(fill=BOTH, expand=1)

hist.pack(fill=BOTH, expand=1)

window.mainloop()
