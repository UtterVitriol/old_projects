#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
"""See main"""
import sys


def main(nums):
    '''Prints range.
    
       Requires three command line arguments:
       Start: positive integer
       Stop:  positive integer
       Step:  positive integer
    '''
    range_nums = [int(x) for x in nums if x.isnumeric()]

    if len(range_nums) != 3 or range_nums[2] == 0:
        print("Please provide 3 integers")
    else:
        range_result = range(*range_nums)
        for num in range_result:
            print(num)


if __name__ == '__main__':
    main(sys.argv)
