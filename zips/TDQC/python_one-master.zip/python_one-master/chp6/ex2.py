import ex1

def meme():
    return ex1.meme
    
    
def main():
    meme()()
    

if __name__ == "__main__":
    main()
