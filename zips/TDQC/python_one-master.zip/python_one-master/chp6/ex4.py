#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#

def main(args):
    added = sum([int(x) for x in args[1:]])
    avg = added / len(args[1:])
    print(added, avg)
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
