import ex1
import ex2



def main():
    ex1.meme()

    ex2.meme()()
    
    ex1.meems()()()
    
    
if __name__ == "__main__":
    main()
