#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#

def main(args):
    print(sorted(sys.argv))
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
