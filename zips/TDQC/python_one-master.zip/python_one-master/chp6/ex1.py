import ex2


def meme():
    print("yeet")
    

def meems():
    return ex2.meme    
    




def main():
    meme()
    
    
if __name__ == "__main__":
    main()
