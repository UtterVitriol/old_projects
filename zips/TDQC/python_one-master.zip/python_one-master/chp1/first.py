#!/usr/bin/env python3
"""This is fun."""

did_i_win = "Heh?"

yeet = 2

beans = 12

soup = yeet + beans

print(soup)
