// Paul Burkhardt
// 01/06/2020
//
// Tutorial for a max heap.
//------------------------------------------------------------------------------
#ifndef __MAX_HEAP_
#define __MAX_HEAP_
void heapsort(int, int*);
void buildheap(int, int*);
void heapify_downshift(int, int*, int);
void heapify_upshift(int, int*);
void heap_insert(int, int*, int);
void heap_extract(int, int*);
int heap_order(int, int*);
#endif
