// Paul Burkhardt
// 01/06/2020
//
// Tutorial for a max heap.
//
// Each node in the heap tree has a larger value than its children. The heap is
// a complete binary tree and filled in level order from left to right.
//
// The heap is stored in an array where a node i has children at indices 2i,
// 2i+1 or 2i+1, 2i+2 if using zero indexing. Then a node i has a parent at
// floor(i/2) or if zero indexing then at floor((i-1)/2).
//------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <max_heap.h>
//------------------------------------------------------------------------------
void heapify_downshift(int n, int* a, int i)
{
  int l = 2*i+1;
  int r = l+1;
  int j = 0;
  if (l < n)
  {
    // Select the larger of the two siblings.    
    if (r > n-1)
    {
      r = l;
    }
    if (a[l] > a[r])
    {
      j = l;
    }
    else
    {
      j = r;
    }
    if (a[i] < a[j])
    {
      // Exchange child with parent if child has larger value.
      int tmp = a[i];
      a[i] = a[j];
      a[j] = tmp;

      // Move down to children.
      heapify_downshift(n, a, j);
    }
  }
}

void heapify_upshift(int i, int* a)
{
  // New nodes are added to the leaf level in level order (left to right). A new
  // child node that is greater than its parent must also be greater than any
  // existing sibling, then maintaining heap order requires only exchanging the
  // new child node with each ancestor of lesser value. Hence only ancestors in
  // the lineage are evaluated in the path from leaf to root.
  int p = (i-1)/2;
  if (a[i] > a[p])
  {
    int tmp = a[i];
    a[i] = a[p];
    a[p] = tmp;
    heapify_upshift(p, a);
  }
}

void heapsort(int n, int* a)
{
  if (n > 1)
  {
    int tmp = a[0];
    a[0] = a[n-1];
    a[n-1] = tmp;
    n = n-1;
    int i = 0;
    heapify_downshift(n, a, i);
    heapsort(n,a);
  }
}

void buildheap(int n, int* a)
{
  // The leaf level is trivially in heap order, so begin at the level before it.
  //
  // Start from next to last level and downshift heapify from each node, working
  // up to the root node in reverse level order. Thus start from the last node
  // in the next to last level and work right to left. The start node is simply
  // the parent of the last node, so begin at node i = floor(n-1/2) for zero
  // indexing and work up to the root node i = 0.
  for (int i = (n-1)/2; i >= 0; --i)
  {
    heapify_downshift(n, a, i);
  }
}

void heap_insert(int n, int* a, int i)
{
  // Add new item to end.
  a[n] = i;
  ++n;
  if (n == 1) return;
  
  // Upshift heapify.
  //
  // NOTE: Can save one extra move by swapping a new item with the root if the
  // new item is greater.
  heapify_upshift(n-1, a);
}

void heap_extract(int n, int* a)
{
  // Downshift heapify.
  --n;
  a[0] = a[n];
  heapify_downshift(n, a, 0);
}

int heap_order(int n, int* a)
{
  // Return true if array is in heap order.
  int order = 1;
  for (int i = 0; i < n; ++i)
  {
    int l = 2*i+1;
    int r = l+1;
    if (l < n)
    {
      if (a[i] < a[l] || a[i] < a[r])
      {
        order = 0;
        break;
      }
    }
  }
  return order;
}
