//https://stackoverflow.com/questions/2597608/c-socket-connection-timeout
//https://www.geeksforgeeks.org/socket-programming-cc/

/*
 * *slaps code* This bad boy probably shouldn't work at all....
 * 
 * suggest setting font size of terminal to 8
*/

#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <ctype.h>
#include <wchar.h>
#include <locale.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <wctype.h>

#include "battleship.h"

#define PORT 6666

int connect_server(int *, char *, int *);

int init_game(void);

int new_game(int, int, int, int);

int load_game(int, int);

int save_game(int, struct player *);

int game_loop(struct player *, int, int, int);

struct map_grid generate_grid(int, int, int);

int place_boats(struct map_grid *, int);

int get_coords(int, wchar_t, int *, struct map_grid *, int, const char *);

int update_map(int, wchar_t, int *, struct map_grid *);

int check_guess(int, int, struct player *, int);

int free_grid(struct player *);

int get_input(char *);

void clear_buffer(char *, int);

void print_grid(struct map_grid *);

int int_from_str(char *, int *);

void print_sick_logo(void);

void print_hit(void);

void print_miss(void);

void winner_winner_chicken_dinner(void);

void loser_loser_you_suck(void);


void sigintHandler(int sig_num)
{
	// catches sneaky ctrl+c's

	signal(SIGINT, sigintHandler);
	puts("\nPlease press ctrl+d to exit...\n");
}

int main(int argc, char *argv[])
{
	srand((unsigned)time(NULL));
	setlocale(LC_ALL, "");
	signal(SIGINT, sigintHandler);
	init_game();
}

int connect_server(int *sock, char *ip, int *player)
{
	// bippity boppity connecty server

	struct sockaddr_in serv_addr;
	char buffer[100] = {0};
	fd_set fdset;
	struct timeval tv;
	
	// I copy pasted this
	if((*sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		puts("Socket Error...");
		return 2;
	}
	
	// I also copy pasted this
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(PORT);
	
	// I also copy pasted this
	if(inet_pton(AF_INET, ip, &serv_addr.sin_addr) <= 0)
	{
		puts("Invalid Address...");
		return 2;
	}
	
	// a big ctrl+c followed by a fat ctrl+v
	long arg;
	arg = fcntl(*sock, F_GETFL, NULL);
	arg |= O_NONBLOCK;
	fcntl(*sock, F_SETFL, arg);
	
	printf("Connecting to server...\n");
	
	// I also copy pasted this..mostly
	int res;
	res = connect(*sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if(res < 0){
		FD_ZERO(&fdset);
		FD_SET(*sock, &fdset);
		tv.tv_sec = 3;
		tv.tv_usec = 0;
		res = select(*sock + 1, NULL, &fdset, NULL, &tv);
		if(res > 0)
		{
			int so_error;
			socklen_t len = sizeof(so_error);
			
			if(getsockopt(*sock, SOL_SOCKET, SO_ERROR, &so_error, &len) < 0){
				puts("Error in  getsockopt");
				return 2;
			}
			
			if(so_error){
				printf("\nError in connection...\n");
				close(*sock);
				return 2;
			}
		}else if(res < 0){
			puts("Error in connection..\n");
			return 2;
		}else{
			printf("Connection timed out...");
			return 2;
		}
	}
	
	// I also copy pasted this
	arg = fcntl(*sock, F_GETFL, NULL);
	arg &= (~O_NONBLOCK);
	fcntl(*sock, F_SETFL, arg);
	
	puts("Connected to server...");
	puts("Waiting for other player...");
	
	read(*sock, buffer, 100);
	
	*player = atoi(buffer);
	
	
	return 0;
}

int init_game(void)
{
	/* main menu
	 * gets user input
	 * starts new game or loads a saved game
	 */

	char choice[17] = {'\0'};
	char buffer[10] = {'\0'}, *b_ptr = NULL;
	int coords[2] = {0};
	int sock, player;
	
	system("clear");
	print_sick_logo();
	
	while(1){
		puts("");
		puts("Enter ip address of server");
		printf("> ");
		
		if(get_input(choice)){
			exit(1);
		}
		
		choice[strlen(choice) - 1] = '\0';

		if(connect_server(&sock, choice, &player) != 0){
			puts("");
			continue;
		}
		
		clear_buffer(buffer, 10);
		read(sock, buffer, 10);
		
		if(atoi(buffer) == 1){
			system("clear");
			print_sick_logo();
			
			read(sock, buffer, 1024);
			
			coords[0] = strtol(buffer, &b_ptr, 10);
			int_from_str(b_ptr, &coords[1]);
			
			puts("Sarting Game....");
			
			new_game(player, coords[0], coords[1], sock);
			
			break;
		}else if(atoi(buffer) == 2){
			load_game(sock, player);
			
			break;
		}else{
			puts("something broke...");
			//system("clear");
			//bad_input = 1;
			continue;
		}
	}
	return 0;
}

int new_game(int player, int x, int y, int sock)
{
	/* new game
	 * inits player one and player two
	 */

	struct player p_one;
	char buffer[3] = {0};
	
	int p = 1;
	
	if(player == 1){
		p = 2;
	}
	
	p_one.boats_health = 2;//19;
	
	p_one.guess = generate_grid(x, y, 0);
	p_one.boats = generate_grid(x, y, 1);
	
	if(place_boats(&p_one.boats, player)){
		send(sock, "1", 1, 0);
		close(sock);
		free_grid(&p_one);
		exit(1);
	}
	
	send(sock, "0", 1, 0);
	
	system("clear");
	print_sick_logo();
	printf("\nWaiting for other player...\n");
	
	read(sock, buffer, 3);
	
	if(atoi(buffer)){
		printf("Player %d disconnected...", p);
		close(sock);
		free_grid(&p_one);
		exit(1);
	}
	
	read(sock, buffer, 3);

	if(player == 1){
		game_loop(&p_one, player, 0, sock);
	}else{
		game_loop(&p_one, player, 1, sock);
	}

	return 0;
}

int game_loop(struct player *p_one, int player, int turn, int sock)
{
	/* main game loop
	 * gets x/y coodinates from players or calls save_game
	 */

	char input_x[17] = {'\0'};
	char input_y[17] = {'\0'};
	char guess[6] = {'\0'};
	char buffer[17] = {'\0'}, *b_ptr;
	
	int guess_x = 0;
	int guess_y = 0;
	int bad_input = 0;
	int game_over = 0;
	
	int p = 2;
	
	if(player == 2){
		p = 1;
	}
	
	while(!game_over){
		
		
		if(turn == 1){
			system("clear");
			print_sick_logo();
			print_grid(&p_one->guess);
			printf("Waiting for player %d...\n", p);
			read(sock, buffer, 10);
			
			if(atoi(buffer) == 100){
				save_game(sock, p_one);
				free_grid(p_one);
				close(sock);
				printf("Player %d disconnected...\n", p);
				exit(1);
			}
			
			guess_x = strtol(buffer, &b_ptr, 10);
			int_from_str(b_ptr, &guess_y);
			
			// check that shit
			if(check_guess(guess_x, guess_y, p_one, sock)){
				free_grid(p_one);
				close(sock);
				loser_loser_you_suck();
				exit(1);
			}
			
			// pause to show player guess response
			system("clear");
			print_sick_logo();
			print_grid(&p_one->boats);
			
			printf("Turn: %d\n", turn);
			puts("Press enter to continue...");
			if(get_input(input_x)){
				free_grid(p_one);
				exit(1);
			}
			
			turn = 0;
			
		}
		
		system("clear");
		print_sick_logo();
		print_grid(&p_one->guess);
		
		if(bad_input){
			puts("Bad guess. Try again...");
			bad_input = 0;
		}
		
		printf("Enter x coordinate guess (1 - %d)\n", p_one->guess.x);
		printf("Player_%d-> ", player);
		
		// get input
		if(get_input(input_x)){
			send(sock, "3", 1, 0);
			save_game(sock, p_one);
			close(sock);
			free_grid(p_one);
			exit(1);
		}
		
		// check if guess is int
		if(atoi(input_x) == 0){
			bad_input = 1;
			continue;
		}
		
		// set guess x
		guess_x = atoi(input_x) - 1;
		
		system("clear");
		print_sick_logo();
		print_grid(&p_one->guess);
		
		printf("Enter y coordinate guess (1 - %d)\n", p_one->guess.y);
		printf("Player_%d-> ", player);
		
		// get input
		if(get_input(input_y)){
			send(sock, "3", 1, 0);
			save_game(sock, p_one);
			close(sock);
			free_grid(p_one);
			exit(1);
		}
		
		// check if guess is int
		if(atoi(input_y) == 0){
			bad_input = 1;
			continue;
		}
		
		// set guess y
		guess_y = atoi(input_y) - 1;
		
		// check if guess is out of bounds
		if(guess_x > p_one->boats.x - 1 || guess_y > p_one->boats.y - 1){
			bad_input = 1;
			continue;
		}
		
		// check if guess is out of bounds
		if(guess_x < 0 || guess_y < 0){
			bad_input = 1;
			continue;
		}
		
		// check if hit or miss
		sprintf(guess, "%d %d", guess_x, guess_y);
		
		puts("here");
		send(sock, guess, 6, 0);
	
		
		
		while(read(sock, buffer, 6) < 0){}
		
		if(atoi(buffer) == 1){
			p_one->guess.grid[guess_y][guess_x] = 'H';
			system("clear");
			print_hit();
			sleep(2);
		}else if(atoi(buffer) == 2){
			p_one->guess.grid[guess_y][guess_x] = 'M';
			system("clear");
			print_miss();
			sleep(2);
		}else if(atoi(buffer) == 3){
			close(sock);
			free_grid(p_one);
			winner_winner_chicken_dinner();
			exit(1);
		}
		
		turn = 1;
	}
	
	// game over, print obnoxious win text
	winner_winner_chicken_dinner();
	
	return 0;
}

int check_guess(int x_guess, int y_guess, struct player *p_one, int sock)
{
	/* checks player guess
	 * updates grids based on guess
	 */

	if(p_one->boats.grid[y_guess][x_guess] != L' ' && \
	   p_one->boats.grid[y_guess][x_guess] != L'🌀' && \
	   p_one->boats.grid[y_guess][x_guess] != L'💥'){
		// player got a hit
		
		// change opponet boats map at coord to ' ' (space)
		p_one->boats.grid[y_guess][x_guess] = L'💥';
		
		// decrement opponent boats_health
		p_one->boats_health -= 1;
		
		// return 1 for win condition
		if(p_one->boats_health == 0){
			send(sock, "3", 1, 0);
			return 1;
		}
		
		//send hit
		send(sock, "1", 1, 0);
		
		// prints hit ascii art
		print_hit();
		sleep(2);
	}else{
		// player missed
		
		p_one->boats.grid[y_guess][x_guess] = L'💥';
		//send miss
		send(sock, "2", 1, 0);
		
		// print miss ascii art
		print_miss();
		sleep(2);
	}

	return 0;
}

struct map_grid generate_grid(int x_axis, int y_axis, int is_boats)
{
	/* mallocs 2d array for map grid
	 * populates 2d array with whitespace
	 */
	struct map_grid map;
	
	int temp = 0;
	
	map.x = x_axis;
	map.y = y_axis;
	
	// malloc 'y axis'
	map.grid = malloc(map.y * sizeof(wchar_t *));
	
	// malloc 'x axis'
	for(int i = 0; i < map.y; i ++){
		map.grid[i] = malloc(map.x * sizeof(wchar_t));
	}
	
	
	
	// populate grid with whitespace and random obstacles
	for(int i = 0; i < map.y; i++){
		for(int j = 0; j < map.x; j++){
			
			temp = (rand() % 100);
			if(is_boats){
				if(temp < 25){
					map.grid[i][j] = L'🌀';
				}else{
					map.grid[i][j] = ' ';
				}
			}else{
				map.grid[i][j] = ' ';
			}
			
		}
	}
	
	return map;
}

void print_grid(struct map_grid *map)
{
	/* prints map grid with flourishes and numbers
	 */
	
	char temp[5];
	sprintf(temp, "%d", map->y);
	
	// gets # of digits in largest number for margin
	//int marg = strlen(temp);  
	
	// print first line
	printf("%s", "\xE2\x94\x8c");
	printf("%s", "\xE2\x94\x80");
	printf("%s", "\xE2\x94\x80");
	
	for(int i = 0; i < map->x * 4 + 1; i++){
		if(i > 0 && i % 4 == 1){
				printf("%s", "\xE2\x94\xac");
			}else{
				printf("%s", "\xE2\x94\x80");
			}
	}
	
	printf("%s", "\xE2\x94\x90");
	
	puts("");
	
	// print second line
	printf("%s   %s","\xE2\x94\x82", "\xE2\x94\x82");
	
	for(int i = 0; i < map->x; i ++){
		printf("%2d %s", i + 1, "\xE2\x94\x82");
	}
	
	puts("");
	
	// print third line
	printf("%s", "\xE2\x94\x9c");
	
	for(int i = 0; i < map->x * 4 + 2; i++){
		if(i > 0 && i % 4 == 3){
				printf("%s", "\xE2\x94\xbc");
			}else{
				printf("%s", "\xE2\x94\x80");
			}
	}
	
	printf("%s", "\xE2\x94\x80");
	printf("%s", "\xE2\x94\xa4");
	
	puts("");
	
	// print the rest of the grid
	for(int i = 0; i < map->y; i++){
		printf("%s%3d%s", "\xE2\x94\x82", i + 1, "\xE2\x94\x82");
		
		for(int j = 0; j < map->x; j++){
			if(map->grid[i][j] == L'⏅'){
				printf(" %s %s", "\xE2\x8F\x85", "\xE2\x94\x82");
			}else if(map->grid[i][j] == L'⛴'){
				printf(" %s %s", "\xE2\x9B\xB4", "\xE2\x94\x82");
			}else if(map->grid[i][j] == L'🛥'){
				printf(" %s %s", "\xF0\x9F\x9B\xA5", "\xE2\x94\x82");
			}else if(map->grid[i][j] == L'🛳'){
				printf(" %s %s", "\xF0\x9F\x9B\xB3", "\xE2\x94\x82");
			}else{
				printf("%2lc %s", map->grid[i][j], "\xE2\x94\x82");
			}
		}
		
		puts("");
		
		for(int j = 0; j < map->x * 4 + 5; j++){
			if(i < map->y - 1 &&  j == 0){
				printf("%s", "\xE2\x94\x9c");
				continue;
			}
			
			if(i == map->y - 1 && j == 0){
				printf("%s", "\xE2\x94\x94");
				continue;
			}
			
			if(j > 0 && j % 4 == 0){
				if(j == (map->x * 4 + 4) && i == map->y - 1){
					printf("%s", "\xE2\x94\x98");
					break;
				}
				
				if(i < map->y - 1 && j == (map->x * 4 + 4)){
					printf("%s", "\xE2\x94\xa4");
				}else{
					if(i == map->y - 1){
						printf("%s", "\xE2\x94\xb4");
					}else{
						printf("%s", "\xE2\x94\xbc");
					}
				}
			}else{
				printf("%s", "\xE2\x94\x80");
			}
		}
		puts("");
	}
}

int update_map(int len, wchar_t boat, int *coords, struct map_grid *map)
{
	/* places boat chars on player map if there is space
	 */

	int x1 = coords[0];
	int y1 = coords[1];
	int x2 = coords[2];
	int y2 = coords[3];
	
	// check for diagonal coordinates
	if(x1 != x2 && y1 != y2){
		return 1;
	}
	
	// reverses coordinates to be low to high
	if((x1 + y1) > (x2 + y2)){
		x1 = coords[2];
		y1 = coords[3];
		x2 = coords[0];
		y2 = coords[1];
	}
	
	// check if there is space for boat
	for(int i = 0; i < len; i++){
		if(x1 == x2){
			if(map->grid[y1 + i][x1] != ' '){
				return 1;
			}
		}else{
			if(map->grid[y1][x1 + i] != ' '){
				return 1;
			}
		}
	}
	
	// place boat
	for(int i = 0; i < len; i++){
		if(x1 == x2){
			map->grid[y1 + i][x1] = boat;
		}else{
			map->grid[y1][x1 + i] = boat;
		}
	}
	
	return 0;
}

int get_coords(int num, wchar_t boat_char, int *coords, struct map_grid *map,\
	       int player_num, const char *boat)
{
	/* gets coordinates from player to place boats on their boat grid
	 */

	char coord[17] = {'\0'};
	
	char axis[4] = {'x', 'y', 'x', 'y'};
	
	int lens[4] = {map->x, map->y, map->x, map->y};
	
	static int bad_input = 0;
	
	int result = 0;
	
	for(int i = 0; i < 4; i++){
		system("clear");
		print_sick_logo();
		print_grid(map);
		
		if(bad_input){
			puts("Bad input, try again...");
			printf("You need to input the coordinates at the ");
			printf("ends of %d spaces\n\n", num);
			bad_input = 0;
		}
		
		printf("Enter %s coordinates.\n", boat);
		printf("The %s is %d spaces long.\n", boat, num);
		
		if(i < 2){
			printf("Enter %c coordinate # 1 (1 - %d)\n", axis[i],\
			       lens[i]);
		}else{
			printf("Enter %c coordinate # 2 (1 - %d)\n", axis[i],\
			       lens[i]);
		}
		
		printf("Player_%d-> ", player_num);
		
		if(get_input(coord)){
			return 2;
		}
		
		if(atoi(coord) == 0){
			bad_input = 1;
			return 1;
		}
		
		coords[i] = atoi(coord);
		
		// check if coordinates are out of bounds
		if(i % 2 == 0){
			if(coords[i] < 1 || coords[i] > map->x){
				bad_input = 1;
				return 1;
			}
		}else{
			if(coords[i] < 1 || coords[i] > map->y){
				bad_input = 1;
				return 1;
			}
		}
		
		// decrement coords to match index
		coords[i]--;
	}
	
	// check if coordinates equals the correct number of spaces
	if(abs((coords[0] + coords[1]) - (coords[2] + coords[3])) + 1 != num){
		bad_input = 1;
		return 1;
	}else{
		result = update_map(num, boat_char, coords, map);
		
		if(result == 1){
			bad_input = 1;
			return 1;
		}else{
			return result;
		}
	}
}

int place_boats(struct map_grid *map, int player_num)
{
	/* loops through boats and calls get_coords
	 */

	char input[17] = {'\0'};
	int boat_lens[] = {2, 2, 3, 3, 4, 5};
	wchar_t boat_chars[] = {L'⏅', L'⛵', L'⛴', L'🛥', L'🛳', L'🚢'};
	const char *boats[] = {"Patrol Boat", "Sumbarine", "Cruiser",\
			       "Destroyer", "Battleship", "Aircraft Carrier"};
			 
	int coords[4] = {0};
	int check = 3;
	
	for(int i = 0; i < 1; i++){
		while(1){
			check = get_coords(boat_lens[i], boat_chars[i],\
					   coords, map, player_num, boats[i]);
			
			if(check == 2){
				return 1;
			}else if(check == 0){
				break;
			}
		}
		system("clear");
		print_sick_logo();
		print_grid(map);
		
		puts("Press enter to continue...");
		
		if(get_input(input)){
			return 1;
		}
	}
	
	return 0;
}


int load_game(int sock, int player)
{
	// loads previous save game

	int temp_x = 0;
	int temp_y = 0;
	int temp_health = 0;
	int temp_turn = 0;
	
	struct player p_one;
	
	char *temp_field = NULL;
	
	wchar_t *temp_wfield = NULL;
	
	char buffer[10] = {'\0'}, *b_ptr = NULL;
	
	// get coords
	read(sock, buffer, 10);

	temp_x = strtol(buffer, &b_ptr, 10);
	int_from_str(b_ptr, &temp_y);
	
	int size = ((((temp_x + 1) * temp_y) * 2) - 1) * 4 ;
	int wsize = (((temp_x + 1) * temp_y) * 2) - 1;
	
	if((temp_field = calloc(sizeof(char), size + 1)) == NULL){
		puts("bad calloc");
	}
	
	if((temp_wfield = calloc(sizeof(wchar_t), wsize + 2)) == NULL){
		puts("bad calloc 2");
	}
	
	
	// alloc grids
	p_one.guess = generate_grid(temp_x, temp_y, 0);
	p_one.boats = generate_grid(temp_x, temp_y, 0);
	
	// get health
	clear_buffer(buffer, 10);
	read(sock, buffer, 10);
	temp_health = strtol(buffer, &b_ptr, 10);
	
	// set boat healths
	p_one.boats_health = temp_health;
	
	// get turn
	clear_buffer(buffer, 10);
	read(sock, buffer, 10);
	temp_turn = strtol(buffer, &b_ptr, 10);
	
	// get maps
	read(sock, temp_field, size);
	swprintf(temp_wfield, wsize + 1, L"%s", temp_field);
	
	struct map_grid *temp_map;
	temp_map = &p_one.guess;
	int y = 0;
	int x = 0;
	
	// populate grids
	for(int i = 0; i < wsize; i++){
		
		// check if end of first grid
		if(y == temp_y){
			temp_map = &p_one.boats;
			y = 0;
			x = 0;
		}
		
		// new line
		if(temp_wfield[i] == L'\n'){
			x = 0;
			y++;
			continue;
		}
		
		// debug code
		if(x == temp_x || y == temp_y + 1){
			puts("your logic is trash");
			printf("x: %d y: %d", x, y);
			break;
		}
		
		temp_map->grid[y][x] = temp_wfield[i];
		x++;
	}

	free(temp_field);
	free(temp_wfield);
	game_loop(&p_one, player, temp_turn, sock);
	free_grid(&p_one);
	return 0;
}

int save_game(int sock, struct player *p_one)
{
	// sends current game state to server

	char *grids = NULL;
	wchar_t *wgrids = NULL;
	int temp_x = p_one->guess.x;
	int temp_y = p_one->guess.y;
	
	int size = (((((temp_x + 1) * temp_y)) * 2) ) * 4 ;
	int wsize = ((((temp_x + 1) * temp_y)) * 2);
	
	if((grids = calloc(sizeof(char), size + 1)) == NULL){
		puts("bad calloc");
	}
	
	if((wgrids = calloc(sizeof(wchar_t), wsize + 1)) == NULL){
		puts("bad calloc 2");
	}
	
	int count = 0;
	
	for(int i = 0; i < temp_y; i++){
		for(int j = 0; j < temp_x; j++){
			wgrids[count] = p_one->guess.grid[i][j];
			count++;
		}
		wgrids[count] = L'\n';
		count++;
	}
	
	for(int i = 0; i < temp_y; i++){
		for(int j = 0; j < temp_x; j++){
			wgrids[count] = p_one->boats.grid[i][j];
			count++;
		}
		
		wgrids[count] = L'\n';
		count++;
	}
	
	sprintf(grids, "%ls", wgrids);
	
	send(sock, grids, strlen(grids), 0);
	
	free(grids);
	free(wgrids);
	return 0;
}

int free_grid(struct player *one)
{
	/* frees 2d grid arrays
	 */
	struct map_grid maps[2] = {one->guess, one->boats};
	
	for(int i = 0; i < 2; i ++){
		for(int j = 0; j < maps[i].y; j++){
			free(maps[i].grid[j]);
		}
	
		free(maps[i].grid);
	}
	
	return 0;
}


int get_input(char *input)
{
	/* get user input and drain stdin
	 */

	char dumpster[10] = {'\0'};
	
	if(fgets(input, 17, stdin) == NULL){
		return 1;
	}
	
	if(!strchr(input, '\n')){
		while(!strchr(dumpster, '\n')){
			if(fgets(dumpster, 10, stdin) == NULL){
				return 1;
			}
		}
	}
	
	return 0;
}






void print_sick_logo(void)
{
	/* prints the battleship asci art
	 */

	for(int i = 0; i < 67; i++){
		printf("%s", "\xE2\x94\x8b");
	}
	
	puts("");
	
	printf("%s\n", logo_one);
	printf("%s\n", logo_two);
	printf("%s\n", logo_three);
	printf("%s\n", logo_four);
	printf("%s\n", logo_five);
	printf("%s\n", logo_six);
	
	puts("");
	
	for(int i = 0; i < 67; i++){
		printf("%s", "\xE2\x94\x8b");
	}
	puts("");
}

void print_hit(void)
{
	// print hit ascii art

	system("clear");
	
	puts(hit_one);
	puts(hit_two);
	puts(hit_three);
	puts(hit_four);
	puts(hit_five);
	puts(hit_six);
	puts(hit_seven);
	puts(hit_eight);
	puts(hit_nine);
	
}

void print_miss(void)
{
	// print miss ascii art

	system("clear");
	
	puts(miss_one);
	puts(miss_two);
	puts(miss_three);
	puts(miss_four);
	puts(miss_five);
	puts(miss_six);
	puts(miss_seven);
	puts(miss_eight);
	puts(miss_nine);
	
}

void winner_winner_chicken_dinner(void)
{
	// print obnoxious win text

	system("clear");

	for(int i = 0; i < 1000; i++){
		printf("_-WINNER_-");
		fflush(stdout);
		usleep(20000);
	}
}

void loser_loser_you_suck(void)
{
	// print obnoxious win text

	system("clear");

	for(int i = 0; i < 1000; i++){
		printf("_-LOSER_-");
		fflush(stdout);
		usleep(20000);
	}
}

void clear_buffer(char *buffer, int len)
{
	// sets buffer to \0's

	for(int i = 0; i < len; i++){
		buffer[i] = '\0';
	}
}

int int_from_str(char *line, int *number)
{
	// gets next int from string

	char *position = NULL;
	position = line;	
	while(*position){
		if(isdigit(*position)){
			*number = strtol(position, &position, 10);
			return 0;
		}else{
			position++;
		}
	}
	return 1;
}
