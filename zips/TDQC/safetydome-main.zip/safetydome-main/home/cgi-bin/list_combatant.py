#!/usr/bin/env python3
import cgi
from mysql_utils import get_connection
from html_utils import make_ulist, create_link, get_info


def main():
    """Query database to list all combatants
    """

    # header text
    print("Content-type: text/html\n")
    print("<html><head><title>Combatants</title>"
          "<link href='/style_sheets/lists.css'"
          " type='text/css' rel='stylesheet'/>"
          "<a href='/index.html'>Home</a></head>")

    # create query
    query = ("SELECT name Combatants, id FROM combatant "
             "ORDER BY name")

    # query database
    combatants = get_info(query)

    # create page
    print("<body>")
    print("<center><h1>Combatants</h1></center>")
    make_ulist(create_link(combatants, "combatant_details.py"))
    print("</body>")


try:
    main()
except (Exception, KeyboardInterrupt, SystemExit, GeneratorExit):
    print("<body>")
    print("<center><h1>Server Error</h1></center>")
    print("<center><h1>It's not your computer</h1></center>")
    print("<center><h1>Try again later...</h1></center>")
    print("</body>")
