#!/usr/bin/env python3
import cgi

from html_utils import get_connection, get_info


def main():
    """Validates data from query string
       Queries database to inserts data in to species table
       Queries database to list all species
    """

    # header text
    print("Content-type: text/html\n")
    print("<html><head><title>Combatant details</title> "
          "<link href='/style_sheets/tables.css'"
          " type='text/css' rel='stylesheet'/>"
          "<a href='/index.html'>Home</a></head>")

    values = check_values()

    # check if valid values
    if not values:
        return

    insert_data(values)

    # create page
    species = "SELECT * FROM species"
    print("<body>")
    get_info(species, '', True, "Species")
    print("</body>")


def insert_data(data):
    """Queries database to inserts data in to species table
    """

    connection = get_connection()

    sql = ("INSERT INTO species (name, type, base_atk, base_dfn, base_hp)"
           " VALUES (%s, %s, %s, %s, %s)")

    cursor = connection.cursor()
    cursor.execute(sql, data)

    connection.commit()

    cursor.close()
    connection.close()


def input_error(message):
    """Prints error page with message
    """

    print("<body>")
    print("<h1>Input Error</h1>")
    print(f"<h1>{message}</h1>")
    print("</body>")


def check_values():
    """Validates data from query string
    """

    fields = cgi.FieldStorage()

    # get species data from query string
    name = fields.getvalue("name")
    type = fields.getvalue("type")
    attack = fields.getvalue("atk")
    defense = fields.getvalue("def")
    health = fields.getvalue("hp")

    # check for missing values
    values = (name, type, attack, defense, health)
    for value in values:
        if value is None:
            input_error("Missing Required Entry")
            return None

    attack = int(values[2])
    defense = int(values[3])
    health = int(values[4])

    # check for space in name
    if " " in name:
        input_error("No spaces allowed in name")
        return None

    # check if stats add up to 300
    if (attack + defense + health) != 300:
        input_error("Stats must add up to 300")
        return None

    # check if species exists already
    species = "SELECT name FROM species"
    species = get_info(species)
    species = [item[0] for item in species]
    if name in species:
        input_error("Species exists already")
        return None

    return values


try:
    main()
except (Exception, KeyboardInterrupt, SystemExit, GeneratorExit):
    print("<body>")
    print("<center><h1>Server Error</h1></center>")
    print("<center><h1>It's not your computer</h1></center>")
    print("<center><h1>Try again later...</h1></center>")
    print("</body>")
