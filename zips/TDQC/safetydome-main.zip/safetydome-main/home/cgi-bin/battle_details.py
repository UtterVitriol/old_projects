#!/usr/bin/env python3
import cgi

from html_utils import get_info


def main():
    """Queries database to list a specific fight
    """

    # header text
    print("Content-type: text/html\n")
    print("<html><head><title>Battle</title> "
          "<link href='/style_sheets/tables.css'"
          " type='text/css' rel='stylesheet'/>"
          "<a href='/index.html'>Home</a></head>")

    # grab data
    fields = cgi.FieldStorage()
    default = ""
    id = fields.getvalue("item", default)
    id = id.split(',')
    combatant_one = id[0].split(':')[0]
    combatant_two = id[0].split(':')[1]
    start = id[1]

    # create query
    items = (combatant_one, combatant_two, start)
    battle = ("select com1.name as `Combatant 1`, com2.name as `Combatant 2`,"
              "win.name as `Winner`, fight.start as `Start`, fight.finish as "
              "`Finish` from fight inner join combatant com1 on com1.id = "
              "fight.combatant_one inner join combatant com2 on com2.id = "
              "fight.combatant_two inner join combatant win on win.id "
              "= fight.winner_id WHERE com1.id=%s and com2.id=%s and start=%s")

    # create body
    print("<body>")
    print("<center><h1>Battle Details</h1></center>")
    get_info(battle, items, True, "Battle")
    print("</body>")


try:
    main()
except (Exception, KeyboardInterrupt, SystemExit, GeneratorExit):
    print("<body>")
    print("<center><h1>Server Error</h1></center>")
    print("<center><h1>It's not your computer</h1></center>")
    print("<center><h1>Try again later...</h1></center>")
    print("</body>")
