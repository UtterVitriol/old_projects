#!/usr/bin/env python3
import cgi

from html_utils import get_info, make_dropdown


def main():
    """Get information to create new species
    """

    # header text
    print("Content-type: text/html\n")
    print("<html><head><title>Add new species</title> "
          "<link href='/style_sheets/forms.css'"
          " type='text/css' rel='stylesheet'/>"
          "<a href='/index.html'>Home</a></head>")

    # get types to create dropdown
    types = ("SELECT name FROM type")
    types = get_info(types)

    # create page
    print("<body>")
    print("<center><h1>Add New Species</h1></center>")
    print("<form action='/cgi-bin/list_species.py'>")
    print("<p><label>Name: <input type='text' name='name'/></label></p>")
    print("<p><label>Type:")
    make_dropdown(types, "type")
    print("</label></p>")
    print("<p><label>Base ATK: <input type='number' name='atk'/></label></p>")
    print("<p><label>Base DEF: <input type='number' name='def'/></label></p>")
    print("<p><label>Base HP: <input type='number' name='hp'/></label></p>")
    print("<p><input type='submit' value='Submit'/>")
    print("</form>")
    print("<h2>Base ATK, DEF and HP values must add up to 300</h2>")
    print("</body>")


try:
    main()
except (Exception, KeyboardInterrupt, SystemExit, GeneratorExit):
    print("<body>")
    print("<center><h1>Server Error</h1></center>")
    print("<center><h1>It's not your computer</h1></center>")
    print("<center><h1>Try again later...</h1></center>")
    print("</body>")
