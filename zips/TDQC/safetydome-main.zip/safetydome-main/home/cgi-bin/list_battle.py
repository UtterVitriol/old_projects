#!/usr/bin/env python3
import cgi

from html_utils import get_info, make_ulist, create_link


def main():
    """Queries database to list all battles
    """

    # header text
    print("Content-type: text/html\n")
    print("<html><head><title>Battles</title>"
          "<link href='/style_sheets/lists.css'"
          " type='text/css' rel='stylesheet'/>"
          "<a href='/index.html'>Home</a></head>")

    # create query
    battles = ("select com1.name, com2.name, com1.id, com2.id, start"
               " from combatant com1, combatant com2, fight"
               " where fight.combatant_one = com1.id"
               " and fight.combatant_two = com2.id;")

    # query database
    temp = get_info(battles)

    # create page
    print("<body>")
    print("<center><h1>Battles</h1></center>")
    battles = [[f"{item[0]} vs {item[1]}",
                f"{item[2]}:{item[3]},{item[4]}"] for item in temp]
    make_ulist(create_link(battles, "battle_details.py"))
    print("</body>")


try:
    main()
except (Exception, KeyboardInterrupt, SystemExit, GeneratorExit):
    print("<body>")
    print("<center><h1>Server Error</h1></center>")
    print("<center><h1>It's not your computer</h1></center>")
    print("<center><h1>Try again later...</h1></center>")
    print("</body>")
