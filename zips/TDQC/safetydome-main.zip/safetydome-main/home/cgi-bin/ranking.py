#!/usr/bin/env python3
import cgi

from html_utils import make_list, get_info, create_link


def main():
    """Query database to list combatant rankings
    """

    # header text
    print("Content-type: text/html\n")
    print("<html><head><title>Combatant details</title> "
          "<link href='/style_sheets/lists.css'"
          " type='text/css' rel='stylesheet'/>"
          "<a href='/index.html'>Home</a></head>")

    # create query
    winners = ("SELECT id, name 'Name',"
               " COUNT(winner_id) AS 'Wins'"
               " FROM combatant c LEFT OUTER JOIN fight f ON"
               " c.id = f.winner_id group by id"
               " order by count(winner_id) DESC")

    # query database
    winners = get_info(winners)
    winners = [[item[1], item[0]] for item in winners]

    # create page
    print("<body>")
    print("<center><h1>Combatant Rankings</h1></center>")
    make_list(create_link(winners, "combatant_details.py"))
    print("</body>")


try:
    main()
except (Exception, KeyboardInterrupt, SystemExit, GeneratorExit):
    print("<body>")
    print("<center><h1>Server Error</h1></center>")
    print("<center><h1>It's not your computer</h1></center>")
    print("<center><h1>Try again later...</h1></center>")
    print("</body>")
