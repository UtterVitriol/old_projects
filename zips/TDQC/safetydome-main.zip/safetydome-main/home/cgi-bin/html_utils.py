#!/usr/bin/env python3
"""html utility functions"""

from mysql_utils import get_connection


def make_dropdown(list, name):
    """Create dropdwon list"""

    print(f"<select name='{name}'>")
    for item in list:
        print(f"<option value={item[0]}>{item[0]}</option>")

    print("</select>")


def make_header(title):
    """Makes h1 header"""

    print(f"<h1>{title}</h1>")


def make_ulist(list):
    """Creates unordered list"""

    print("\t<ul>")
    for item in list:
        print(f"\t\t<li>{item}</li>")
    print("\t</ul>")


def make_list(list):
    """Creates ordered list"""

    print("\t<ol>")
    for item in list:
        print(f"\t\t<li>{item}</li>")
    print("\t</ol>")


def create_row(data):
    """Creates a row in table"""

    row = []
    for item in data:
        row.append(f"<td>{item}</td>")
    return "".join(row)


def create_table(title, cursor):
    """Creates a table"""

    html = []
    html.append("<table>")
    html.append(f"<caption>{title}</caption>")
    html.append("<thead>")
    html.append("<tr>")
    table_heads = []
    for name in cursor.column_names:
        table_heads.append(f"<th>{name}</th>")
    html.extend(table_heads)
    html.append("</tr>")
    html.append("</thead>")
    html.append("<tbody>")
    for row in cursor.fetchall():
        html.append("<tr>")
        html.append(create_row(row))
        html.append("</tr>")
    html.append("</tbody>")
    html.append("</table>")

    html = "".join(html)
    print(html)


def create_link(list, file):
    """Creates a link"""

    for idx, item in enumerate(list):
        list[idx] = f"<a href='/cgi-bin/{file}?item={item[1]}'>{item[0]}</a>"
    return list


def get_info(query, items=(''), table=False, title=""):
    """Queries database"""

    # connect to database
    connection = get_connection()
    sql = (query)

    # query database
    cursor = connection.cursor()
    cursor.execute(sql, items)

    if table:
        # create table with queried data
        create_table(title, cursor)
        cursor.close()
        connection.close()
    else:
        # return queried data
        data = cursor.fetchall()
        cursor.close()
        connection.close()
        return data
