#!/usr/bin/env python3
import cgi

from html_utils import get_info


def main():
    """Queries database and lists data about specific combatant
    """

    # header text
    print("Content-type: text/html\n")
    print("<html><head><title>Combatant details</title> "
          "<link href='/style_sheets/tables.css'"
          " type='text/css' rel='stylesheet'/>"
          "<a href='/index.html'>Home</a></head>")

    # get data
    fields = cgi.FieldStorage()
    default = ""
    id = fields.getvalue("item", default)

    # query to get species id and name from combatant id
    species = ("SELECT species_id, name FROM combatant "
               f"WHERE id = {id}")
    species = get_info(species)
    species = species[0]

    # query to get basic info about combatant
    items_one = (id, species[0])
    basic_info = ("select combatant.name as 'Name',"
                  " plus_atk as 'Plus Attack',"
                  " plus_dfn as 'Plus Defense',"
                  " plus_hp as 'Plus HP',"
                  " species.name as 'Species',"
                  " type Type, base_atk as 'Base Attack',"
                  " base_dfn as 'Base Defense',"
                  " base_hp as 'Base HP' from combatant,"
                  " species where combatant.id = %s and species.id = %s")

    # query to get combatant's attacks
    items_two = (species[0],)
    attack_info = ("select name as 'Name', type as 'Type',"
                   " min as 'Min Damage', max as 'Max Damage',"
                   " speed as 'Speed' from attack"
                   " inner join(select attack_id from species_attack"
                   " where species_id=%s) as s"
                   " where attack.id = s.attack_id")

    # make page
    print("<body>")
    get_info(basic_info, items_one, True, species[1])
    get_info(attack_info, items_two, True, "Attacks")
    print("</body>")


try:
    main()
except (Exception, KeyboardInterrupt, SystemExit, GeneratorExit):
    print("<center><h1>Server Error</h1></center>")
    print("<center><h1>It's not your computer</h1></center>")
    print("<center><h1>Try again later...</h1></center>")
