"""dashboard.py - contains the Dashboard class."""
from tkinter import Frame, LEFT, RIGHT, Toplevel, Text, BOTH
import tkinter
import tkinter


class Dashboard(tkinter.Toplevel):
    """Dashbaord Class."""

    def __init__(self, parent):
        """
        Intialize a Dashboard.

        Args:
            parent: parent of the toplevel tkinter window.
        """
        super().__init__(parent)
        self.geometry("995x200+410+0")
        self.title("Overlord's Dashboard")

        self.frame1 = Frame(self)
        self.frame2 = Frame(self)
        self.frame3 = Frame(self)

        tkinter.Label(self.frame1, text="Overlord", bg="grey", fg="black",
                      highlightbackground="grey").pack()
        tkinter.Label(self.frame2, text="Drones", bg="grey", fg="black",
                      highlightbackground="grey").pack()
        tkinter.Label(self.frame3, text="Legend", bg="grey", fg="black",
                      highlightbackground="grey").pack()

        self.overlord_log = tkinter.Text(self.frame1, height=10,  width=25)
        self.overlord_log.pack()

        self.drone_log = tkinter.Text(self.frame2, height=10, width=70)
        self.drone_log.pack()

        self.legend = tkinter.Text(
            self.frame3, height=10, width=30, bg="black", fg="grey")
        self.legend.tag_config("wall", background="black", foreground="red")
        self.legend.tag_config("acid", background="green", foreground="black")
        self.legend.tag_config(
            "mineral", background="black", foreground="gold")
        self.legend.tag_config("zerg", background="black",
                               foreground="#ff57f4")
        self.legend.pack()

        self.frame1.pack(side=LEFT)
        self.frame2.pack(side=LEFT)
        self.frame3.pack(side=RIGHT)

        legend = "f = Fog\t\t# = Wall\n\n* = Mineral\t\t~ " \
                 "= Acid\n\n_ = Landing\t\tZ = Drone\n"

        self.legend.insert(tkinter.END, legend)
        self.legend.insert(tkinter.END, "\n")

        tags = {"#": "wall", "~": "acid",
                "*": "mineral", "Z": "zerg",
                "_": "landing"}

        for char in "#~_*Z":
            self.legend.mark_set("matchStart", "1.0")
            self.legend.mark_set("matchEnd", "1.0")
            self.legend.mark_set("searchLimit", tkinter.END)
            count = tkinter.IntVar()
            pos = self.legend.search(char, "matchEnd", "searchLimit",
                                     count=count)
            self.legend.mark_set("matchStart", pos)
            self.legend.mark_set("matchEnd", "%s+%sc" % (pos, count.get()))
            self.legend.tag_add(tags[char], "matchStart", "matchEnd")

        self.legend.tag_add

        self.map1 = Toplevel(self)
        self.map1.geometry("615x615+0+300")
        self.map1.title("Map1")
        self.text1 = Text(self.map1, height=10,
                          width=50, bg="black", fg="grey",
                          font=("Monospace", 8))
        self.text1.pack(fill=BOTH, expand=True)

        self.text1.tag_config("wall", background="black", foreground="red")
        self.text1.tag_config("acid", background="green", foreground="black")
        self.text1.tag_config("mineral", background="black", foreground="gold")
        self.text1.tag_config("zerg", background="black", foreground="#ff57f4")
        self.text1.tag_config(
            "landing", background="black", foreground="white")

        self.map2 = Toplevel(self)
        self.map2.geometry("615x615+620+300")
        self.map2.title("Map2")
        self.text2 = Text(self.map2, height=10,
                          width=50, bg="black", fg="grey",
                          font=("Monospace", 8))
        self.text2.pack(fill=BOTH, expand=True)

        self.text2.tag_config("wall", background="black", foreground="red")
        self.text2.tag_config("acid", background="green", foreground="black")
        self.text2.tag_config("mineral", background="black", foreground="gold")
        self.text2.tag_config("zerg", background="black", foreground="#ff57f4")
        self.text2.tag_config(
            "landing", background="black", foreground="white")

        self.map3 = Toplevel(self)
        self.map3.geometry("615x615+1240+300")
        self.map3.title("Map3")
        self.text3 = Text(self.map3, height=10,
                          width=50, bg="black", fg="grey",
                          font=("Monospace", 8))
        self.text3.pack(fill=BOTH, expand=True)

        self.text3.tag_config("wall", background="black", foreground="red")
        self.text3.tag_config("acid", background="green", foreground="black")
        self.text3.tag_config("mineral", background="black", foreground="gold")
        self.text3.tag_config("zerg", background="black", foreground="#ff57f4")
        self.text3.tag_config(
            "landing", background="black", foreground="white")
