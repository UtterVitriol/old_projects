"""
graph.py - Graph Class.

A dictionary adjacency list implementation.
"""


class Graph:
    """Graph Class."""

    def __init__(self, vertices):
        """
        Initialize a Graph object.

        Args:
            vertices: the number of vertices for the graph object.
        """
        self.vertices = vertices
        self.graph = {}
        self.path = []
        self.mineral_locations = []
        self.dz = None
        self.explorer = False
        self.sprinter = False
        self.transporter = False
        self.dz_occupied = False
        self.too_big = False
        self.blanks = 0

    def add_edge(self, src, dest):
        """
        Add an edge to the graph.

        Args:
            src: source node.
            dest: destination node.

        Returns: None.
        """
        # add the node to the source node
        if src not in self.graph:
            self.graph[src] = {dest: 0}
        else:
            if dest not in self.graph[src]:
                self.graph[src][dest] = 0

        # add the source node to the destination
        if dest not in self.graph:
            self.graph[dest] = {src: 0}
        else:
            if src not in self.graph[dest]:
                self.graph[dest][src] = 0

    def dijkstra(self, src, dest, visited=None, distances=None,
                 predecessors=None):
        """Calculate the shortest path between to points."""
        if predecessors is None:
            predecessors = {}
        if distances is None:
            distances = {}
        if visited is None:
            visited = []
        # target shortest path
        if src == dest:
            path = []
            pred = dest
            while pred:
                path.append(pred)
                pred = predecessors.get(pred, None)

            self.path = path
        else:
            # if not visited, set cost to 0
            if not visited:
                distances[src] = 0
            # visit the neighbors
            try:
                for neighbor in self.graph[src]:
                    if neighbor not in visited:
                        new_distance = distances[src] + \
                            self.graph[src][neighbor]
                        if (new_distance
                                < distances.get(neighbor, float('inf'))):
                            distances[neighbor] = new_distance
                            predecessors[neighbor] = src
            except KeyError:
                # silently pass if the requested neighbor is in in the graph
                pass

            visited.append(src)
            unvisited = {}
            for k in self.graph:
                if k not in visited:
                    unvisited[k] = distances.get(k, float('inf'))
            x = min(unvisited, key=unvisited.get)
            self.dijkstra(x, dest, visited, distances, predecessors)
