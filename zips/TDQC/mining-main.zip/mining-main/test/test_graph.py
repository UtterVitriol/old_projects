"""test_graph.py - Test the Graph Class."""
import unittest
from mining.data_structure.graph import Graph


class TestGraph(unittest.TestCase):
    """TestGraph Class."""

    def test_graph_init(self):
        """Test Graph Initialization."""
        graph_ = Graph(100)
        self.assertIsInstance(graph_, Graph)

    def test_graph_properties(self):
        """Test Graph Properties."""
        graph_ = Graph(100)
        self.assertEqual(graph_.vertices, 100)
        self.assertEqual(graph_.too_big, False)

    def test_add_edge(self):
        """Test Graph add_edge."""
        graph_ = Graph(100)
        graph_.add_edge((0, 1), (0, 2))
        self.assertTrue((0, 1) in graph_.graph)

    def test_dijkstra(self):
        """Test Graph dijkstra."""
        graph_ = Graph(100)
        graph_.add_edge((0, 1), (0, 2))
        graph_.add_edge((0, 2), (0, 3))
        graph_.dijkstra((0, 1), (0, 3))
        self.assertEqual(graph_.path, [(0, 3), (0, 2), (0, 1)])
