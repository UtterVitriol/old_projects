"""test_overlord.py - Test the Overlord Class."""
import unittest
from mining.zergs.overlord import Overlord
from mining.gui.dashboard import Dashboard


class TestOverlord(unittest.TestCase):
    """TestOverlord Class."""

    def test_overlord_init(self):
        """Test Overlord Initialization."""
        overlord_ = Overlord(10, 50, Dashboard(None))
        overlord_.add_map(0, 1.7)
        overlord_.add_map(1, 1.7)
        overlord_.add_map(2, 1.7)
        self.assertIsInstance(overlord_, Overlord)

    def test_overlord_get_property(self):
        """Test Overlord Properties."""
        overlord_ = Overlord(10, 100, Dashboard(None))
        overlord_.add_map(0, 1.7)
        overlord_.add_map(1, 1.7)
        overlord_.add_map(2, 1.7)
        self.assertEqual(overlord_.total_ticks, 10)
        # assert equals 1.0 because the overlord decrements refined_minerals
        # when calculating init drone costs
        self.assertEqual(overlord_.refined_minerals, 1.0)

    def test_overlord_add_map(self):
        """Test Overlord add_map method."""
        overlord_ = Overlord(10, 50, Dashboard(None))
        overlord_.add_map(0, 1.7)
        overlord_.add_map(1, 1.7)
        overlord_.add_map(2, 1.7)
        self.assertEqual(overlord_.maps[0], 1.7)

    def test_over_lord_action(self):
        """Test Overlord action method."""
        overlord_ = Overlord(10, 50, Dashboard(None))
        overlord_.add_map(0, 1.7)
        overlord_.add_map(1, 1.7)
        overlord_.add_map(2, 1.7)
        self.assertNotEqual(overlord_.action(None), None)
