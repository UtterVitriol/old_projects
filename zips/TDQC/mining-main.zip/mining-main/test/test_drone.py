"""test_drone.py - Test the Drone Class."""
import unittest
from mining.zergs.drone import Drone, Sprinter, Transporter
from mining.zergs.overlord import Overlord
from mining.gui.dashboard import Dashboard


class TestDrone(unittest.TestCase):
    """TestDrone Class."""

    def test_drone_init(self):
        """Test Drone Initialization."""
        drone_ = Drone(Overlord(100, 100, Dashboard(None)))
        self.assertIsInstance(drone_, Drone)

    def test_drone_property(self):
        """Test Drone Properties."""
        drone_ = Drone(Overlord(100, 100, Dashboard(None)))
        self.assertEqual(drone_.health, 40)
        self.assertEqual(drone_.capacity, 10)
        self.assertEqual(drone_.moves, 1)

    def test_sprinter_init(self):
        """Test Sprinter Initialization."""
        sprinter_ = Sprinter(Overlord(100, 100, Dashboard(None)))
        self.assertIsInstance(sprinter_, Sprinter)

    def test_sprinter_property(self):
        """Test Drone Properties."""
        sprinter_ = Sprinter(Overlord(100, 100, Dashboard(None)))
        self.assertEqual(sprinter_.health, 70)
        self.assertEqual(sprinter_.capacity, 10)
        self.assertEqual(sprinter_.moves, 2)

    def test_drone_cost(self):
        """Test Drone get_init_cost."""
        self.assertEqual(Drone.get_init_cost(), 9.0)

    def test_sprinter_cost(self):
        """Test Sprinter get_init_cost."""
        self.assertEqual(Sprinter.get_init_cost(), 15.0)

    def test_drone_steps(self):
        """Test Drone steps."""
        drone_ = Drone(Overlord(100, 100, Dashboard(None)))
        self.assertEqual(drone_.steps(), 0)

    def test_transporter_init(self):
        """Test Transporter initialization."""
        trans_ = Transporter(Overlord(100, 100, Dashboard(None)))
        self.assertIsInstance(trans_, Transporter)

    def test_transporter_property(self):
        """Test Transporter properties."""
        trans_ = Transporter(Overlord(100, 100, Dashboard(None)))
        self.assertEqual(trans_.health, 50)
        self.assertEqual(trans_.capacity, 100)
        self.assertEqual(trans_.moves, 1)

    def test_transporter_cost(self):
        """Test Transporter get_init_cost."""
        self.assertEqual(Transporter.get_init_cost(), 28.0)

    def test_transporter_steps(self):
        """Test Transporter steps."""
        trans_ = Transporter(Overlord(100, 100, Dashboard(None)))
        self.assertEqual(trans_.steps(), 0)
