"""test_zerg.py - Test the Zerg Abstract Class."""
import unittest
from mining.zergs.zerg import Zerg


class TestZerg(unittest.TestCase):
    """TestZerg Class."""

    def test_zerg_cannot_instantiate(self):
        """Test to ensure Zerg objects cannot instantiate."""
        self.assertRaises(TypeError, Zerg)
