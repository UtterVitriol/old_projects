"""done.py - contains the Drone, Sprinter, and Transporter classes."""

import random
import logging
import os
from datetime import datetime
from .zerg import Zerg


class Drone(Zerg):
    """Drone Class."""

    health = 40
    capacity = 10
    moves = 1

    def __init__(self, overlord, health=40, capacity=10, moves=1):
        """
        Initialize a Drone.

        Args:
            overlord: overlord object.
            health: number of health points.
            capacity: amount of minerals a drone can hold.
            moves: number of moves per tick.
        """
        logging.basicConfig(filename=os.path.join(Zerg.file_path),
                            level=logging.DEBUG)

        self.overlord = overlord
        self.max_health = health
        self.health = health
        self.capacity = capacity
        self.moves = moves
        self.load = 0
        self.status = "WAITING"
        self.steps_ = 0
        self.steps_since_minerals = 0
        self.return_flag = False
        self.pos = None
        self.choice = None
        self.first = True
        self.map_check = True

        self.count = 0
        self.visited = []
        self.choices = []
        self.previous = None

        self.bad = ["#", "Z", "*"]
        self.current = "_"
        self.next = 0

        self.context = None

        for map_id, _ in enumerate(self.overlord.graphs):
            if self.overlord.graphs[map_id] is not None:
                self.map_id = map_id

    def action(self, context):
        """Perform and action on a given context."""
        context.map_id = self.map_id
        context.zerg_id = id(self)
        context.type = self
        context.current = self.current
        context.status = self.status
        self.context = context
        self.overlord.map_updates.append(context)

        if self.current == "~":
            self.health -= 3

        if self.current == "#":
            self.health -= 1

        if self.health <= 0:
            logging.info(f"{str(datetime.now())} Drone {id(self)} died.")
            self.overlord.graphs[self.map_id].explorer = False
            del self.overlord.zerg[id(self)]

        self.pos = (context.x, context.y)
        if self.status == "WAITING":
            self.last = self.pos
            self.overlord.graphs[self.map_id].dz = self.pos
        elif self.last != self.pos:
            self.steps_ += 1
            self.steps_since_minerals += 1

        if self.pos == self.overlord.graphs[self.map_id].dz:
            if "*" in self.bad:
                self.bad.remove("*")
            self.overlord.graphs[self.map_id].dz_occupied = True
        else:
            if "*" not in self.bad and type(self) is Drone:
                self.bad.append("*")
            self.overlord.graphs[self.map_id].dz_occupied = False

        if (self.steps_since_minerals < 100
                and self.overlord.graphs[self.map_id].mineral_locations and
                self.overlord.graphs[self.map_id].too_big is False):
            self.steps_since_minerals = 0
            self.overlord.graphs[self.map_id].too_big = False

        if (self.steps_since_minerals > 100
                or self.overlord.graphs[self.map_id].too_big is True):
            self.overlord.graphs[self.map_id].too_big = True
            self.overlord.graphs[self.map_id].sprinter = True
            if "*" in self.bad:
                self.bad.remove("*")

        if self.health < ((self.max_health / 2) + 3):
            if "~" not in self.bad:
                self.bad.append("~")
                self.status = "RETURN READY"

        directions = {2: 'NORTH', 1: 'SOUTH',
                      0: 'EAST', 3: 'WEST', "None": "None"}

        contexts = {"NORTH": context.north, "SOUTH": context.south,
                    "EAST": context.east, "WEST": context.west,
                    "None": "None"}

        repeat = {0: (context.x + 1, context.y),
                  1: (context.x, context.y - 1),
                  2: (context.x, context.y + 1),
                  3: (context.x - 1, context.y)}

        self.visited.append(self.pos)

        if self.status == "RETURNING":
            self._return(repeat, contexts, directions, context)
        elif self.status == "PATHING":
            self._pathing(contexts, directions, context)
        elif self.status == "RETURNED":
            # silent pass because a comment is required
            pass
        elif self.status == "MINING":
            self._mining(repeat, contexts, directions, context)
        elif not self._all_visited(repeat, contexts, directions):
            self._explore(repeat, contexts, directions, context)
        else:
            self.status = "BACKTRACKING"
            if "*" in self.bad:
                self.bad.remove("*")
            self._back_track(repeat, contexts, directions, context)

        if self.choice in directions:
            if contexts[directions[self.choice]] != "#":
                if self.status != "MINING":
                    self.current = contexts[directions[self.choice]]

                if (self.status == "EXPLORING" and
                        contexts[directions[self.choice]] not in ("*", "#")):
                    self.choices.append(self.choice)
                if not self.first:
                    self.last = self.pos
                else:
                    self.first = False
                return directions[self.choice]
            else:
                self.status = "RETURN READY"
                return self.status
        else:
            return self.status

    def _find_empty(self, context):
        choices = [0, 1, 2, 3]

        if context.north == " ":
            return 2

        elif context.south == " ":
            return 1

        elif context.east == " ":
            return 0

        elif context.west == " ":
            return 3

        else:
            return random.choice(choices)

    def _back_track(self, repeat, contexts, directions, context):
        opposite = {2: 1, 1: 2, 0: 3, 3: 0, "None": "None"}
        if self.choices:
            try:
                if (contexts[directions[opposite[self.choices[-1]]]] not in
                        ("Z", "#")):
                    self.choice = opposite[self.choices.pop()]
                elif contexts[directions[opposite[self.choices[-1]]]] == "Z":
                    self.choice = self._find_empty(context)
                    self.choices.append(self.choice)
                else:
                    self.choices.pop()
                    self.choice = self.status
            except KeyError:
                # silent pass comment because it is required
                pass
        else:
            self.status = "RETURN READY"
            self.return_flag = True
            self.choice = self.status

    def _all_visited(self, repeat, contexts, directions):
        all_visited_flag = True

        for position in repeat:
            if (repeat[position] not in self.visited and
                    contexts[directions[position]] not in self.bad):
                all_visited_flag = False

        return all_visited_flag

    def _return(self, repeat, contexts, directions, context):
        if self.return_flag is True and self.current == "_":
            self.status = "RETURNED"
            self.choice = self.status
        else:
            self._back_track(repeat, contexts, directions, context)

    def _mining(self, repeat, contexts, directions, context):
        self.status = "MINING"
        if self.load == self.capacity:
            if type(self) is Drone:
                self.status = "RETURNING"
                self.choice = self.status
            elif type(self) is Sprinter:
                self.status = "RETURN READY"
                self.choices.pop()
            elif type(self) is Transporter:
                self.status = "RETURNING"
                self.choice = self.status
            # self.return_flag = True
            # self._back_track(repeat, contexts, directions)
        elif contexts[directions[self.choice]] == "*":
            self.load += 1
            print("Load:", self.load)
        else:
            if type(self) is Drone:
                self._explore(repeat, contexts, directions, context)
            elif type(self) is Sprinter:
                self.status = "RETURN READY"
                self.choices.pop()
            elif type(self) is Transporter:
                self._explore(repeat, contexts, directions, context)

    def _explore(self, repeat, contexts, directions, context):

        self.status = "EXPLORING"
        try:
            while (contexts[directions[self.choice]] in self.bad or
                    repeat[self.choice] in self.visited):
                self.choice += 1

                if self.choice > 3:
                    self.choice = 0
        except KeyError:
            pass

        if (contexts[directions[self.choice]] == "*"):
            self._mining(repeat, contexts, directions, context)

    def _pathing(self, contexts, directions, context):
        conversion = {(context.x+1, context.y): 0,
                      (context.x, context.y-1): 1,
                      (context.x, context.y+1): 2,
                      (context.x-1, context.y): 3}
        if self.choices:
            try:
                if contexts[directions[conversion[self.choices[-1]]]] == "#":
                    self.status = "RETURN READY"
                    self.choice = self.status
                else:
                    self.choice = conversion[self.choices.pop()]

            except KeyError:
                # silent pass comment because it is required
                pass
        else:
            self.status = "RETURNED"
            self.choice = self.status

    def steps(self):
        """Get the number of steps a Drone has taken."""
        return self.steps_

    @classmethod
    def get_init_cost(cls):
        """Get the initial Drone construction cost."""
        return (cls.health / 10) + (cls.capacity / 5) + (cls.moves * 3)


class Sprinter(Drone):
    """Sprinter Class."""

    health = 70
    capacity = 10
    moves = 2

    def __init__(self, overlord, health=70, capacity=10, moves=2):
        """
        Initialize a Sprinter.

        Args:
            overlord: overlord object.
            health: number of health points.
            capacity: amount of minerals a drone can hold.
            moves: number of moves per tick.
        """
        self.prior = []
        self.opposite = {2: 1, 1: 2, 0: 3, 3: 0, "None": "None"}
        super().__init__(overlord, health, capacity, moves)

    def action(self, context):
        """Perform an action on a context."""
        context.map_id = self.map_id
        context.zerg_id = id(self)
        context.type = self
        context.current = self.current
        context.status = self.status
        self.context = context
        self.overlord.map_updates.append(context)

        directions = {2: 'NORTH', 1: 'SOUTH',
                      0: 'EAST', 3: 'WEST', "None": "None"}

        contexts = {"NORTH": context.north, "SOUTH": context.south,
                    "EAST": context.east, "WEST": context.west, "None": "None"}

        repeat = {0: (context.x + 1, context.y), 1: (context.x, context.y - 1),
                  2: (context.x, context.y + 1), 3: (context.x - 1, context.y)}

        if self.current == "~":
            self.health -= 3

        if self.current == "#":
            self.health -= 1
            self.status = "RETURN READY"
            self.choice = self.status

        if self.health <= 0:
            logging.info(f"{str(datetime.now())} Drone {id(self)} died.")
            self.overlord.graphs[self.map_id].sprinter = False
            del self.overlord.zerg[id(self)]

        self.pos = (context.x, context.y)

        if self.first:
            self.last = self.pos
        elif self.last != self.pos:
            self.steps_ += 1

        if self.health < ((self.max_health / 2) + 3):
            if "~" not in self.bad:
                self.bad.append("~")
                if self.status != "PATHING":
                    self.status = "RETURN READY"

        if self.status == "SEEKING":
            self._seeking(contexts, directions, context)
        elif self.status == "PATHING":
            super()._pathing(contexts, directions, context)
        elif self.status == "RETURNED":
            # TODO pass comment
            pass
        elif self.status == "RETURN READY":
            self.choice = self.status

        if self.choice in directions:
            if contexts[directions[self.choice]] != "#":
                if contexts[directions[self.choice]] != "*":
                    self.current = contexts[directions[self.choice]]
                if not self.first:
                    self.last = self.pos
                else:
                    self.first = False

                return directions[self.choice]
            else:
                self.status = "RETURN READY"
                return self.status
        else:
            return self.status

    def _seeking(self, contexts, directions, context):
        conversion = {(context.x + 1, context.y): 0,
                      (context.x, context.y - 1): 1,
                      (context.x, context.y + 1): 2,
                      (context.x - 1, context.y): 3}
        if len(self.choices) > 1:
            try:
                if contexts[directions[conversion[self.choices[-1]]]] == "Z":
                    self.choice = self.opposite[self.prior.pop()]
                    for key, value in conversion:
                        if self.choice == value:
                            self.choices.append(key)
                elif contexts[directions[conversion[self.choices[-1]]]] == "#":
                    self.status = "RETURN READY"
                    self.choice = self.status
                else:
                    self.choice = conversion[self.choices.pop()]
                    self.prior.append(self.choice)
            except KeyError:
                # silent pass comment because it is required
                pass

        elif len(self.choices) == 0:
            self.choice = self.status

        else:
            self.choice = conversion[self.choices[-1]]
            if contexts[directions[self.choice]] == "*":
                self.load += 1
            if contexts[directions[self.choice]] == " ":
                self.status = "RETURN READY"
                self.choice = contexts[directions[self.choice]]


class Transporter(Drone):
    """Transporter Class."""

    health = 50
    capacity = 100
    moves = 1

    def __init__(self, overlord, health=50, capacity=100, moves=1):
        """
        Initialize a Transporter.

        Args:
            overlord: overlord object.
            health: number of health points.
            capacity: amount of minerals a drone can hold.
            moves: number of moves per tick.
        """
        self.prior = []
        self.opposite = {2: 1, 1: 2, 0: 3, 3: 0, "None": "None"}
        super().__init__(overlord, health, capacity, moves)
        self.bad = ["#", "Z"]
