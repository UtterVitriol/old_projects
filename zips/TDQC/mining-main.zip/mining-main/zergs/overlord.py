"""overlord.py - Contains the Overlord Class for zerg command and control."""

import random
import tkinter
from queue import Queue
import logging
import os
from datetime import datetime
from .zerg import Zerg
from .drone import Drone, Sprinter, Transporter
from mining.data_structure.graph import Graph


class Overlord(Zerg):
    """Overlord Class - creates, manages, updates, controls drones."""

    def __init__(self, total_ticks, refined_minerals, dashboard=None):
        """
        Initialize an overlord object.

        Args:
            total_ticks: number of total "turns" per program execution.
            refined_minerals: number of minerals alloted for drone creation.
            dashboard: a tkinter gui object.
        """
        logging.basicConfig(filename=os.path.join(Zerg.file_path),
                            level=logging.DEBUG)
        self.dashboard = dashboard
        self.total_ticks = total_ticks
        self.refined_minerals = refined_minerals
        self.mined_minerals = 0
        self._create_maps()
        self.map_updates = []
        self.maps = {}
        self.zerg = {}
        self.drone_queue = Queue()
        self.queue_list = []
        self.sprinter_queue = Queue()
        self.sprinter_list = []
        self.transporter_queue = Queue()
        self.transporter_list = []
        self.pickup_queue = Queue()
        self.graphs = [Graph(10000), Graph(10000), Graph(10000)]
        self.map_num = 0
        self.current_tick = 0

        while self.refined_minerals:
            if self.refined_minerals - Drone.get_init_cost() < 0:
                break
            self.refined_minerals -= Drone.get_init_cost()
            z = Drone(self)
            logging.info(f"{str(datetime.now())} Drone {id(z)} initialized.")
            self.zerg[id(z)] = z
            self.drone_queue.put(id(z))
            self.queue_list.append(id(z))
            if self.refined_minerals - Sprinter.get_init_cost() < 0:
                continue
            s = Sprinter(self)
            self.zerg[id(s)] = s
            self.sprinter_queue.put(id(s))
            self.sprinter_list.append(id(s))
            if self.refined_minerals - Transporter.get_init_cost() < 0:
                continue
            t = Transporter(self)
            self.zerg[id(t)] = t
            self.transporter_queue.put(id(t))
            self.transporter_list.append(id(t))

    def add_map(self, map_id, summary):
        """
        Add a map to the overlord.

        Args:
            map_id: a number identifying the map.
            summary: a float detailing the map density.

        Returns: None
        """
        maps = [self.dashboard.map1, self.dashboard.map2, self.dashboard.map3]

        self.maps[map_id] = summary

        title = f"Map{str(map_id)}"

        title_id = f"{title} = Map ID: {str(map_id)}"

        maps[self.map_num].title(title)
        self.dashboard.legend.insert(tkinter.END, title_id)
        self.dashboard.legend.insert(tkinter.END, "\n")

        self.map_num += 1

    def action(self, context=None):
        """
        Perform an action given a context.

        Args:
            context: information detailing a zerg's location and surroundings.

        Returns: a string indicating the overlord action to take.
        """
        self.current_tick += 1

        if self.current_tick == 1:
            for map_id in self.maps:
                if not self.maps[map_id]:
                    self.graphs[map_id] = None

        action_choice = 0
        map_id = None

        returned = "RETURNED"
        return_ready = "RETURN READY"
        waiting = "WAITING"

        for zerg_id in self.zerg:
            if self.zerg[zerg_id].map_check:
                for index, graph in enumerate(self.graphs):
                    if not graph:
                        continue
                    else:
                        self.zerg[zerg_id].map_id = index
                        self.zerg[zerg_id].map_check = False
            # temporary variables for zerg position, map dz, and zerg status
            temp_pos = self.zerg[zerg_id].pos
            temp_dz = self.graphs[self.zerg[zerg_id].map_id].dz
            temp_status = self.zerg[zerg_id].status

            if temp_status == returned and temp_pos == temp_dz:
                self.pickup_queue.put(zerg_id)
            elif temp_status == returned and temp_pos != temp_dz:
                self.zerg[zerg_id].status = return_ready
            if type(self.zerg[zerg_id]) is Drone:
                if zerg_id not in self.queue_list and temp_status == waiting:
                    self.drone_queue.put(zerg_id)
                    self.queue_list.append(zerg_id)
            elif type(self.zerg[zerg_id]) is Sprinter:
                if zerg_id not in self.sprinter_list \
                        and temp_status == waiting:
                    self.sprinter_queue.put(zerg_id)
                    self.sprinter_list.append(zerg_id)
            elif type(self.zerg[zerg_id]) is Transporter:
                if zerg_id not in self.sprinter_list \
                        and temp_status == "WAITING":
                    self.transporter_queue.put(zerg_id)
                    self.transporter_list.append(zerg_id)
            if temp_status == "RETURN READY":
                map_id_ = self.zerg[zerg_id].map_id
                graph_ = self.graphs[map_id_]
                graph_.dijkstra(temp_pos, temp_dz)
                graph_.path.pop()
                self.zerg[zerg_id].choices = graph_.path
                self.zerg[zerg_id].status = "PATHING"
                action_choice = 0
        if not self.pickup_queue.empty():
            drone_id = self.pickup_queue.get()
            action_choice = 1
        elif not self.drone_queue.empty():
            drone_id = self.drone_queue.get()
            self.zerg[drone_id].visited = []
            self.zerg[drone_id].choices = []
            self.zerg[drone_id].return_flag = False
            self.zerg[drone_id].choice = random.randint(0, 3)
            if self.queue_list:
                self.queue_list.remove(drone_id)
            if temp_status == waiting:
                action_choice = 2

        if action_choice == 2:
            for index, graph in enumerate(self.graphs):
                if not graph or graph.blanks > 2:
                    continue
                if graph.explorer is False and graph.transporter is False:
                    map_id = index
                    break
        elif action_choice == 1:
            map_id = self.zerg[drone_id].map_id
        else:
            action_choice = 0

        for index, graph in enumerate(self.graphs):
            if not graph:
                continue
            if not self.sprinter_queue.empty()\
                    and graph.mineral_locations \
                    and graph.sprinter is False \
                    and not graph.dz_occupied:
                drone_id = self.sprinter_queue.get()
                map_id = index
                if self.sprinter_list:
                    self.sprinter_list.remove(drone_id)
                if self.zerg[drone_id].status == waiting:
                    dz = graph.dz
                    target = graph.mineral_locations.pop(0)
                    graph.dijkstra(dz, target)
                    action_choice = 2
                    graph.path.pop()
                    self.zerg[drone_id].choices = graph.path
                    self.zerg[drone_id].status = "SEEKING"
                break
            elif (not self.transporter_queue.empty() and graph.too_big is True
                  and graph.transporter is False and not graph.dz_occupied):
                drone_id = self.transporter_queue.get()
                map_id = index
                if self.transporter_list:
                    self.transporter_list.remove(drone_id)
                if self.zerg[drone_id].status == "WAITING":
                    action_choice = 2
                    self.zerg[drone_id].choice = random.randint(0, 3)
                break

        if map_id is None:
            action_choice = 0

        if action_choice == 0:
            self.result = "NONE"
        elif action_choice == 1:
            self.result = 'RETURN {}'.format(drone_id)

            self.map_updates.append(self.zerg[drone_id].context)

            if (self.zerg[drone_id].load == 0 and not
                    self.graphs[map_id].mineral_locations):
                self.graphs[map_id].blanks += 1
            else:
                self.graphs[map_id].blanks = 0
            if type(self.zerg[drone_id]) is Drone:
                self.graphs[map_id].explorer = False
            elif type(self.zerg[drone_id]) is Sprinter:
                self.graphs[map_id].sprinter = False
            elif type(self.zerg[drone_id]) is Transporter:
                self.graphs[map_id].transporter = False
            self.mined_minerals += self.zerg[drone_id].load
            self.zerg[drone_id].load = 0
            self.zerg[drone_id].status = waiting
        elif action_choice == 2:
            if (self.graphs[map_id].sprinter is False
                    or self.graphs[map_id].explorer is False or
                    self.graphs[map_id].transporter is False):
                self.result = 'DEPLOY {} {}'.format(drone_id, map_id)
                self.zerg[drone_id].map_id = map_id
                if type(self.zerg[drone_id]) is Drone:
                    self.graphs[map_id].explorer = True
                elif type(self.zerg[drone_id]) is Sprinter:
                    self.graphs[map_id].sprinter = True
                    if self.graphs[map_id].mineral_locations:
                        self.graphs[map_id].blanks = 0
                elif type(self.zerg[drone_id]) is Transporter:
                    self.graphs[map_id].transporter = True
                    if self.graphs[map_id].mineral_locations:
                        self.graphs[map_id].blanks = 0

        self._update_dashboard()
        self._update_maps()
        self.map_updates = []
        return self.result

    def _update_dashboard(self):
        """Update the overlord's dashboard."""
        self.dashboard.overlord_log.config(state=tkinter.NORMAL)
        self.dashboard.overlord_log.insert(tkinter.END, self.result)
        self.dashboard.overlord_log.insert(tkinter.END, "\n")
        self.dashboard.overlord_log.see(tkinter.END)
        self.dashboard.overlord_log.config(state=tkinter.DISABLED)

        status = "MAP: {} ID: {} HEALTH: {}/{} LOAD: {} STATUS: {}"
        self.dashboard.drone_log.delete("1.0", tkinter.END)
        for _, zerg in self.zerg.items():
            if zerg.status != "WAITING":
                self.dashboard.drone_log.insert(tkinter.END, status.format(
                    zerg.map_id, id(zerg), zerg.health, zerg.max_health,
                    zerg.load, zerg.status))
                self.dashboard.drone_log.insert(tkinter.END, "\n")

    def _update_maps(self):
        """Update the GUI map representation."""
        map_texts = [self.dashboard.text1,
                     self.dashboard.text2,
                     self.dashboard.text3]

        maps = [self.map1, self.map2, self.map3]

        for update in self.map_updates:
            index = update.map_id
            curr_map = maps[index]

            if (update.current == "_" and
                    update.status == "RETURN READY" or
                    update.status == "RETURNED"):
                curr_map[update.y][update.x] = update.current
            else:
                curr_map[update.y][update.x] = "Z"

            curr_map[update.y + 1][update.x] = update.north
            curr_map[update.y - 1][update.x] = update.south
            curr_map[update.y][update.x - 1] = update.west
            curr_map[update.y][update.x + 1] = update.east

            text = map_texts[index]
            text.delete("1.0", tkinter.END)

            for line in curr_map:
                text.insert(tkinter.END, "".join(line))
                text.insert(tkinter.END, "\n")

            tags = {"#": "wall", "~": "acid",
                    "*": "mineral", "Z": "zerg",
                    "_": "landing"}

            # courtesy of https://tinyurl.com/48c6veun
            for char in "#~_*Z":
                text.mark_set("matchStart", "1.0")
                text.mark_set("matchEnd", "1.0")
                text.mark_set("searchLimit", tkinter.END)
                count = tkinter.IntVar()
                while True:
                    pos = text.search(char, "matchEnd", "searchLimit",
                                      count=count)
                    if pos == "":
                        break
                    if count.get() == 0:
                        break

                    text.mark_set("matchStart", pos)
                    text.mark_set("matchEnd", "%s+%sc" % (pos, count.get()))
                    text.tag_add(tags[char], "matchStart", "matchEnd")

            if type(update.type) is Sprinter:
                continue

            curr_coord = (update.x, update.y)
            north_coord = (update.x, update.y + 1)
            south_coord = (update.x, update.y - 1)
            west_coord = (update.x - 1, update.y)
            east_coord = (update.x + 1, update.y)

            directions = {north_coord: update.north, south_coord: update.south,
                          west_coord: update.west, east_coord: update.east}

            temp_minerals = self.graphs[index].mineral_locations

            for coord, direction in directions.items():
                # add nodes to adjacency list
                if direction != "#":
                    self.graphs[index].add_edge(curr_coord, coord)
                # add locations of minerals
                if direction == "*" and coord not in temp_minerals:
                    temp_minerals.append(coord)
                # check for mined minerals
                if direction == " " and coord in temp_minerals:
                    temp_minerals.remove(coord)

    def _create_maps(self):
        """Create map grids and populate initial map windows."""
        self.map1 = self._create_map_grid()
        self._init_gui_map(self.dashboard.text1)

        self.map2 = self._create_map_grid()
        self._init_gui_map(self.dashboard.text2)

        self.map3 = self._create_map_grid()
        self._init_gui_map(self.dashboard.text3)

    def _create_map_grid(self):
        """Create 100x100 maps for displaying map updates."""
        return [["f" for i in range(100)] for j in range(100)]

    def _init_gui_map(self, text):
        """Populate initial map windows."""
        for line in self.map1:
            text.insert(tkinter.END, "".join(line))
            text.insert(tkinter.END, "\n")
