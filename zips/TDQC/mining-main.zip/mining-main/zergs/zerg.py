"""zerg.py - Main abstract Zerg Class."""

from abc import ABC, abstractmethod


class Zerg(ABC):
    """Main abstract Zerg."""

    file_path = ""

    @abstractmethod
    def action(self, context):
        """Perform an action on a context."""
        pass
