var searchData=
[
  ['poly_2eh_0',['poly.h',['../poly_8h.html',1,'']]],
  ['poly_5fadd_1',['Poly_add',['../poly_8h.html#aeb76035c270ec5ed04d66163badc5316',1,'poly.h']]],
  ['poly_5fcreate_5fterm_2',['Poly_create_term',['../poly_8h.html#a22eb06d186ac6534a07b56710a52303b',1,'poly.h']]],
  ['poly_5fdestroy_3',['Poly_destroy',['../poly_8h.html#adcb2653c4cfa4503725e31ffa930db25',1,'poly.h']]],
  ['poly_5fequal_4',['Poly_equal',['../poly_8h.html#a859bc29329bb61220a518e09a91a5096',1,'poly.h']]],
  ['poly_5feval_5',['Poly_eval',['../poly_8h.html#a05f68845f24873c3c3e7c9643bf2acba',1,'poly.h']]],
  ['poly_5fiterate_6',['Poly_iterate',['../poly_8h.html#ad351bf61a68908c7ed4556e037aac121',1,'poly.h']]],
  ['poly_5fprint_7',['Poly_print',['../poly_8h.html#a3ae3c98e55c98060b665da4fe8079375',1,'poly.h']]],
  ['poly_5fsub_8',['Poly_sub',['../poly_8h.html#abf02d95d2e47d588e80d6bdc3e1c3c7b',1,'poly.h']]],
  ['poly_5fto_5fstring_9',['Poly_to_string',['../poly_8h.html#a5d651811740093108fd9ce0c638a22d8',1,'poly.h']]]
];
