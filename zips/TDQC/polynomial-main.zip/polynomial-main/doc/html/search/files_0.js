var searchData=
[
  ['poly_2eh_12',['poly.h',['../poly_8h.html',1,'']]]
];
