// Used to test poly library

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../poly.h"

void triple(struct term *t);

int main(void)
{
	/*
	 * TEST Poly_create_term
	 */

	printf("Test: Poly_create_term()\n");

	Polynomial *a = Poly_create_term(2, 3);
	a->next = Poly_create_term(2, 2);

	Polynomial *b = Poly_create_term(2, 4);
	b->next = Poly_create_term(4, 3);
	b->next->next = Poly_create_term(4, 2);

	printf("Poly a: ");
	Poly_print(a);
	puts("");
	printf("Poly b: ");
	Poly_print(b);
	puts("");

	char *a_result = Poly_to_string(a);
	char *b_result = Poly_to_string(b);

	int create_result = 0;

	!strcmp(a_result, "+2x^3 +2x^2 ") ? create_result++ : create_result;
	!strcmp(b_result, "+2x^4 +4x^3 +4x^2 ") ? create_result++
						: create_result;

	printf("Test: %s\n", create_result == 2 ? "pass" : "fail");

	free(a_result);
	free(b_result);

	puts("");

	Polynomial *temp = NULL;

	/*
	 * TEST Poly_add
	 */

	printf("Test: Poly_add()\n");

	Polynomial *c = Poly_add(a, b);
	printf("Poly a + b: ");
	Poly_print(c);
	puts("");

	char *add_result = Poly_to_string(c);
	printf("Test: %s\n\n",
	       !strcmp(add_result, "+2x^4 +6x^3 +6x^2 ") ? "pass" : "fail");

	free(add_result);
	temp = c;

	/*
	 * TEST Poly_sub
	 */

	printf("Test: Poly_sub()\n");
	c = Poly_sub(a, b);
	printf("Poly a - b: ");
	Poly_print(c);
	puts("");

	char *sub_result = Poly_to_string(c);
	printf("Test: %s\n",
	       !strcmp(sub_result, "+2x^4 -2x^3 -2x^2 ") ? "pass" : "fail");

	free(sub_result);
	Poly_destroy(temp);

	Poly_destroy(a);
	Poly_destroy(b);
	Poly_destroy(c);

	puts("");

	a = Poly_create_term(2, 3);
	a->next = Poly_create_term(2, 2);

	b = Poly_create_term(2, 3);
	b->next = Poly_create_term(2, 2);

	/*
	 * TEST Poly_equal
	 */

	printf("Test: Poly_equal()\n");

	printf("Poly d: ");
	Poly_print(a);
	puts("");

	printf("Poly e: ");
	Poly_print(b);
	puts("");

	bool equal_result = Poly_equal(a, b);

	printf("Poly d == Poly e? : %s\n", Poly_equal(a, b) ? "yes" : "no");

	printf("Test: %s\n", equal_result ? "pass" : "fail");

	Poly_destroy(a);
	Poly_destroy(b);

	puts("");

	a = Poly_create_term(4, 4);
	a->next = Poly_create_term(3, 3);
	a->next->next = Poly_create_term(2, 2);

	/*
	 * TEST Poly_eval
	 */

	printf("Test: Poly_eval()\n");

	printf("Poly h: ");
	Poly_print(a);
	puts("");

	double eval_result = Poly_eval(a, 2);

	printf("Poly h eval (x = 2): %.2f\n", eval_result);
	printf("Test: %s\n", (int)eval_result == 96 ? "pass" : "fail");

	puts("");

	/*
	 * TEST Poly_to_string
	 */

	printf("Test: Poly_to_string()\n");

	char *to_string = Poly_to_string(a);
	printf("Poly h string: %s", to_string);
	puts("");

	int to_string_result = (int)strlen(to_string);

	printf("Test: %s\n", to_string_result == 18 ? "pass" : "fail");

	free(to_string);

	puts("");

	/*
	 * TEST Poly_iterate
	 */

	printf("Test: Poly_interate()\n");

	printf("Poly h: ");
	Poly_print(a);
	puts("");

	printf("Poly h -> foreach(coefficient){coefficient *= 3}\nPoly h: ");
	Poly_iterate(a, triple);
	Poly_print(a);

	puts("");

	char *interate = Poly_to_string(a);
	printf("Test: %s\n",
	       !strcmp(interate, "+12x^4 +9x^3 +6x^2 ") ? "pass" : "fail");
	free(interate);
	Poly_destroy(a);
}

void triple(struct term *t)
{
	t->coeff *= 3;
}