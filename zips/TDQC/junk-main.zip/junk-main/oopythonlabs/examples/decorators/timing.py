from functools import wraps, partial
from time import process_time, perf_counter
from sys import stderr

def timer(original_function):
    def wrapper(*args, **kwargs):
        return _helper(original_function, *args, **kwargs)
    return wrapper

def wrapped_timer(original_function):
    @wraps(original_function)
    def wrapper(*args, **kwargs):
        return _helper(original_function, *args, **kwargs)
    return wrapper


def _helper(original_function, *args, **kwargs):
    start_times = process_time(), perf_counter()
    original_return = original_function(*args, **kwargs)
    end_times = process_time(), perf_counter()
    print(f"{original_function.__name__}({args}, {kwargs}) took:",
          f"  {end_times[0] - start_times[0]:.8f} total seconds and",
          f"  {end_times[1] - start_times[1]:.8f} CPU seconds",
          sep="\n", file=stderr)
    return original_return
