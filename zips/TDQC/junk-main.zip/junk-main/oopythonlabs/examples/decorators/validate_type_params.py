from more_validators import TypeValidator

class SpecificClass:
    pass

def process_a_type(data_type):
    """Prints out the type of parameter it receives"""
    print(f"Received type {type(data_type)}")

@TypeValidator(0, SpecificClass)
def process_a_type_again(data_type):
    """Prints out the type of parameter it receives"""
    print(f"Received type {type(data_type)}")


def main():

    for data_type in (list(), tuple(), int(), dict(), set(), SpecificClass()):
        try:
           print("Not Checked:")
           process_a_type(data_type)
           print("Checked:")
           process_a_type_again(data_type)
        except Exception as e:
           print(type(e).__name__, "~",  e)
        finally:
           print("*" * 50)


if __name__ == "__main__":
    main()
