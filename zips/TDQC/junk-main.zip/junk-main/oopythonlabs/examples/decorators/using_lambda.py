#!/usr/bin/env python3
def main():
    people = ["Angie Young", "Declan Martinez", "Alice Walker",
             "Jeffrey Mitchell", "Janet Williams"]
    print("Before:", people)
    people.sort(key=lambda x: x.split()[1])
    print("After:", people)

if __name__ == '__main__':
    main()
