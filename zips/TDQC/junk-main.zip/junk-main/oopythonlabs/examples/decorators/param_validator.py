from functools import wraps


class ParamValidator:
    def __init__(self, arg_num, type_checker, value_checker):
        self._arg_num = arg_num;
        self._type_checker = type_checker
        self._value_checker = value_checker

    def __call__(self, original_function):
        @wraps(original_function)
        def wrapper(*args, **kargs):
            if len(args) < self._arg_num:
                fmt = "requires at least {} parameters; {} provided."
                self._raise_exception(TypeError, original_function,
                                      fmt.format(self._arg_num, len(args)))
            elif msg := self._type_checker(args[self._arg_num]):
                self._raise_exception(TypeError, original_function, msg)
            elif msg := self._value_checker(args[self._arg_num]):
                self._raise_exception(ValueError, original_function, msg)
            return original_function(*args, **kargs)
        return wrapper

    def _raise_exception(self, exc_type, function_, msg):
        raise exc_type(f"{function_.__name__}: {msg}")
