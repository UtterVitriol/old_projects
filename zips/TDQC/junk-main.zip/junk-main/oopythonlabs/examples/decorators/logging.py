from functools import wraps, partial
from datetime import datetime
from os import getpid


def logger(original_function=None, /, *,
           logfile=f"/tmp/logfile-{getpid()}.txt"):
    function_name = original_function.__name__ if original_function else None
    print(f"Logging {function_name} to {logfile}")
    if original_function is None:
        return partial(logger, logfile=logfile)

    @wraps(original_function)
    def wrapper(*args, **kwargs):
        try:
            original_return = original_function(*args, **kwargs)
        except Exception as e:
            msg = (f"{datetime.now()}: Exception {e} occurred when running "
                   f"{original_function.__name__}")
            raise
        else:
            msg = (f"{datetime.now()}: {original_function.__name__}"
                   f"({args}, {kwargs}) => {repr(original_return)}")
            return original_return
        finally:
            with open(logfile, "a") as f:
                print(msg, file=f)
    return wrapper


if __name__ == "__main__":

    @logger(logfile="/tmp/logging")
    def first(a, b, c=None, *d, **e):
        print(a, b, c, d, e)

    first(1, 2, 3, 4, 5, kilroy="Here", test="Test 1")

    @logger()
    def second(a, b, c=None, *d, **e):
        print(a, b, c, d, e)

    second(1, 2, 3, 4, 5, kilroy="Here", test="Test 2")

    @logger
    def third(a, b, c=None, *d, **e):
        print(a, b, c, d, e)

    third(1, 2, 3, 4, 5, kilroy="Here", test="Test 3")
