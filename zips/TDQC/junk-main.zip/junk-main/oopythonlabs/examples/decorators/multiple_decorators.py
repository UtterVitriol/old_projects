def first_decorator(original):
    print("first_decorator")
    def f(*args, **kargs):
        print("A")
        return original(*args, **kargs)
    return f

def second_decorator(original):
    print("first_decorator")
    def f(*args, **kargs):
        print("B")
        return original(*args, **kargs)
    return f

@first_decorator
@second_decorator
def some_function():
    pass

some_function()
