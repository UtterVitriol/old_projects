from more_validators import PositiveIntValidator, StringRegExValidator

def process_phone_number(idx, phone):
    print(f"Received {idx} and {phone}")

@PositiveIntValidator(0)
@StringRegExValidator(1, r"(\(?\d{3}\)?)?[-\s.]?\d{3}[-\s.]\d{4}")
def process_phone_number_again(idx, phone):
    print(f"Received {idx} and {phone}")


def main():
    data = ["(555) 555-1212", "(555) 555-1212 extension 007", "8675-309"]
    for idx, ph in enumerate(data):
        try:
            print("Not Checked:")
            process_phone_number(idx, ph)
            print("Checked:")
            process_phone_number_again(idx, ph)
        except Exception as e:
            print(type(e).__name__, "~",  e)
        finally:
            print("*" * 50)


if __name__ == "__main__":
    main()
