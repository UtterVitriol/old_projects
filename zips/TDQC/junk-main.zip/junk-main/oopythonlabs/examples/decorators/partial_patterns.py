#!/usr/bin/env python3
import functools
import re


def main():
    date_regex = r"^(0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01])/\d{4}"
    time_regex = r"^([01]\d|2[0-3])(:[0-5][0-9]){2}"
    ssn_regex = r"^\d{3}-\d{2}-\d{4}"
    regex_patterns = [date_regex, time_regex, ssn_regex]
    allowed = []
    for pattern in regex_patterns:
        allowed.append(functools.partial(re.match, pattern))

    with open("patterns.txt") as the_data:
        lines = the_data.readlines()

    for line in lines:
        if any([True for test in allowed if test(line.rstrip())]):
            print(line.rstrip(), " was a match")


if __name__ == '__main__':
    main()
