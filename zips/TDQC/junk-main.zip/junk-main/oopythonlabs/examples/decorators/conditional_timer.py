from functools import wraps, partial
from time import process_time, perf_counter
from sys import stderr

def conditional_timer(original_function=None, /, *, condition=lambda *a, **k: True):
    if original_function is None:
        return partial(conditional_timer, condition=condition)

    @wraps(conditional_timer)
    def wrapper(*args, **kwargs):
        if condition(*args, **kwargs):
            start_times = process_time(), perf_counter()

        original_return = original_function(*args, **kwargs)

        if condition(*args, **kwargs):
            end_times = process_time(), perf_counter()
            print(f"{original_function.__name__}({args}, {kwargs}) took:",
                  f"  {end_times[0] - start_times[0]:.8f} total seconds and",
                  f"  {end_times[1] - start_times[1]:.8f} CPU seconds",
                  sep="\n", file=stderr)
        return original_return
    return wrapper
