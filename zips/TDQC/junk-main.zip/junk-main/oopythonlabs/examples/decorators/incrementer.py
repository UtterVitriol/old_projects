#!/usr/bin/env python3
def create_incrementer(starting_value):
        def increment(y):
            nonlocal starting_value
            starting_value += y
            return starting_value

        return increment

if __name__ == '__main__':
    plus_equal = create_incrementer(10)
    print(plus_equal(5))
    print(plus_equal(3))
    print(plus_equal(7))
