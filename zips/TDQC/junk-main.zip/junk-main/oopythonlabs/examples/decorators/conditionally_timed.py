#!/usr/bin/env python3
from conditional_timer import conditional_timer

timing_enabled = True

@conditional_timer(condition = lambda n: timing_enabled and n > 10)
def fibonacci(n):
    '''Calculate and return the Nth Fibonacci number using iterator'''
    if n < 2:
        return n
    curr, last = 1, 0
    for _ in range(n):
        curr, last = curr + last, curr
    return last

if __name__ == "__main__":
    for i in range(10):
        print(f"fib({i}) is {fibonacci(i)}")

    print(f"fib(300) is {fibonacci(300)}")
