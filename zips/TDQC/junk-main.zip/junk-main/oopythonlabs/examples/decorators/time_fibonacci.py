#!/usr/bin/env python3
from timing import timer, wrapped_timer

def fibonacci(n):
    '''Calculate and return the Nth Fibonacci number using iterator'''
    if n < 2:
        return n
    curr, last = 1, 0
    for _ in range(n):
        curr, last = curr + last, curr
    return last


def _invoke(fibonacci):  # helper function to keep code DRY
    print("-" * 30)
    print(fibonacci.__name__, fibonacci.__doc__, sep=" : ")
    print(f"fibonacci(300) is {fibonacci(300)}")


if __name__ == "__main__":
    print(fibonacci.__name__, fibonacci.__doc__, sep=" : ")
    for i in range(10):
        print(fibonacci(i), end=" ")
    print()

    original_fib = fibonacci
    fibonacci = timer(fibonacci)         # loses original name and doc string
    _invoke(fibonacci)


    fibonacci = original_fib
    fibonacci = wrapped_timer(fibonacci) # Keeps original name and doc string
    _invoke(fibonacci)
