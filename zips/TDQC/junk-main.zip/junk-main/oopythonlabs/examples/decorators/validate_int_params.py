from more_validators import PositiveIntValidator

def process_two_params(value1, value2):
    print(f"Received {value1} and {value2}")


@PositiveIntValidator(0)
@PositiveIntValidator(1)
def process_two_params_again(value1, value2):
    print(f"Received {value1} and {value2}")


def main():
    dataset = ((1, 2), ("Hello", -1), (1, 3.45), (-2, 1), (1, -5))
    for a, b in dataset:
        try:
            print("Not Checked:")
            process_two_params(a, b)
            print("Checked:")
            process_two_params_again(a, b)
        except Exception as e:
            print(type(e).__name__, "~",  e)
        finally:
            print("*" * 50)



if __name__ == "__main__":
    main()
