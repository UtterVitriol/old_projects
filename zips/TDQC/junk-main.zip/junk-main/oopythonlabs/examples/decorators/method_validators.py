import inspect
from more_validators import TypeValidator, StringRegExValidator

class Contact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone

    def __str__(self):
        return f"{self.name}: {self.phone}"

    @property
    def name(self):
        return self._name

    @name.setter
    @TypeValidator(1, str)
    def name(self, name):
        self._name = name

    @property
    def phone(self):
        return self._phone

    @phone.setter
    @StringRegExValidator(1, r"(\(?\d{3}\)?)?[-\s.]?\d{3}[-\s.]\d{4}")
    def phone(self, phone):
        self._phone = phone


def main():
    names_and_numbers = (("Operator", 0), ("Liam", "(555) 555-1212"),
                         ("Bond, James", "(555) 555-1212 extension 007"),
                         ("Jenny", "8675-309"))
    for name, number in names_and_numbers:
        try:
            print(Contact(name, number))
        except Exception as e:
            print(type(e).__name__, "~",  e)



if __name__ == "__main__":
    main()
