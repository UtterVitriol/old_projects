import re
from param_validator import ParamValidator

class TypeValidator(ParamValidator):
    def __init__(self, arg_num, type_, value_check = lambda v: None):
        def _function_to_wrap(v):
            if isinstance(v, type_):
                return None
            else:
                fmt = "parameter {} must be of type {} not a {}"
                return fmt.format(arg_num, type_.__name__, type(v))
        super().__init__(arg_num, _function_to_wrap, value_check)

class PositiveIntValidator(TypeValidator):
    def __init__(self, arg_num):
        def _function_to_wrap(v):
             if v > 0:
                 return None
             else:
                 fmt= "parameter {} must be a positive int, not {}"
                 return fmt.format(arg_num, v)
        super().__init__(arg_num, int, _function_to_wrap)



class StringRegExValidator(TypeValidator):
    def __init__(self, arg_num, pattern):
        if not isinstance(pattern, str):
            raise TypeError("StringRegExValidator requires a string parameter")
        def _function_to_wrap(v):
            if self._validator.match(v):
                return None
            else:
                fmt = "parameter {} with value of {} must match regex of {}"
                return fmt.format(arg_num, v, pattern)
        super().__init__(arg_num, str, _function_to_wrap)
        self._validator = re.compile(pattern)
