#!/usr/bin/env python3
from examples.implementing.cuboid_alt import Cuboid

def main():
    box = Cuboid(3,4,5)
    print(f"length:{box.length} width:{box.width} height:{box.height}")
    print(box)

if __name__ == '__main__':
    main()
