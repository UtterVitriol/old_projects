#!/usr/bin/env python3
from examples.implementing.snow.parcel import Parcel
from examples.implementing.snow.driveway import Driveway
from examples.implementing.snow.sidewalk import Sidewalk
from examples.implementing.snow.parkinglot import ParkingLot
from examples.implementing.snow.street import Street


def main():
    parcels = [Parcel("Next Door Neighbor", 30, .05),
               Driveway("Marcus Jones", 600, 6, "123 Main Street"),
               Sidewalk("Rachel Worthington", 40, 5,
                        "84 Linwood Dr.", "front door to driveway"),
               ParkingLot("Acme Hardware", 180 * 500, 10, "234 Second St",
                          ["15 Light Poles", "5 grass islands"]),
               Street("City of Metroplois", 4000 * 28, 18, "Poplar Dr.",
                      ["1st Street", "12th Street"])]

    print("Jobs that need to be done today:")
    for index, parcel in enumerate(parcels, start=1):
        print(f"Job#{index:03}:\n{parcel}")
        print()

    print("*" * 50)
    print("Time to start the day:")
    for index, parcel in enumerate(parcels, start=1):
        print("Job #", index, end=" ")
        parcel.clear()


if __name__ == '__main__':
    main()
