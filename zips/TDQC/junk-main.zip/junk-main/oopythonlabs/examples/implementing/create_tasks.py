#!/usr/bin/env python3
from examples.implementing.snow.tasks import Tasks
from examples.implementing.snow.parcel import Parcel
from examples.implementing.snow.driveway import Driveway
from examples.implementing.snow.sidewalk import Sidewalk
from examples.implementing.snow.parkinglot import ParkingLot
from examples.implementing.snow.street import Street

def get_tasks():
   tasks = Tasks()
   tasks.add(Parcel("Next Door Neighbor", 30, .05))
   tasks.add(Driveway("Marcus Jones", 600, 6, "123 Main Street"))
   tasks.add(Sidewalk("Rachel Worthington", 40, 5, "84 Linwood Dr.",
                      "front door to driveway"))
   tasks.add(ParkingLot("Acme Hardware", 180 * 500, 10, "234 Second St",
                        ["15 Light Poles", "5 grass islands"]))
   tasks.add(Street("City of Metroplois", 4000 * 28, 18, "Poplar Dr.",
                    ["1st Street", "12th Street"]))
   tasks.add(Driveway("Claudette Rustin", 850, 15, "76 South St"))
   tasks.add(Driveway("Emma Rodriguez", 525, 4, "675 Hollow Dr"))
   tasks.add(ParkingLot("County High School", 180 * 200, 13, "34 River Dr",
                        ["12 Handicap Signs"]))
   tasks.add(Driveway("Minnie Johnson", 800, 7.5, "1002 Princeton Pl"))
   return tasks

def main():
    tasks = get_tasks()
    print("These are all the customers we have today:\n")
    print(", ".join(task.owner for task in tasks.tasks))
    print()
    print("Joe, since you have the snow blower, you'll clear these customers")
    for driveway in tasks.driveways:
        print(driveway, end="\n\n")

    print("Mary, call in when you are done with the last ParkingLot at:",
           list(tasks.parkinglots)[-1].address)
    print("We'll let you know if there are any streets you can help with")


if __name__ == '__main__':
    main()
