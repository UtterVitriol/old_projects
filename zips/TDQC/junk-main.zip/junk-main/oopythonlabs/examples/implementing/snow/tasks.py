#!/usr/bin/env python3
from examples.implementing.snow.driveway import Driveway
from examples.implementing.snow.sidewalk import Sidewalk
from examples.implementing.snow.parkinglot import ParkingLot
from examples.implementing.snow.street import Street


class Tasks:
    def __init__(self):
        self._parcels = []

    def add(self, parcel):
        self._parcels.append(parcel)

    def __str__(self):
        return "\n\n".join(str(parcel) for parcel in self._parcels)

    @property
    def tasks(self):
        return list(self._parcels)

    @property
    def sidewalks(self):
        return self._filter_parcels(Sidewalk)

    @property
    def driveways(self):
        return self._filter_parcels(Driveway)

    @property
    def parkinglots(self):
        return self._filter_parcels(ParkingLot)

    @property
    def streets(self):
        return self._filter_parcels(Street)

    def _filter_parcels(self, parcel_type):
        return (parcel for parcel in self._parcels
                if isinstance(parcel, parcel_type))
