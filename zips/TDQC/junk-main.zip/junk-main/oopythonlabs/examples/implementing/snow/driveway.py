#!/usr/bin/env python3
from examples.implementing.snow.parcel import Parcel


class Driveway(Parcel):
    def __init__(self, owner, linear_feet, distance_to_site, address):
        super().__init__(owner, linear_feet, distance_to_site)
        self._address = address

    @property
    def address(self):
        return self._address

    def clear(self):
        print("Clearing the driveway with snow blower")

    def __str__(self):
        fmt = "{}\nAddress:{}"
        return fmt.format(super().__str__(), self._address)
