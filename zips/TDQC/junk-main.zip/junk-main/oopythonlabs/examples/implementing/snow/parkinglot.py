#!/usr/bin/env python3
from examples.implementing.snow.parcel import Parcel


class ParkingLot(Parcel):
    def __init__(self, owner, linear_feet, distance_to_site,
                 address, obstacles):
        super().__init__(owner, linear_feet, distance_to_site)
        self._address = address
        self._obstacles = obstacles

    @property
    def address(self):
        return self._address

    @property
    def obstacles(self):
        return self._obstacles

    def clear(self):
        print("Plowing the parking lot and avoiding the obstacles throughout")

    def __str__(self):
        fmt = "{}\nAddress:{}\nObstacles:\n\t{}"
        return fmt.format(super().__str__(), self._address,
                          "\n\t".join(self._obstacles))
