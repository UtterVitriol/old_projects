#!/usr/bin/env python3
from examples.implementing.snow.parcel import Parcel


class Street(Parcel):
    def __init__(self, owner, linear_feet, distance_to_site, street_name,
                 cross_streets):
        super().__init__(owner, linear_feet, distance_to_site)
        self._street_name = street_name
        self._cross_streets = cross_streets

    @property
    def street_name(self):
        return self._street_name

    @property
    def cross_streets(self):
        return self._cross_streets

    def clear(self):
        print("Plowing the street")

    def __str__(self):
        fmt = "{}\nStreet Name: {}\nIntersections: {} and {}"
        return fmt.format(super().__str__(), self._street_name,
                          *self._cross_streets)
