#!/usr/bin/env python3
from examples.implementing.snow.parcel import Parcel


class Sidewalk(Parcel):

    def __init__(self, owner, linear_feet, distance_to_site,
                 address, location):
        super().__init__(owner, linear_feet, distance_to_site)
        self._address = address
        self._location = location

    @property
    def address(self):
        return self._address

    @property
    def location(self):
        return self._location

    def clear(self):
        print("Shoveling the Sidewalk")

    def __str__(self):
        fmt = "{}\nAddress:{}\nLocation:{}"
        return fmt.format(super().__str__(), self._address, self._location)
