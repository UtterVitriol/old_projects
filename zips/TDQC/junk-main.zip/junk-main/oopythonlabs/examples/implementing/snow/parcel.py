#!/usr/bin/env python3
class Parcel:

    def __init__(self, owner, linear_feet, distance_to_site):
        self._owner = owner
        self._linear_feet = linear_feet
        self._distance_to_site = distance_to_site

    @property
    def owner(self):
        return self._owner

    @property
    def linear_feet(self):
        return self._linear_feet

    @property
    def distance_to_site(self):
        return self._distance_to_site

    def clear(self):
        print("Should clear itself once temperature gets warm enough")

    def __str__(self):
        fmt = "Parcel Owner:{}\nLinear Feet:{}\nDistanceToSite (miles):{}"
        return fmt.format(self._owner, self._linear_feet,
                          self._distance_to_site)


def main():
    parcel = Parcel("Next Door Neighbor", 30, .05)
    print("About to clear the following parcel:")
    print(parcel)
    parcel.clear()


if __name__ == '__main__':
    main()
