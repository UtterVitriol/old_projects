from examples.implementing.print_utilities import print_dictionary
class BasicClass:
    def __init__(self):
        errmsg = "{} is a singleton.  Call the {}.singleton() method."
        raise RuntimeError(errmsg.format(self.__class__.__name__, self.__class__.__name__))

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        self._name = name


    _the_singleton = None

    @classmethod
    def singleton(cls):
        if not cls._the_singleton:
            cls._the_singleton = cls.__new__(cls)
        return cls._the_singleton

    @staticmethod
    def print_singleton():
        if BasicClass._the_singleton:
            print(BasicClass.singleton())
        else:
            print("Singleton not yet created.")

    print_dictionary(locals())

if __name__ == "__main__":
    doit = BasicClass.print_singleton;

    print_dictionary(BasicClass.__dict__)

    try:
        doit()
        BasicClass()
    except Exception as e:
        print(e)

    c1 = BasicClass.singleton()
    doit()
    c2 = BasicClass.singleton()
    c3 = c1.singleton()
    if c1 == c2 == c3:
        print("They are all the same!")
    else:
        print("Something went wrong!")
