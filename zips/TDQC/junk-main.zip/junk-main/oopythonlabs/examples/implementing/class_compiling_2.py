from examples.implementing.print_utilities import print_dictionary
class BasicClass:
    print_dictionary(locals())

    def __init__(self, name):
        self.name = name

    print_dictionary(locals())
