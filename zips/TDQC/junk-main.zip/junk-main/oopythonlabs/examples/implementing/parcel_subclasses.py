#!/usr/bin/env python3
from examples.implementing.snow.driveway import Driveway
from examples.implementing.snow.sidewalk import Sidewalk
from examples.implementing.snow.parkinglot import ParkingLot
from examples.implementing.snow.street import Street


def main():
    rule = "#" * 50
    driveway = Driveway("Marcus Jones", 600, 6, "123 Main Street")
    print(driveway.owner, "is the owner of the", type(driveway).__name__, "at",
          driveway.address)
    print(rule)

    sidewalk = Sidewalk("Rachel Worthington", 40, 5, "84 Linwood Dr.",
                        "front door to driveway")
    fmt = "The distance to {0}'s sidewalk is {1} miles,"
    print(fmt.format(sidewalk.owner, sidewalk.distance_to_site))
    print("and the location is as follows:", sidewalk.location)
    print(rule)

    parking_lot = ParkingLot("Acme Hardware", 180 * 500, 10, "234 Second St",
                             ["15 Light Poles", "5 grass islands"])
    print("The parking lot is", parking_lot.linear_feet, "linear feet,")
    print("and has the following obstacles:", parking_lot.obstacles)
    print(rule)

    street = Street("City of Metropolis", 4000 * 28, 18, "Poplar Dr.",
                    ["1st Street", "12th Street"])
    fmt = "The street owned by:{} is between {} and {}"
    print(fmt.format(street.owner, *street.cross_streets))


if __name__ == '__main__':
    main()
