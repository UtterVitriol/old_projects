#!/usr/bin/env python3
from examples.implementing.rectangle import Rectangle
class Cuboid(Rectangle):

    def __init__(self, length=1, width=1, height=1):
        super().__init__(length, width)
        self.height = height

    @property
    def height(self):
        """height of the Cuboid"""
        return self._height

    @height.setter
    def height(self, height):
        self._height = height

    @property
    def area(self):
        """ returns the three dimensional surface area of the Cuboid"""
        return  2 * (self._length * self._width +
                     self._width * self._height +
                     self._height * self._length)

    @property
    def volume(self):
        """ returns the three dimensional volume of the Cuboid"""
        super().area() * self._height

    def __str__(self):
        return f"{super().__str__()} x {self._height}"
