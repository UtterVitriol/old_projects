#!/usr/bin/env python3
from examples.implementing.rectangle import Rectangle
class Cuboid(Rectangle):

    def __init__(self, length=1, width=1, height=1):
        pass

    @property
    def height(self):
        pass

    @height.setter
    def height(self, height):
        pass

    @property
    def area(self):
        pass

    @property
    def volume(self):
        pass

    def __str__(self):
        pass

if __name__ == '__main__': pass
