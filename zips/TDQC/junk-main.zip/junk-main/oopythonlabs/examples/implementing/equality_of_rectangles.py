#!/usr/bin/env python3
from examples.implementing.rectangle_equality import Rectangle

def test_equality(obj1, obj2):
    return "=" if obj1 == obj2 else "!="

def main():
    rect1 = Rectangle(6, 10)
    rect2 = Rectangle(6, 10)
    rect3 = Rectangle(5,9)
    rect4 = rect3
    print(rect1, test_equality(rect1, rect2), rect2)
    print(rect1, test_equality(rect1, rect3), rect3)
    print(rect3, test_equality(rect3, rect4), rect4)
    rect1 = rect3
    print(rect1, test_equality(rect1, rect3), rect3)

if __name__ == '__main__':
    main()
