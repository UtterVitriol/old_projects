#!/usr/bin/env python3
class Rectangle:

    def __init__(self, length = 1, width = 1):
        self.length = length
        self.width = width

    @property
    def length(self):
        """length of the Rectangle"""
        return self._length

    @property
    def width(self):
        """width of the Rectangle"""
        return self._width

    @length.setter
    def length(self, length):
        self._length = length

    @width.setter
    def width(self, width):
        self._width = width

    @property
    def area(self):
        """ returns the two dimensional area of the Rectangle"""
        return self._length * self._width

    def __str__(self):
        return f"{self._length} x {self._width}"

    def __eq__(self, obj):
        return self.length == obj.length and self.width == obj.width
