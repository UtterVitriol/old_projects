def print_dictionary(dictionary):
    max_length = len(max(dictionary.keys(), key=len))
    print("*** Dictionary")
    for key, value in dictionary.items():
        print(f"    Key: {key:{max_length}}, Value: {value}")
    print()
