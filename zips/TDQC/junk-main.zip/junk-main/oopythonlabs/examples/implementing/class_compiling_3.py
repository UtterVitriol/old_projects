from examples.implementing.print_utilities import print_dictionary
class BasicClass:
    def __init__(self, name):
        self.name = name

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    print_dictionary(locals())

    name = property(get_name, set_name)

    print_dictionary(locals())
