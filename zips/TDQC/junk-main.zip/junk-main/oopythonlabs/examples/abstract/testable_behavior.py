#!/usr/bin/env python3
from examples.abstract.send_receive_withhook import SendReceive
from examples.abstract.send_receive_impl import SendReceiveAllUpper
from examples.abstract.register_unrelated import Trunctated
from examples.abstract.registered_lie import DoesNotSendReceive

if __name__ == '__main__':

    SendReceive.register(DoesNotSendReceive)
    instances = (SendReceiveAllUpper(), Trunctated(15), DoesNotSendReceive())

    for index, instance in enumerate(instances):
        if isinstance(instance, SendReceive):
            with open("data_source.txt") as input, open(f"output-{index}", "w") as output:
                instance.send(output, instance.receive(input))
        else:
            print(f"{instance.__class__.__name__} is not a SendReceive")
