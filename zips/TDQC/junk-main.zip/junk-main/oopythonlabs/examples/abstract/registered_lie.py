#!/usr/bin/env python3
from examples.abstract.send_receive import SendReceive

class DoesNotSendReceive:
    pass

if __name__ == '__main__':
    SendReceive.register(DoesNotSendReceive)
    print('Subclass:', issubclass(DoesNotSendReceive, SendReceive))
    print('Instance:', isinstance(DoesNotSendReceive(), SendReceive))
    print('MRO:')
    for class_ in DoesNotSendReceive.mro():
        print("  ", class_)
