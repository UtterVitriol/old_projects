#!/usr/bin/env python3
from examples.abstract.send_receive import SendReceive

@SendReceive.register
class Trunctated():
    def __init__(self, count):
        self._count = count

    def receive(self, source):
        return source.read(self._count)

    def send(self, destination, data):
        return destination.write(data[:self._count])


if __name__ == '__main__':
    print('Subclass:', issubclass(Trunctated, SendReceive))
    print('Instance:', isinstance(Trunctated(20), SendReceive))
    print('MRO:')
    for class_ in Trunctated.mro():
        print("  ", class_)
