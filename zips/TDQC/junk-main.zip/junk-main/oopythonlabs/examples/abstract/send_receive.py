#!/usr/bin/env python3
from abc import ABC, abstractmethod

class SendReceive(ABC):

    @abstractmethod
    def receive(self, source):
        """Retrieve data from the source and return an object."""

    @abstractmethod
    def send(self, destination, data):
        """Send the data object to the destination."""
