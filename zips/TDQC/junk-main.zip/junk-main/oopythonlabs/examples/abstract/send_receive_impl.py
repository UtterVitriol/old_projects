#!/usr/bin/env python3
from examples.abstract.send_receive import SendReceive
class SendReceiveAllUpper(SendReceive):

    def receive(self, source):
        return source.read().upper()

    def send(self, destination, data):
        return destination.write(data.upper())


if __name__ == '__main__':
    print('Subclass:', issubclass(SendReceiveAllUpper, SendReceive))
    print('Instance:', isinstance(SendReceiveAllUpper(), SendReceive))
    print('MRO:')
    for class_ in SendReceiveAllUpper.mro():
        print("  ", class_)
