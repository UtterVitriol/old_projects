#!/usr/bin/env python3
from abc import ABC, abstractmethod

class SendReceive(ABC):

    @abstractmethod
    def receive(self, source):
        """Retrieve data from the source and return an object."""

    @abstractmethod
    def send(self, destination, data):
        """Send the data object to the destination."""

    @classmethod
    def __subclasshook__(cls, class_to_check):
        '''Verify that we have load and save methods in the MRO'''
        if cls is SendReceive:
            sendable = True if any("send" in a_class.__dict__
                for a_class in class_to_check.mro()) else False
            receivable = True if any("receive" in a_class.__dict__
                for a_class in class_to_check.mro()) else False
            return sendable and receivable
        return NotInplemented()
