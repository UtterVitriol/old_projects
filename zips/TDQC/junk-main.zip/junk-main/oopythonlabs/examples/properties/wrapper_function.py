#!/usr/bin/env python3
import time
def function_timer(your_function):
    def counter():
        start = time.perf_counter()
        result = your_function()
        end = time.perf_counter()
        return (result, end - start)
    return counter

def prompt_user():
    print("please enter some text: ")
    return input()

if __name__ == '__main__': pass