#!/usr/bin/env python3
from examples.oodesign.wrapper_function import function_timer

@function_timer
def prompt_user():
    print("please enter some text: ")
    return input()

if __name__ == '__main__': pass