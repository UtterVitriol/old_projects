#!/usr/bin/env python3
import abc, math
from dataclasses import dataclass, field
from typing import ClassVar
from builtins import str

@dataclass(frozen=True)
class Shape():
    id: ClassVar[int] = 100
    name:str
    
    def __post_init__(self):
        self.__dict__["number"] = Shape.id
        Shape.id += 1

    @abc.abstractmethod
    def area(self):
        pass  # Intended o be implemented by subclasses

    @abc.abstractmethod
    def perimeter(self):
        pass  # Intended o be implemented by subclasses

    def __str__(self):
        return "Name:{}  id:{}".format(self.name, self.number)

class Circle(Shape):
    def __init__(self, name, radius):
        super().__init__(name)
        self.radius = radius
    def __str__(self):
        fmt = "{}  Radius:{}"
        return fmt.format(super().__str__(), self.radius)
    def area(self):
        return math.pi * self.radius ** 2   
    def perimeter(self):
        return 2 * math.pi * self.radius

@dataclass(frozen=True)
class Rectangle(Shape):
    length: int
    width: int
    def __str__(self):
        fmt = "{}  Length:{} Width:{}"
        return fmt.format(super().__str__(), self.length,
                          self.width)
    def area(self):
        return self.length * self.width
    def perimeter(self):
        return 2 * self.length + 2 * self.width

r1 = Rectangle(name="Me", length=5, width=4)
r2 = Rectangle(name="Other", length=6, width=7)
r3 = Rectangle("Other", 9, 99)
print(r1)
print(r2)
print(r3)