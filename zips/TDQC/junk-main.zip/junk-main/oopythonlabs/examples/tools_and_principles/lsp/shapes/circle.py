#!/usr/bin/env python3
import math
from dataclasses import dataclass

from shape import Shape

@dataclass(frozen=True)
class Circle(Shape):
    radius:int

    def __str__(self):
        fmt = "{}  Radius:{}"
        return fmt.format(super().__str__(), self.radius)

    def area(self):
        return math.pi * self.radius ** 2
    
    def perimeter(self):
        return 2 * math.pi * self.radius
    
