import abc
from dataclasses import dataclass, field
from typing import ClassVar

@dataclass(frozen=True)
class Shape():
    id: ClassVar[int] = 100
    name:str
    
    def __post_init__(self):
        self.__dict__["number"] = Shape.id
        Shape.id += 1

    @abc.abstractmethod
    def area(self):
        pass  # Intended o be implemented by subclasses

    @abc.abstractmethod
    def perimeter(self):
        pass  # Intended o be implemented by subclasses

    def __str__(self):
        return "Name:{}  id:{}".format(self.name, self.number)