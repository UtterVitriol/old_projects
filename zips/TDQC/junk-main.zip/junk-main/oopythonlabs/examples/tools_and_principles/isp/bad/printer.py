import os
from abc import ABC, abstractmethod

class Printer(ABC):
    @abstractmethod
    def print_it(self):
        pass

    @abstractmethod
    def scan_it(self, file_name):
        pass

    @abstractmethod
    def fax_it(self, fax_number):
        pass
    
    @abstractmethod
    def email_it(self, email_address):
        pass