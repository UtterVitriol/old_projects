from printer import Printable, Scannable

class PrintAndScan(Printable, Scannable):
    def __init__(self, data):
        self.data = data
    
    def print_it(self):
        print("Printing")
        print(self.data)

    def scan_it(self, file_name):
        print("Scanning to:", file_name)
        with open(file_name, "w") as scan_to:
            scan_to.write(self.data)