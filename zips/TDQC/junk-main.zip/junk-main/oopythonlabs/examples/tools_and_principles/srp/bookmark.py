#!/usr/bin/env python3
class Bookmark:

    def __init__(self, book, page):
        self.book = book
        self.page = page

    def __str__(self):
        fmt = "Bookmark:\nPage: {1}\Book : {2}"
        return fmt.format(self.page, self.book.title)
