#!/usr/bin/env python3
def words(filename):
    words = []
    with open(filename) as the_file:
        text = the_file.read()
    for each_line in [line for line in text.split("\n")]:
        words.extend(each_line.split())
    print(words)


def main():
    words("declaration_of_independance.txt")


if __name__ == "__main__":
    main()
