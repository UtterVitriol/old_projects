#!/usr/bin/env python3
class Book:

    def __init__(self, title, author, pages):
        self.title = title
        self.author = author
        self.pages = pages
        self.current_page = 0

    def __str__(self):
        fmt = "Title: {0}\nAuthor: {1}\nPages: {2}\nCurrent Page: {3}"
        return fmt.format(self.title, self.author, self.pages,
                          self.current_page)
