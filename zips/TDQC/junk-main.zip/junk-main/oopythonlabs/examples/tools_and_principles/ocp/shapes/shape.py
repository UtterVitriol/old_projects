#!/usr/bin/env python3
import abc


class Shape(abc.ABC):
    id = 100

    def __init__(self, name):
        self.name = name
        self.number = Shape.id
        Shape.id += 1

    @abc.abstractmethod
    def area(self):
        pass  # Intended o be implemented by subclasses

    @abc.abstractmethod
    def perimeter(self):
        pass  # Intended o be implemented by subclasses

    @property
    def name(self): return self._name

    @name.setter
    def name(self, name): self._name = name

    def __str__(self):
        return "Name:{}  id:{}".format(self.name, self.number)
