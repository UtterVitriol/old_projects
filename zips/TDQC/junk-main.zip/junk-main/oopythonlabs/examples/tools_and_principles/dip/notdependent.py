import os
from abc import ABC, abstractmethod

class AbstractEnvironment(ABC):
    @abstractmethod
    def get_home(self):
        pass

    @abstractmethod
    def get_user(self):
        pass

class OSEnvironment(AbstractEnvironment):
    def get_home(self):
        return os.getenv("HOME")
    def get_user(self):
        return os.getenv("USER")

class HardCodedEnvironment(AbstractEnvironment):
    def get_home(self):
        return "/home/default"
    
    def get_user(self):
        return "default"


class DependsOnEnv:
    def __init__(self, abstract_environment):
        self.abstract_environment = abstract_environment

    def get_home(self):
        return self.abstract_environment.get_home()
    def get_user(self):
        return self.abstract_environment.get_user()
        
doe = DependsOnEnv(HardCodedEnvironment())

print(doe.get_home())
print(doe.get_user())


doe = DependsOnEnv(OSEnvironment())

print(doe.get_home())
print(doe.get_user())