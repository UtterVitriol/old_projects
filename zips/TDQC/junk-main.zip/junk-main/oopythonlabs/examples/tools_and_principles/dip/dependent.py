import os

class DependsOnEnv:
    def get_home(self):
        return os.getenv("HOME")
    def get_user(self):
        return os.getenv("USER")
        
doe = DependsOnEnv()

print(doe.get_home())
print(doe.get_user())