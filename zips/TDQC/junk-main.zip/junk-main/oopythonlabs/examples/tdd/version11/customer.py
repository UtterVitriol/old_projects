#!/usr/bin/env python3
class Customer:
    def __init__(self, first_name, last_name, job, hired):
        self.first_name = first_name
        self.last_name = last_name
        self.job = job
        self.hired = hired

    @property
    def first_name(self): return self._first_name

    @first_name.setter
    def first_name(self, fname): self._first_name = fname

    @property
    def last_name(self): return self._last_name

    @last_name.setter
    def last_name(self, lname): self._last_name = lname

    @property
    def job(self): return self._job

    @job.setter
    def job(self, job): self._job = job

    @property
    def hired(self): return self._hired

    @hired.setter
    def hired(self, hired): self._hired = hired

    @property
    defcustomer_id(self): pass
