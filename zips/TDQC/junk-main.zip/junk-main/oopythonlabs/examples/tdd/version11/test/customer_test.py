#!/usr/bin/env python3
import unittest
import datetime
import examples.tdd.version11.customer as customer

class TestCustomer(unittest.TestCase):

    def setUp(self):
        self.customer_ = customer.Customer("Karen", "Jones", "Manager",
                                datetime.date.today())
        # print("Debug: setUp method being called")

    def test_get_customer_properties(self):
        self.assertEqual(self.customer_.first_name, "Karen")
        self.assertEqual(self.customer_.last_name, "Jones")
        self.assertEqual(self.customer_.job, "Manager")
        self.assertEqual(self.customer_.hired, datetime.date.today())

    def test_get_customer_id(self):
        self.assertTrue(hasattr(self.customer_, "customer_id"))

    def test_cannot_change_customer_id(self):
        with self.assertRaises(AttributeError):
            self.customer_.customer_id = 99

if __name__ == "__main__":
    unittest.main()
