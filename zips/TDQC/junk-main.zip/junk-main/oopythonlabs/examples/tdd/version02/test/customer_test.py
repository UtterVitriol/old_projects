#!/usr/bin/env python3
import unittest
import examples.tdd.version02.customer as customer

class TestCustomer(unittest.TestCase):

    def test_customer_object_creation(self):
        customer_ = customer.Customer()

if __name__ == "__main__":
    unittest.main()