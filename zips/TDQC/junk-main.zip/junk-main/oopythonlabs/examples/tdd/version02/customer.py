#!/usr/bin/env python3
class Customer:
    pass