#!/usr/bin/env python3
import unittest
import datetime
import examples.tdd.version06.customer as customer

class TestCustomer(unittest.TestCase):

    def test_customer_object_creation(self):
        customer_ = customer.Customer("Karen", "Jones", "kj@koolmail.net",
                                      datetime.date.today())

    def test_get_customer_properties(self):
        customer_ = customer.Customer("Karen", "Jones", "kj@koolmail.net",
                                      datetime.date.today())
        self.assertEqual(customer_.first_name, "Karen")
        self.assertEqual(customer_.last_name, "Jones")
        self.assertEqual(customer_.email, "kj@koolmail.net")
        self.assertEqual(customer_.enrolled, datetime.date.today())

if __name__ == "__main__":
    unittest.main()
