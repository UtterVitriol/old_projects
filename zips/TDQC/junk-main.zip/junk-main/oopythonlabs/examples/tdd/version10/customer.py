#!/usr/bin/env python3

class Customer:
    def __init__(self, first_name, last_name, email, enrolled):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.enrolled = enrolled
        self._customer_id = 1

    @property
    def first_name(self): return self._first_name

    @first_name.setter
    def first_name(self, fname): self._first_name = fname

    @property
    def last_name(self): return self._last_name

    @last_name.setter
    def last_name(self, lname): self._last_name = lname

    @property
    def email(self): return self._email

    @email.setter
    def email(self, email): self._email = email

    @property
    def enrolled(self): return self._enrolled

    @enrolled.setter
    def enrolled(self, enrolled): self._enrolled = enrolled

    @property
    def customer_id(self): return self._customer_id
