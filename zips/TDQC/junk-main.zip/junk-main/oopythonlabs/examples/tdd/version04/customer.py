#!/usr/bin/env python3
class Customer:
    def __init__(self, first_name, last_name, email, enrolled):
        pass
