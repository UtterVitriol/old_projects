#!/usr/bin/env python3
import unittest
import datetime
import examples.tdd.version04.customer as customer

class TestCustomer(unittest.TestCase):

    def test_customer_object_creation(self):
        customer_ = customer.Customer("Karen", "Jones", "kj@koolmail.net",
                                      datetime.date.today())

if __name__ == "__main__":
    unittest.main()
