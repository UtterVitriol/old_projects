#!/usr/bin/env python3
import unittest

class TestCustomer(unittest.TestCase):

    def test_customer_object_creation(self):
        customer_ = Customer()

if __name__ == "__main__":
    unittest.main()