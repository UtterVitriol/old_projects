#!/usr/bin/env python3

class A:
    def say_hello(self):
        return f"Hi I am an {type(self).__name__}!"

class B(A):
    def say_hello(self):
        return f"As my parent would say: {super().say_hello()}"

class C(A):
    def say_hello(self):
        return "Hello"

class D(B,C):
    pass         # No 'say_hello' defined, for now, but feel free to play!


objects = [A(), B(), C(), D()]
for obj in objects:
    print(obj.say_hello())
    print("MRO:", type(obj).mro())
    print()
