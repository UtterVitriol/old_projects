class Highlander:
    """There can be only one - using __new__"""

    _the_immortal = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        if not cls._the_immortal:
            cls._the_immortal = super().__new__(cls)
        return cls._the_immortal

    def __init__(self, *args, **kwargs):
        if not self.__class__._initialized:
            for n, value in enumerate(args):
                self.__setattr__("arg" + str(n), value)
            for k,v in kwargs.items():
                self.__setattr__(k, v)
            self.__class__._initialized = True
        else:
            print("There can be only one...")

    def __str__(self):
        return ", ".join(f"{key}: {value}" for key, value in self.__dict__.items())

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

if __name__ == "__main__":
    obj1 = Highlander("Connor", "MacLeod", weapon="katana")
    obj1.name = "Russell Nash"
    print (obj1)

    obj2 = Highlander("The Kurgan")
    obj3 = Highlander("Iman Fasil", enemy=True)
    if obj1 == obj2 == obj3:
        print("There is ONLY one")
        print(obj1)
    else:
        print("Something went wrong!")
