#!/usr/bin/env python3
def double_it(sequence):
    reject_none(sequence)
    return 2 * sequence


def every_other(a_list):
    reject_none(a_list)
    return a_list[::2]


def reject_none(an_object):
    if an_object is None:
        raise TypeError("NoneType is not allowed")
