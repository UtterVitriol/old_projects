#!/usr/bin/env python3
class ByConvention:

    def __init__(self):
        self.direct_access = "ABC"
        self._leave_alone = "LMNO"
        self.__really_dont_mess_with = "XYZ"

    def call_from_anywhere(self):
        print("This should be fine")

    def _internal_use_only(self):
        print("Only call from other methods of the class")

    def __mangle_this_(self):
        self._internal_use_only()   # This type of internal access is ok
        print("Sublcasses should have a hard time getting here")
        print(self.__really_dont_mess_with)
