#!/usr/bin/env python3
from datetime import date


class Song:

    def __init__(self):
        self.genre = "Pop Rock"
        self.release_date = date(1968, 8, 26)

    def name(self):
        return "Hey Jude"

    def artist(self):
        return "The Beatles"


def main():
    song = Song()
    print(song.name(), song.artist(), song.genre, song.release_date, sep="\n")


if __name__ == '__main__':
    main()
