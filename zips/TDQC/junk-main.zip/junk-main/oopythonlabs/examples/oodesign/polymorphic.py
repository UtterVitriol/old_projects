class Addressable:
    def address(self):
        print(type(self).__name__, "::address", sep="")


class Home(Addressable):
    pass


class WebSite:
    def address(self):
        print("127.0.0.1")


class Gettysburg:
    def address(self):
        print("Four score and seven years ago...")


def unsafe(addressables):
    for addressable in addressables:
        addressable.address()


def safe(addressables):
    for addressable in addressables:
        if hasattr(addressable, "address"):
            addressable.address()


for each_function in (unsafe, safe):
    try:
        print("Invoking:", each_function.__name__)
        print("********")
        each_function([Addressable(), Home(), WebSite(), Gettysburg(), list()])
    except Exception as e:
        print(type(e).__name__, "occured: ", e)
    finally:
        print()
