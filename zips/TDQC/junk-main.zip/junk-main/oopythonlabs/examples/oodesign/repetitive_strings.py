#!/usr/bin/env python3
first_name = input("Please enter a first name: ")
last_name = input("Please enter a last name: ")

print(first_name, last_name, end="\n\n")
print(last_name, first_name, sep = ", ", end="\n\n")
