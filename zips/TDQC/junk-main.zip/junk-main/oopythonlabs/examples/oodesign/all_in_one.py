#!/usr/bin/env python3
from printer import Printer

class AllInOne(Printer):
    def scan_it(self):
        print("Scanning");

    def fax_it(self):
        print("Faxing");

    def copy_it(self):
        print("Copying");


if __name__=="__main__":
    printer = AllInOne()
    printer.print_it()
    printer.scan_it()
    printer.fax_it()
    printer.copy_it()
