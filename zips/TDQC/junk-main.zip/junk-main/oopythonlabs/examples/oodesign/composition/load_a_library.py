#!/usr/bin/env python3
from examples.oodesign.composition.utilities import list_of_songs
from examples.oodesign.composition.music_library import MusicLibrary


def main():
    songs = list_of_songs()
    # Create and populate a MusicLibrary with 3 Playlists.
    library = MusicLibrary(3)
    print("Adding to Music Library:")
    for song in songs:
        print(song.name)
        library.add(song)

    rule = "*" * 50
    print(rule)
    song, playlist = library.play("Afterglow")
    print("Music Library Playing:", song[1], f"From Playlist #{playlist}",
          sep="\n")
    print(rule)
    print("Current Library Contents:", library, sep="\n")


if __name__ == '__main__':
    main()
