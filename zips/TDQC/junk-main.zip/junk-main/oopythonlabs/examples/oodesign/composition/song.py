#!/usr/bin/env python3
class Song:

    def __init__(self, name, artist, genre, release_date):
        self.name = name
        self.artist = artist
        self.genre = genre
        self.release_date = release_date

    def __str__(self):
        fmt = "    Name: {0}\n  Artist: {1}\n   Genre: {2}\nReleased: {3}"
        return fmt.format(self.name, self.artist, self.genre,
                          self.release_date)
