#!/usr/bin/env python3
from examples.oodesign.composition.playlist import Playlist
from examples.oodesign.composition.utilities import list_of_songs


def main():
    songs = list_of_songs()
    # Create and populate a Playlist with the first 3
    # Songs from the list of Song objects
    playlist = Playlist()
    for song in songs[:3]:
        print("Adding to the playlist:", song.name, "")
        playlist.add(song)

    print("\nPlaying", songs[1].name)
    playlist.play(songs[1].name)

    print("\nPlaylist Contents:", playlist, sep="\n")


if __name__ == '__main__':
    main()
