#!/usr/bin/env python3
class Playlist:

    def __init__(self):
        self.playlist = []

    def add(self, song):
        self.playlist.append(song)

    def play(self, name):
        names = [song.name for song in self.playlist]
        if name in names:
            idx = names.index(name)
            return (idx, self.playlist[idx])

    def __str__(self):
        return "\n\n".join(str(song) for song in self.playlist)
