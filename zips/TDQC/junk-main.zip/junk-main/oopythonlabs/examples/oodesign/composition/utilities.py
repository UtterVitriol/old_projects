#!/usr/bin/env python3
import os
import datetime
from examples.oodesign.composition.song import Song

def song_rows():
    DATA_DIR = os.path.abspath(os.path.dirname(__file__))
    songs = []
    with open(os.path.join(DATA_DIR, "list_of_songs.txt")) as file:
        for line in file:
            yield line[:-1].split("|")

def list_of_songs():
    songs = []
    # Convert each song row to a Song, and return
    # a list of Song objects
    for name, artist, genre, release_date in song_rows():
        release_date = datetime.date.fromisoformat(release_date)
        songs.append(Song(name, artist, genre, release_date))
    return songs
