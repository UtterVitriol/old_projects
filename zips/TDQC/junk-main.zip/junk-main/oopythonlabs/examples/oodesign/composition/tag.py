#!/usr/bin/env python3
class Tag:

    def __init__(self, library, playlist_number, song_number):
        self.library = library
        self.playlist_number = playlist_number
        self.song_number = song_number

    def __str__(self):
        fmt = "Tag:\n{}"
        return fmt.format(self.library[self.playlist_number][self.song_number])
