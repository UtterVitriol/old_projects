#!/usr/bin/env python3
from examples.oodesign.composition.playlist import Playlist


class MusicLibrary:
    def __init__(self, playlist_count):
        self.library = []
        for _ in range(playlist_count):
            self.library.append(Playlist())

    def add(self, song):
        least = min(self.library,
                    key=lambda a_playlist: len(a_playlist.playlist))
        least.add(song)

    def play(self, name):
        for index, a_playlist in enumerate(self.library):
            song = a_playlist.play(name)
            if song:
                break
        return song, index

    def __str__(self):
        return ("\n" * 3).join(f"Playlist # {index}\n{str(playlist)}"
                               for index, playlist in enumerate(self.library))
