#!/usr/bin/env python3
def double_it(sequence):
    if sequence is None:
        raise TypeError("NoneType is not allowed")
    return 2 * sequence


def every_other(a_list):
    if a_list is None:
        raise TypeError("NoneType is not allowed")
    return a_list[::2]
