#!/usr/bin/env python3
from datetime import date


def name():
    return "Hey Jude"


def artist():
    return "The Beatles"


genre = "Pop Rock"
release_date = date(1968, 8, 26)
