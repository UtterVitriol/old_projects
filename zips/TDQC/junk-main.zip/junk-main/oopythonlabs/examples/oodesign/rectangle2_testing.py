#!/usr/bin/env python3
from examples.oodesign.rectangle2 import Rectangle
rectangle = Rectangle(3, 4)
print(rectangle)
print("Length:", rectangle.length)
rectangle.width = 10
print(rectangle)
rectangle.length = 34
print("Length:", rectangle.length, "Width:", rectangle.width)
print("Area:", rectangle.area())
print(rectangle)
print(Rectangle.length.__doc__)
