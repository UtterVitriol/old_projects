#!/usr/bin/env python3
from person import Person

samantha = Person()
print("type(Person):", type(Person), "\t", "type(samantha):", type(samantha))
