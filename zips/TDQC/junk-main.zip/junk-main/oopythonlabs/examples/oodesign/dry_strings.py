#!/usr/bin/env python3
prompt = "Please enter a {} name: "         # Define a single DRY format string
first_name = input(prompt.format("first"))
middle_name = input(prompt.format("middle"))
last_name = input(prompt.format("last"))

double = "\n\n"                            # Define a single DRY string
print(first_name, last_name, end=double)
print(first_name, middle_name, last_name, end=double)
print("*" * 50)

# Define a function so that need of using 'end=' is DRY
def print_double_space(*args):
    print(*args, end="\n\n")


print_double_space(first_name, last_name)
print_double_space(first_name, middle_name, last_name)
