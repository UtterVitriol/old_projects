#!/usr/bin/env python3
class Person:
    pass
