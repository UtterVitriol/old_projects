#!/usr/bin/env python3
class Printer:

    def print_it(self):
        print("Printing")
