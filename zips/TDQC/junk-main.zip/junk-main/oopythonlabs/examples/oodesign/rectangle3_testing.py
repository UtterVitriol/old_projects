#!/usr/bin/env python3
from examples.oodesign.rectangle3 import Rectangle
rectangle = Rectangle(5, 9)
print(rectangle)
print("Length:", rectangle.length)
rectangle.width = 8
print(rectangle)
rectangle.length = 7
print("Length:", rectangle.length, "Width:", rectangle.width)
print("Area:", rectangle.area)
print(rectangle)
print(Rectangle.length.__doc__)
