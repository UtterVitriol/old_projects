#!/usr/bin/env python3
class Rectangle:

    def __init__(self, length = 1, width = 1):
        self.length = length
        self.width = width

    def get_length(self):
        return self._length

    def get_width(self):
        return self._width

    def set_length(self, length):
        self._length = length

    def set_width(self, width):
        self._width = width

    def area(self):
        """ returns the two dimensional area of the Rectangle"""
        return self._length * self._width

    def __str__(self):
        return f"{self._length} x {self._width}"

    length = property(get_length, set_length, doc="length of the Rectangle")
    width = property(get_width, set_width, doc="width of the Rectangle")
