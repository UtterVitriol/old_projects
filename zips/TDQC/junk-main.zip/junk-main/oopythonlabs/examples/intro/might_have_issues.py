def something(number = 0):
    print(    "Number is"  , number  )

value=99
