#!/usr/bin/env python3
import examples.intro     # imported  from ~/oopythonlabs from PYTHONPATH

print("Globals:", [symbol for symbol in dir() if not symbol.startswith("__")])
print()
print("examples package:",
      [symbol for symbol in dir(examples) if not symbol.startswith("__")])
