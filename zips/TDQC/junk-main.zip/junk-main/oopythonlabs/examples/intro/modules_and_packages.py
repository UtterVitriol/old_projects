#!/usr/bin/env python3
import sys          # improted from Python's standard library
import examples     # imported  from ~/oopythonlabs from PYTHONPATH


def symbols(namespace):
    """ Return list of all symbols in the given namespace, filtering
        out those that end with '__'"""
    return [symbol for symbol in dir(namespace) if not symbol.endswith("__")]


print("Globals:", [symbol for symbol in dir() if not symbol.startswith("__")])
print()
print("sys module:", symbols(sys)[:20])  # display first 20 elements
print()
print("examples package:",  symbols(examples))
