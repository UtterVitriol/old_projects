#!/usr/bin/env python3
import examples.intro.conversions.length.mile_km                        # 1st
import examples.intro.conversions.length.inch_cm as in_cm               # 2nd
from examples.intro.conversions.temperature.to_farenheit import c_to_f  # 3rd

# Using the 1st import above
km = 10
miles = examples.intro.conversions.length.mile_km.km_to_miles(km)
print(km, "kilometers =", miles, "miles")

# Using the 2nd import above
inches = 10
cm = in_cm.in_to_cm(inches)
print("{} inches = {:.2f} cm".format(inches, cm))


# Using the 3rd import above
celcius = 0  # freezing point of water
farenheit = c_to_f(celcius)
print(f"{celcius} celcius = {farenheit:.1f} farenheit")
