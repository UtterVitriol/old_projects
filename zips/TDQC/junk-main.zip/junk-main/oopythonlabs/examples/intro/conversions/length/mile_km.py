#!/usr/bin/env python3
def miles_to_km(miles):
    return miles / 0.62137


def km_to_miles(kilometers):
    return kilometers * 0.62137
