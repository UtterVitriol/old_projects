#!/usr/bin/env python3
def f_to_k(farenheit):
    return (farenheit - 32) / 1.8 + 273.15


def c_to_k(celcius):
    return celcius + 273.15
