#!/usr/bin/env python3
def in_to_cm(inches):
    return inches / 0.39370


def cm_to_in(centimeters):
    return centimeters * 0.39370
