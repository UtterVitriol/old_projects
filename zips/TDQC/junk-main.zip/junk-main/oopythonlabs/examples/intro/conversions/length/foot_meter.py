#!/usr/bin/env python3
def f_to_m(feet):
    return feet / 3.2808


def m_to_f(meters):
    return meters * 3.2808
