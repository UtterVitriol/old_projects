#!/usr/bin/env python3
def c_to_f(celcius):
    return celcius * 1.8 + 32


def k_to_f(kelvin):
    return (kelvin - 273.15) * 1.8
