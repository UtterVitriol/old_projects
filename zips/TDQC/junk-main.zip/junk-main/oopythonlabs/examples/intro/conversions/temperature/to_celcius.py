#!/usr/bin/env python3
def k_to_c(kelvin):
    return kelvin - 273.15


def f_to_c(farenheit):
    return (farenheit - 32) / 1.8
