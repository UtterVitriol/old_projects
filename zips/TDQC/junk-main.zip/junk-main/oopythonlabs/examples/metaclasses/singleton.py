class Singleton(type):
    singletons = {}     # { "class": value }-pairs
    def __call__(cls, *args, **kargs):
        if cls not in cls.singletons:
            cls.singletons[cls] = super().__call__(*args, **kargs)
        return cls.singletons[cls]

class TransactionManager(metaclass=Singleton):
    pass

tm1 = TransactionManager()
tm2 = TransactionManager()
print(tm1 is tm2)
