# a function that will be registered as an __init__ method
def initialize(self, name, phone):
    self.name = name
    self.phone = phone

# a function that will be registered as an __str__ method
def as_string(self):
    return f"{self.name} can be reached at {self.phone}"

# Dynamic creation of a class without using the 'class keyword'
Contact = type("Contact", (), {"__init__": initialize, "__str__" : as_string})

# Instanstiate and use a new instance of 'Contact'
p = Contact("Jenny", "8675-309")
print (p)
