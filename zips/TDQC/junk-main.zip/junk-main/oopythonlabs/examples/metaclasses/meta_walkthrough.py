class CustomMeta(type):
    @classmethod
    def __prepare__(metacls, name, bases, **kwargs):
        print (f"Preparing namespace for {name}")
        return super().__prepare__(name, bases, **kwargs)

    def __new__(cls, name, bases, namespace, **kwargs):
        print ("In CustomMeta::__new__")
        return super().__new__(cls, name, bases, namespace, **kwargs)

    def __init__(self, name, bases, namespace, **kwargs):
        print ("In CustomMeta::__init__")
        return super().__init__(name, bases, namespace, **kwargs)

    def __call__(self, *args, **kwargs):
        print("In CustomMeta::__call__")
        return super().__call__(*args, **kwargs)

class ParentClass:
    def __new__(cls, *args, **kwargs):
        print ("ParentClass::__new__")
        return super().__new__(cls, *args, **kwargs)

    def __init_subclass__(cls, **kwargs):
        print(f"ParentClass::__init_subclass__ {cls.__name__}")

class MyClass(ParentClass, metaclass=CustomMeta):
    print(f"Start compiling {__qualname__}")
    print(locals())
    def __new__(cls, *args, **kwargs):
        print ("MyClass::__new__")
        return super().__new__(cls, *args, **kwargs)

    def __init__(self):
        print("MyClass::__init__")

    class Desc:
        def __get__(self, instance, owner):
            pass

        def __set_name__(self, owner, name):
            print(f"{owner} shall know us as {name}")

    bob = Desc()

    print(f"Done compiling {__qualname__}")
    print(locals())

print ("MyClass has been constructed")

obj = MyClass()
