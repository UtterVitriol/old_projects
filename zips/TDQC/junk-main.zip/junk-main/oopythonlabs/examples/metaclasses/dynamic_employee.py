from dynamic_contact import Contact

# a function that will be registered as an __init__ method
def some_function(self, name, phone, id = None):
    super(Employee, self).__init__(name, phone)
    self.emp_id = id if id is not None else self.next_id()

# a function that will be registered as an instance method of a class
def a_getter(self):
    Employee._next_id += 1
    return Employee._next_id

# a function that will be registered as an __str__ method
def get_string(self):
    return  f"{super(Employee, self).__str__()}.  Employee ID: {self.emp_id}"

Employee = type("Employee", (Contact, ), {"__init__": some_function,
                                          "next_id" : a_getter,
                                          "__str__": get_string,
                                          "_next_id" : 0})
emp01 = Employee("Jenny", "8675-309")
emp02 = Employee("Alicia", "489-4608")
print(emp01, emp02, sep='\n')
