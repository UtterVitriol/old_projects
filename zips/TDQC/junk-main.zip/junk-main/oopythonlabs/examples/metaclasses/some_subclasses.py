from auto_slots import AutoSlots

class BasicClass:
    def __init__(self, some_attribute = "Initial value for my property"):
        self.some_attribute = some_attribute

    @property
    def some_attribute(self):
        return self._some_attribute

    @some_attribute.setter
    def some_attribute(self, value):
        self._some_attribute = value

class SlottedClass01(metaclass=AutoSlots):
    def __init__(self, some_attribute = "Initial value for my property"):
        self.some_attribute = some_attribute

    @property
    def some_attribute(self):
        return self._some_attribute

    @some_attribute.setter
    def some_attribute(self, value):
        self._some_attribute = value

class SlottedClass02(metaclass=AutoSlots):
    __slots__ = ["another_attribute"]
    def __init__(self, some_attribute = "Initial value for my property"):
        self.some_attribute = some_attribute
        self.another_attribute = "Proof of Concept"

    @property
    def some_attribute(self):
        return self._some_attribute

    @some_attribute.setter
    def some_attribute(self, value):
        self._some_attribute = value
