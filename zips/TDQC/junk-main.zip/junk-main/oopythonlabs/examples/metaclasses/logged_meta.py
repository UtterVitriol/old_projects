from examples.decorators.logging import logger
from inspect import isfunction

class LoggedMeta(type):
    def __new__(cls, name, bases, ns):
        print(f"Logging {name}")
        for key, value in ns.items():
            print(key, type(value))
            if isfunction(value):
                ns[key] = logger(value)
            elif isinstance(value, property):
                ns[key] = property(logger(value.__get__),
                                   logger(value.__set__),
                                   logger(value.__delete__))

        return super().__new__(cls, name, bases, ns)
