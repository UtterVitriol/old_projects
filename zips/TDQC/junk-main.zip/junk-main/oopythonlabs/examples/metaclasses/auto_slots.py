class AutoSlots(type):
    """This metaclass' singular action is to populate __slots__ with the names
       of all property instances, prefixed with '_'. By doing so, it forces
       programmers to declare properties for all instance data, or to manually
       populate __slots__ with the names of any other instance variables."""
    def __new__(cls, name, bases, namespace):
        # start with whatever names are already defined in __slots__
        slots = set(namespace.pop("__slots__", []))
        # create a set of '_' prefixed names, one for each property defined
        # for the class, and merge with the existing names
        prefixed_names = set()
        for key, value in namespace.items():
            if isinstance(value, property):
                prefixed_names.add(f"_{key}")
        namespace["__slots__"] = list(slots.union(prefixed_names))
        return super().__new__(cls, name, bases, namespace)
