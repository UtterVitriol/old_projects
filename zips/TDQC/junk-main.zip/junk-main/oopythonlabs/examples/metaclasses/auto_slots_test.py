import unittest
import random
from some_subclasses import BasicClass, SlottedClass01, SlottedClass02


class TestAutoSlots(unittest.TestCase):
    def test_BasicClass_has_dict(self):
        a = BasicClass()
        self.assertTrue(hasattr(a, "__dict__"))

    def test_SlottedClass01_has_no_dict(self):
        b = SlottedClass01()
        self.assertFalse(hasattr(b, "__dict__"))

    def test_SlottedClass01_has_slots(self):
        self.assertTrue(hasattr(SlottedClass01, "__slots__"))

    def test_SlottedClass01_has_some_attribute(self):
        self.assertTrue("_some_attribute" in SlottedClass01.__slots__)

    def test_SlottedClass01_can_assign_some_attribute(self):
        b = SlottedClass01()
        r = random.random()
        b.some_attribute = r
        self.assertTrue(b.some_attribute == r)

    def test_SlottedClass02_has_slots(self):
        self.assertTrue(hasattr(SlottedClass02, "__slots__"))

    def test_SlottedClass02_has_some_attribute(self):
        self.assertTrue("_some_attribute" in SlottedClass02.__slots__)

    def test_SlottedClass02_has_another_attribute(self):
        self.assertTrue("another_attribute" in SlottedClass02.__slots__)

if __name__ == "__main__":
    unittest.main()
