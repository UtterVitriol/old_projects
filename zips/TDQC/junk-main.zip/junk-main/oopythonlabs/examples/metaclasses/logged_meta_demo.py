from logged_meta import LoggedMeta

class NormalClass(metaclass=LoggedMeta):
    def __init__(self, some_param):
        self.some_attribute = some_param

    @property
    def some_property(self):
        return self.some_attribute

    @some_property.setter
    def some_property(self, value):
        self.some_attribute = value

    def __str__(self):
        fmt = "An instance of {} has an attribute with {}"
        return fmt.format(self.__class__.__name__, self.some_attribute)

demo = NormalClass("Hello")
print(demo)
demo.some_property = "Goodbye"
print(demo)
