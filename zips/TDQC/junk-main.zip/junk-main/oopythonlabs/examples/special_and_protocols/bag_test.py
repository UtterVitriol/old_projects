from bag_container import Bag


def main():
    b = Bag()
    b += "Something"
    b += "Anything"
    b += -789
    b[0] = "Overwriting"
    b["key"], b["name"] = "value", "Johnny Cash"
    sep, rule =' \n',  '#' * 30

    print(b["Invalid"])
    print(rule, f"The bag has {len(b)} items:", *b, sep=sep)
    if "key" in b:
        del b["key"]
    print(rule, f"The bag now has {len(b)} items:", *b, sep=sep)


if __name__ == "__main__":
    main()
