import pwd
import grp
import getpass


class UserInfo:
    __slots__ = []

    def __dir__(self):
        return ("username", "groups", "uid", "gid")

    def __getattribute__(self, name):
        user = getpass.getuser()
        if name == "username":
            return user
        elif name == "uid":
            return pwd.getpwnam(user).pw_uid
        elif name == "gid":
            return pwd.getpwnam(user).pw_gid
        elif name == "groups":
            groups = [g.gr_name for g in grp.getgrall() if user in g.gr_mem]
            gid = pwd.getpwnam(user).pw_gid
            groups.insert(0, grp.getgrgid(gid).gr_name)
            return groups


if __name__ == "__main__":
    user = UserInfo()
    print(dir(user))
    print(user.username)
    print("uid:", user.uid)
    print("gid:", user.gid)
    print("groups:", user.groups)
