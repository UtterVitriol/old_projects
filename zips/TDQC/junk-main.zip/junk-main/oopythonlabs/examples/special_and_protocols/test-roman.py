from roman import to_roman, to_arabic

with open("roman-numerals.txt") as testdata:
    for arabic, roman in (line.strip().split("=") for line in testdata):
        arabic = int(arabic)
        computed_arabic = to_arabic(roman)
        computed_roman = to_roman(arabic)
        if computed_arabic != arabic:
            print(f"Fail: {computed_arabic} != {arabic}")
            
        if computed_roman != roman:
            print(f"Fail: {computed_roman} != {roman}")
