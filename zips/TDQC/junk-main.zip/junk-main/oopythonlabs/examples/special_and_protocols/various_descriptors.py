class NonDataDescriptor:
    def __get__(self, instance, owner=None):
        return "Non-Data Descriptor Value"

    def __set_name__(self, owner, name):
        self.name = name
        self.owning_class = owner


class ImmutableDataDescriptor(NonDataDescriptor):
    def __get__(self, instance, owner=None):
        return "Data Descriptor Value"

    def __set__(self, instance, value):
        msg = f"{self.owning_class.__name__}.{self.name} is not mutable"
        raise AttributeError(msg)

    def __delete__(self, instance, value):
        pass


class MutableDataDescriptor(ImmutableDataDescriptor):
    def __set__(self, instance, value):
        setattr(instance, "_" + self.name, value)
