import unittest
from string_int import StringInt

class StringIntTest(unittest.TestCase):
    def setUp(self):
        self.a = StringInt("20")

    def test_bad_type(self):
        with self.assertRaises(TypeError):
            StringInt(20)

    def test_bad_value(self):
        with self.assertRaises(ValueError):
            StringInt("Twenty")

    def test_allow_negative(self):
        a = StringInt("-20")
        self.assertEqual(a, "-20")

    def test_str(self):
        self.assertEqual(str(self.a), "20")

    def test_repr(self):
        self.assertEqual(repr(self.a), "StringInt(20)")

    def test_bool(self):
        self.assertTrue(bool(self.a))

    def test_bool2(self):
        self.assertFalse(bool(StringInt("0")))

    def test_eq(self):
        self.assertTrue(self.a == "20")

    def test_lt(self):
        self.assertTrue(self.a < "30")

    def test_gt(self):
        self.assertTrue("40" > self.a)

    def test_ne(self):
        self.assertTrue(self.a != "-50")

    def test_ne2(self):
        self.assertTrue("24" != self.a)

    def test_add(self):
        self.assertEqual(self.a + "35", "55")

    def test_radd(self):
        self.assertEqual("10" + self.a, "30")

    def test_iadd(self):
        self.a += "18"
        self.a += "12"
        self.assertEqual(str(self.a), "50")

    def test_sub(self):
        self.assertEqual(self.a - "18", "2")

    def test_rsub(self):
        self.assertEqual("28" - self.a, "8")

    def test_isub(self):
        self.a -= "7"
        self.assertEqual(str(self.a), "13")

    def test_mul(self):
        self.assertEqual(self.a * "4", "80")

    def test_rmul(self):
        self.assertEqual("5" * self.a, "100")

    def test_imul(self):
        self.a *= "7"
        self.assertEqual(str(self.a), "140")

    def test_truediv(self):
        self.assertEqual(self.a / "3", f"{20/3}")

    def test_rtruediv(self):
        self.assertEqual("64" / self.a, f"{64/20}")

    def test_floordiv(self):
        self.assertEqual(self.a // "3", "6")

    def test_rfloordiv(self):
        self.assertEqual("57" // self.a, "2")

    def test_mod(self):
        self.assertEqual(self.a % "3", "2")

    # This will fail because str.__mod__ throws a TypeError
    # instead of returning NotImplemented
    def test_rmod(self):
        with self.assertRaises(TypeError):
            self.assertEqual("74" % self.a, 14)


unittest.main()
