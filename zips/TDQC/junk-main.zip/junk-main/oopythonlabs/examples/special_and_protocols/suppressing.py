from contextlib import suppress

with suppress(ValueError):
    print("Enter 10 numbers:")
    sum = 0
    for _ in range(10):
        sum += int(input("> "))

print("Sum of provided numbers is:", sum)
