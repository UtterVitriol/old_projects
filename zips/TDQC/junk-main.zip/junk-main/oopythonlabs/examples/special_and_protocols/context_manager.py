import traceback as tb


class SampleContext:
    def __enter__(self):
        print("Initialization of context being managed")
        return self

    def __exit__(self, exception_type, exception_value, traceback):
        msg = "Exiting context"
        if type:
            print(msg, "with exception")
            print(f"{exception_type=}\n{exception_value=}")
            tb.print_tb(traceback)
        else:
            print(msg)
        return True


for value in range(3, -1, -1):
    print()
    with SampleContext() as sample:
        print(f'10/{value}={10/value}')
