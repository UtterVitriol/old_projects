from bag_iterator import BagIterator


class Bag:
    def __init__(self, default_value="Unknown"):
        self._sequence, self._mapping, self._default  = [], {}, default_value

    def __iadd__(self, item):
        self._sequence.append(item)
        return self

    def __len__(self):
        return len(self._sequence) + len(self._mapping)

    def __getitem__(self, key):
        if isinstance(key, int) or isinstance(key, slice):
            return self._sequence[key]
        else:  # treat it as a key
            return self._mapping[key] if key in self._mapping \
                   else self.__missing__(key)

    def __missing__(self, key):
        return self._default  # self._mapping[key] = self._default

    def __setitem__(self, key, value):
        if isinstance(key, int) or isinstance(key, slice):
            self._sequence[key] = value
        else:  # treat it as a key
            self._mapping[key] = value

    def __delitem__(self, key):
        if isinstance(key, int) or isinstance(key, slice):
            del self._sequence[key]
        else:  # treat it as a key
            del self._mapping[key]

    def __contains__(self, item):
        return item in self._sequence or item in self._mapping

    def __iter__(self):
        return BagIterator(self._sequence, self._mapping)
