from datetime import date
from various_descriptors import ImmutableDataDescriptor


class TimeLapse(ImmutableDataDescriptor):

    def __init__(self, attribute):
        self.attr = attribute

    @staticmethod
    def time_lapse(since):
        if not isinstance(since, date):
            return 0
        days_in_year = 365.2425
        age = int((date.today() - since).days / days_in_year)
        return age

    def __get__(self, instance, owner=None):
        return TimeLapse.time_lapse(getattr(instance, self.attr, date.today()))

class Person:
    def __init__(self, name, date_of_birth):
        self.name = name
        self._date_of_birth = date_of_birth

    @property
    def date_of_birth(self):
        return self._date_of_birth

    def __str__(self):
        data = [f'{self.name=}', f'{self.date_of_birth=}', f'{self.age=}',
                f'{self.years_married=}', f'{self.years_at_residence=}']
        return '\n'.join(data)

    age = TimeLapse("date_of_birth")
    years_married = TimeLapse("wedding_date")
    years_at_residence = TimeLapse("move_in_date")

p = Person("Sam", date(1930, 8, 9))
p.wedding_date = date(1960, 3, 12)
p.move_in_date = date(1967, 6, 1)
print(p)
