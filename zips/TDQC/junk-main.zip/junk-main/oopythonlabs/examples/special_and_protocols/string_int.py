from functools import total_ordering


@total_ordering
class StringInt:
    def __init__(self, value: str):
        if not isinstance(value, str):
            raise TypeError("StringInt requires a string")
        if not StringInt._is_valid_string(value):
            raise ValueError("StringInt requires a string of only digits")
        self.value = StringInt._convert(value)

    def __str__(self):
        return str(self.value)

    def __repr__(self):
        return f"StringInt({self.value})"

    def __hash__(self):
        return hash(self.value)

    def __bool__(self):
        return True if self.value else False

    def __index__(self):
        return int(self.value)

    # Utilty method
    def _binary_op(self, other, f, /):
        if not StringInt._is_valid_string(other):
            return NotImplemented
        return str(f(self.value, StringInt._convert(other)))

    def _ibinary_op(self, other, op, /):
        if not isinstance(other, str):
            raise TypeError("StringInt requires a string")
        if not StringInt._is_valid_string(other):
            raise ValueError("StringInt requires a string of only digits")

        self.value = int(op(other))
        return self

    # These two methods satisfy the requirements of total_ordering
    # v                          v                               v
    def __eq__(self, other):
        if self._binary_op(other, lambda x, y: x == y) == "True":
            return True
        else:
            return False

    def __lt__(self, other):
        if self._binary_op(other, lambda x, y: x < y) == "True":
            return True
        else:
            return False
    # ^                          ^                               ^
    # These two methods satisfy the requirements of total_ordering

    def __add__(self, other):
        return self._binary_op(other, lambda x, y: x + y)

    __radd__ = __add__

    def __iadd__(self, other):
        return self._ibinary_op(other, self.__add__)

    def __sub__(self, other):
        return self._binary_op(other, lambda x, y: x - y)

    def __rsub__(self, other):
        return self._binary_op(other, lambda x, y: y - x)

    def __mul__(self, other):
        return self._binary_op(other, lambda x, y: x * y)

    __rmul__ = __mul__

    def __truediv__(self, other):
        return self._binary_op(other, lambda x, y: x / y)

    def __rtruediv__(self, other):
        return self._binary_op(other, lambda x, y: y / x)

    def __floordiv__(self, other):
        return self._binary_op(other, lambda x, y: x // y)

    def __rfloordiv__(self, other):
        return self._binary_op(other, lambda x, y: y // x)

    def __mod__(self, other):
        return self._binary_op(other, lambda x, y: x % y)

    def __rmod__(self, other):
        return self._binary_op(other, lambda x, y: y % x)

    @staticmethod
    def _is_valid_string(value):
        return isinstance(value, str) and \
               (value.isdigit() or
                (len(value) > 1 and value[0] == '-' and value[1:].isdigit()))

    @staticmethod
    def _convert(value: str) -> int:
        return int(value)
