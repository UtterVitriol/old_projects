from getpass import getuser as current_user

class ClassWithAttributes:
    def __init__(self):
        self.trait = "An attribute named: trait"

    # called *BEFORE* the normal attribute lookup
    def __getattribute__(self, name):
        print(f"Trying to __getattribute__ of {name}")
        value = None
        try:
            value = super().__getattribute__(name)
        except AttributeError as e:
            print(e)
            raise e
        print(f"End __getattribute__ of {name}")
        return value

    # called *AFTER* unsuccessful attribute lookup
    def __getattr__(self, name):
        print("trying __getattr__ of", name)
        if name == current_user():
            return f"{name} was here!"
        msg = f'No Attribute "{name}" in {type(self).__name__} object'
        raise AttributeError(msg)

a = ClassWithAttributes()
rule = f'\n{"*" * 50}\n'
print(a.trait, end=rule)
print(getattr(a, "trait"), end=rule)
print(getattr(a, "attr2", "default value"), end=rule)
try:
    a.student()
except AttributeError as ae:
    print(ae, end=rule)
try:
    a.nobody
except AttributeError as ae:
    print(ae, end=rule)

print(getattr(a, input("Enter your username: ")), end=rule)
