from various_descriptors import NonDataDescriptor, ImmutableDataDescriptor

class TakingPrecedence:
    descriptor = NonDataDescriptor()
    data_descriptor = ImmutableDataDescriptor()

    def __init__(self):
        self.descriptor = "Instance Descriptor"
        self.__dict__["data_descriptor"] = "Instance Data Descriptor"

    def __str__(self):
        return f"{self.descriptor=} {self.data_descriptor=}"

print(TakingPrecedence())
