class CustomDir:
    def __init__(self, transparency = True):
        self.transparency = transparency

    def __dir__(self):
        return ("key1", "key2") if not self.transparency else super().__dir__()

if __name__ == "__main__":
    obj = CustomDir()
    print(dir(obj))
    obj.transparency = False
    print()
    print(dir(obj))
