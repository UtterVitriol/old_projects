"Based on https://en.wikipedia.org/wiki/Roman_numerals"

def to_roman(value: int)  -> str:
    "Convert an integer to a Roman numeral. "
    if not isinstance(value, int):
        raise TypeError(f"Cannot convert a {type(value)}; must be an int")
    
    if not 0 <= value < 4000:
        raise ValueError("The value to convert must be between 0 and 3999")

    if value == 0:
        return "N"      # https://en.wikipedia.org/wiki/Roman_numerals#Zero

    arabic = (1000, 900,  500, 400, 100,  90, 50,  40, 10,  9,   5,  4,   1)
    roman = ('M',  'CM', 'D', 'CD','C', 'XC','L','XL','X','IX','V','IV','I')
    result = []
    for i in range(len(arabic)):
        count = value // arabic[i]
        result.append(roman[i] * count)
        value -= arabic[i] * count
    return ''.join(result)


import re

romanRegex = re.compile(r"M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})")

def to_arabic(roman: str) -> int:
    """ Convert a Roman numeral to an integer. """
    if not isinstance(roman, str):
        raise TypeError(F"Cannot convert a {type(roman)}; must be a string")

    if not roman:
        raise ValueError("Cannot convert an empty string")

    if roman == "N":
        return 0        # https://en.wikipedia.org/wiki/Roman_numerals#Zero

    if not romanRegex.match(roman):
        raise ValueError(f"'{roman}' is not a valid roman numeral")

    roman = roman.upper()
    romanMap = {'M':1000, 'D':500, 'C':100, 'L':50, 'X':10, 'V':5, 'I':1}
    arabic = 0
    for i in range(len(roman)):
        value = romanMap[roman[i]]
        # If the next place holds a larger number, this value is negative
        arabic += -value if i+1 < len(roman) and romanMap[roman[i+1]] > value else value
    return arabic
