class CustomRange:
    __slots__ = ("_start", "_stop", "_step", "_up", "_current")

    def __init__(self, start, stop=None, step=1, /):
        if not isinstance(step, int):
            raise TypeError("step argument must be an int")
        if not step:
            raise ValueError("step argument must not be zero")
        self._start = 0 if stop is None else start
        self._stop = start if stop is None else stop
        self._step = step
        self._up = step > 0

    def __iter__(self):
        self._current = self._start
        return self

    def __next__(self):
        value = self._current
        if (value >= self._stop and self._up) or \
           (value <= self._stop and not self._up):
            raise StopIteration()
        self._current += self._step
        return value

if __name__ == "__main__":
    print("CustomRange(10)          ", *CustomRange(10))
    print("CustomRange(1, 11)       ", *CustomRange(1,11))
    print("CustomRange(10, 101, 10) ", *CustomRange(10, 101, 10))
    print("CustomRange(10, 0, -1)   ", *CustomRange(10, 0, -1))
    print("CustomRange(10, 0, 1)    ", *CustomRange(10, 0, 1))
    print("-" * 30)
    print("Attempting: CustomRange(10, 0, 0)")
    print(CustomRange(10, 0, 0))
