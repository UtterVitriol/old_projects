class BagIterator:
    def __init__(self, items, keyed_items):
        self._items = items.copy()         # copy list to ensure behavior
        self._items.extend(keyed_items.items())  # return keyed as tuples
        self._limit = len(self._items)
        self._current = 0

    def __next__(self):
        value = self._current
        if value >= self._limit:
            raise StopIteration()
        self._current += 1
        return self._items[value]
