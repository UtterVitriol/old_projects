class GreetingQuotes:
    def __init__(self, greeting = lambda s: f"Hello {s}"):
        self.greeting = greeting

    def __call__(self, subject):
        print(self.greeting(subject))

developer = GreetingQuotes()
developer("World")

gang = GreetingQuotes(lambda s : f"{s}, come out and play-ee-ay!")
gang("Warriors")

goonies = GreetingQuotes(lambda s : f"Hey you guys!")
goonies("Everyone!")
