import enum
import pickle
from customers import Customer

class CustomerToXML:
    def __init__(self, filename, customer):
        self.filename = filename
        self.customer = customer
        
    def convert_to_xml(self):
        data = []
        fmt = "<{0}>{1}</{0}>\n"
        data.append("<customer>\n")
        data.append(fmt.format("first_name", self.customer.first_name))
        data.append(fmt.format("last_name", self.customer.last_name))
        data.append(fmt.format("age", self.customer.age))
        data.append(fmt.format("street", self.customer.street))
        data.append(fmt.format("city", self.customer.city))
        data.append(fmt.format("state", self.customer.state))
        data.append(fmt.format("zip", self.customer.zip))
        data.append("</customer>\n")
        with open(self.filename, "w") as file:
            file.writelines(data)


class CustomerToBinary:
    def __init__(self, filename, customer):
        self.filename = filename
        self.customer = customer

    def convert_to_xml(self):
        with open(self.filename, "wb") as file:
            pickle.dump(self.customer, file)

    
class CustomerToText:
    def __init__(self, filename, customer):
        self.filename = filename
        self.customer = customer

    def convert_to_xml(self):
        with open(self.filename, "w") as file:
            print(self.customer, file=file)
    

class CustomerConverterType(enum.Enum):
    XMLConverterType = 1
    BinaryConverterType = 2
    TextConvertertype = 3

class CustomerExporter:
    def __init__(self, filename, converter_type):
        self.filename = filename
        self.converter_type = converter_type

    def export_customer(self, customer):
    
        if self.converter_type == CustomerConverterType.XMLConverterType:
                exporter = CustomerToXML(self.filename, customer)
                exporter.convert_to_xml()
        elif self.converter_type == CustomerConverterType.BinaryConverterType:
                exporter = CustomerToBinary(self.filename, customer)
                exporter.convert_to_binary()
        elif self.converter_type == CustomerConverterType.TextConverterType:
                exporter = CustomerToText(self.filename, customer)
                exporter.convert_to_text()
        else:
            print("Unrecognized converter type")
            
            
def main():
    customer = Customer("A", "T", 36, "1 Main St", "Columbia", "MD", "21046")
    exporter = CustomerExporter("sample.xml", CustomerConverterType.XMLConverterType)
    exporter.export_customer(customer)

if __name__ == "__main__":
    main()