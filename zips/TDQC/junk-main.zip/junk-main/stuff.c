#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

#define MAX 20

void get_input(char *);

void math(double *out, char *ops, int *buff);

int main(void)
{
	char ops[33] = {'\0'}, operators[5] = {'*', '/', '+', '-'}, temp[20] = {'\0'};
	int buff[66] = {0};
	char input[MAX];
	
	get_input(input);
	
	input[strlen(input) - 1] = ' ';
	
	if(input[strlen(input) - 1] != ' '){
		puts("shits too long, son.");
		exit(1);
	}
	
	int count = 0, count1 = 0, count2 = 0, flag = 0;
	
	
	for(int i = 0; i < (int)strlen(input); i++){
		if(isdigit(input[i])){
			flag = 1;
			temp[count1++] = input[i];
		}
		
		if((input[i] == ' ' || i == strlen(input)) && flag){
			flag = 0;
			buff[count2] = atoi(temp);
			count2 += 1;
			for(int y = 0; y < strlen(temp); y++){
				temp[y] = '0';
			}
			count1 = 0;
		}
		
		for(int j = 0; j < 4; j++){
			if(input[i] == operators[j]){
				ops[count] = input[i];
				count += 1;
			}
		}
		
	}

	
	double out = 0;
	
	math(&out, ops, buff);
	
	printf("\nResult: %0.2f\n", out);
	return 0;
}

void math(double *out, char *ops, int *buff)
{
	char *op_num, *buff_num;
	int op_count = 0, buff_count = 0;
	int lone = 0, ltwo = 0, flag = 1;
	
	op_num = malloc(sizeof(char) * strlen(ops));
	buff_num = malloc(66);
	
	for(int i = 0; i < strlen(ops); i++){
		if(strchr(op_num, i + '0') == NULL && ops[i] == '*'){
			if(strchr(buff_num, i + '0') == NULL && strchr(buff_num, (i + 1) + '0') == NULL){
				*out += buff[i] * buff[i + 1];
				if(flag){
					lone = buff[i] * buff[i + 1];
					flag = 0;
				}else{
					ltwo = buff[i] * buff[i + 1];
					flag = 1;
				}
				buff_num[buff_count] = i + '0';
				buff_count++;
				buff_num[buff_count] = (i + 1) + '0';
				buff_count++;
			}else{
				if(strchr(buff_num, i + '0') == NULL){
					*out *= buff[i];
					buff_num[buff_count] = i + '0';
					buff_count++;
				}else if(strchr(buff_num, (i + 1) + '0') == NULL){
					*out *= buff[i + 1];
					buff_num[buff_count] = (i + 1) + '0';
					buff_count++;
				}else{
					*out = ltwo * lone;
				}
			}
			op_num[op_count] = i + '0';
			op_count++;
		}
	}
	
	printf("mult: %0.2lf\n", *out);
	
	for(int i = 0; i < strlen(ops); i++){
		if(strchr(op_num, i + '0') == NULL && ops[i] == '/'){
			if(strchr(buff_num, i + '0') == NULL && strchr(buff_num, (i + 1) + '0') == NULL){
				*out += buff[i] / buff[i + 1];
				if(flag){
					lone = buff[i] / buff[i + 1];
					flag = 0;
				}else{
					ltwo = buff[i] / buff[i + 1];
					flag = 1;
				}
				buff_num[buff_count] = i + '0';
				buff_count++;
				buff_num[buff_count] = (i + 1) + '0';
				buff_count++;
			}else{
				if(strchr(buff_num, i + '0') == NULL){
					*out /= buff[i];
					buff_num[buff_count] = i + '0';
					buff_count++;
				}else if(strchr(buff_num, (i + 1) + '0') == NULL){
					*out /= buff[i + 1];
					buff_num[buff_count] = (i + 1) + '0';
					buff_count++;
				}else{
					*out = lone / ltwo;
				}
			}
			op_num[op_count] = i + '0';
			op_count++;
		}
	}
	
	printf("div: %0.2lf\n", *out);
	
	for(int i = 0; i < strlen(ops); i++){
		if(strchr(op_num, i + '0') == NULL && ops[i] == '+'){
			if(strchr(buff_num, i + '0') == NULL && strchr(buff_num, (i + 1) + '0') == NULL){
				*out += buff[i] + buff[i + 1];
				if(flag){
					lone = buff[i] + buff[i + 1];
					flag = 0;
				}else{
					ltwo = buff[i] + buff[i + 1];
					flag = 1;
				}
				buff_num[buff_count] = i + '0';
				buff_count++;
				buff_num[buff_count] = (i + 1) + '0';
				buff_count++;
			}else{
				if(strchr(buff_num, i + '0') == NULL){
					*out += buff[i];
					buff_num[buff_count] = i + '0';
					buff_count++;
				}else if(strchr(buff_num, (i + 1) + '0') == NULL){
					*out += buff[i + 1];
					buff_num[buff_count] = (i + 1) + '0';
					buff_count++;
				}else{
					*out = lone + ltwo;
				}
			}
			op_num[op_count] = i + '0';
			op_count++;
		}
	}
	
	printf("add: %0.2lf\n", *out);
	
	for(int i = 0; i < strlen(ops); i++){
		if(strchr(op_num, i + '0') == NULL && ops[i] == '-'){
			if(strchr(buff_num, i + '0') == NULL && strchr(buff_num, (i + 1) + '0') == NULL){
				*out += buff[i] - buff[i + 1];
				if(flag){
					lone = buff[i] - buff[i + 1];
					flag = 0;
				}else{
					ltwo = buff[i] - buff[i + 1];
					flag = 1;
				}
				buff_num[buff_count] = i + '0';
				buff_count++;
				buff_num[buff_count] = (i + 1) + '0';
				buff_count++;
			}else{
				if(strchr(buff_num, i + '0') == NULL){
					*out -= buff[i];
					buff_num[buff_count] = i + '0';
					buff_count++;
				}else if(strchr(buff_num, (i + 1) + '0') == NULL){
					*out -= buff[i + 1];
					buff_num[buff_count] = (i + 1) + '0';
					buff_count++;
				}else{
					*out = ltwo - lone;
				}
			}
			op_num[op_count] = i + '0';
			op_count++;
		}
	}
	printf("sub: %0.2lf\n", *out);
}

void get_input(char *stuff)
{
	fgets(stuff, MAX, stdin);
}
