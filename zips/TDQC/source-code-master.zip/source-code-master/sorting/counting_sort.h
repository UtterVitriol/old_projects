#ifndef COUNTING_SORT_H
#define COUNTING_SORT_H

#include <stdlib.h>

void counting_sort(int *arr, size_t n, int min, int max);

#endif
