#ifndef SWAPPING_H
#define SWAPPING_H

#include <stddef.h>

void swap(void *pos1, void *pos2, size_t item_size);

#endif 
