#ifndef ANAGRAM_NAIVE_H
#define ANAGRAM_NAIVE_H

#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

bool anagram(const char *w1, const char *w2);


#endif
