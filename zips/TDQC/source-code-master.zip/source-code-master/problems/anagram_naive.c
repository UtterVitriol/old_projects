#include "anagram_naive.h"

bool anagram(const char *s1, const char *s2) {
  if (strlen(s1) != strlen(s2)) {
    return false;
  }

  char *s2_copy = strdup(s2);

  for (int i = 0; i < strlen(s1); i++) {
    bool found = false;
    for (int j = 0; j < strlen(s2); j++) {
      if (s1[i] == s2_copy[j]) {
        s2_copy[j] = '\0';
        found = true;
        break;
      }
    }

    if (!found) {
      free(s2_copy);
      return false;
    }
  }

  free(s2_copy);
  return true;
}
