#ifndef ANAGRAM_H
#define ANAGRAM_H

#include <stdbool.h>
#include <string.h>

#define NUM_LETTERS 26

bool anagram(const char *w1, const char *w2);

#endif
