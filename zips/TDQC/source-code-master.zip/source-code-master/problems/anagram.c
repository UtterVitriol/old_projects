#include "anagram.h"

bool anagram(const char *w1, const char *w2) {
    unsigned int counts[NUM_LETTERS] = {0};

    // count the letters in each word
    int i;
    for (i = 0; ! (w1[i] == '\0' || w2[i] == '\0'); i++) {
      counts[w1[i] - 'a']++;
      counts[w2[i] - 'a']--;
    }


    // strings with different lengths cannot be anagrams
    if (w1[i] != '\0' || w2[i] != '\0') {
      return false;
    }

    // check to make sure each character occurs the same number of times
    for (int i = 0; i < NUM_LETTERS; i++) {
      if (counts[i] != 0) {
        return false;
      }
    }

    return true;
}
